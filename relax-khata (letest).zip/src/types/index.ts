export type Language = 'en' | 'hi';

export type ScreenRoute =
  | 'dashboard'
  | 'sales'
  | 'purchase'
  | 'payments'
  | 'inventory'
  | 'parties'
  | 'gst-centre'
  | 'reports'
  | 'installer'
  | 'settings'
  | 'admin';

export interface BusinessProfile {
  id: string;
  businessName: string;
  tradeName: string;
  gstin: string;
  pan: string;
  state: string;
  stateCode: string;
  address: string;
  phone: string;
  email: string;
  bankName: string;
  bankAccountNo: string;
  bankIfsc: string;
  bankBranch: string;
  upiId: string;
  logoUrl?: string;
  signatureUrl?: string;
  financialYear: string;
  compositionScheme: boolean;
  invoicePrefix: string;
  termsAndConditions: string;
}

export type PartyType = 'customer' | 'supplier';

export interface Party {
  id: string;
  type: PartyType;
  name: string;
  mobile: string;
  email?: string;
  gstin?: string;
  address?: string;
  state: string;
  stateCode: string;
  openingBalance: number;
  balanceType: 'dr' | 'cr';
  creditLimit: number;
  paymentTerms: string;
  currentBalance: number;
  createdAt: string;
}

export interface Item {
  id: string;
  name: string;
  category: string;
  unit: 'PCS' | 'BOX' | 'KG' | 'MTR' | 'LTR' | 'SET' | 'BAG' | 'DOZ' | 'NOS' | 'PACK';
  hsnCode: string;
  gstRate: number; // 0, 5, 12, 18, 28
  purchasePrice: number;
  salePrice: number;
  wholesalePrice: number;
  retailPrice: number;
  openingStock: number;
  currentStock: number;
  minStockAlert: number;
  negativeStockAllowed: boolean;
  batchNo?: string;
  expiryDate?: string;
  barcode?: string;
  updatedAt: string;
}

export type VoucherType =
  | 'sales_invoice'
  | 'purchase_invoice'
  | 'sales_order'
  | 'purchase_order'
  | 'quotation'
  | 'proforma_invoice'
  | 'cash_memo'
  | 'delivery_challan'
  | 'credit_note'
  | 'debit_note'
  | 'payment_in'
  | 'payment_out'
  | 'contra'
  | 'journal'
  | 'expense'
  | 'income';

export interface VoucherItem {
  id: string;
  itemId: string;
  itemName: string;
  hsnCode: string;
  quantity: number;
  unit: string;
  rate: number;
  discountPercent: number;
  discountAmount: number;
  taxableAmount: number;
  gstRate: number;
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
  cessAmount: number;
  totalAmount: number;
  batchNo?: string;
  expiryDate?: string;
}

export interface Voucher {
  id: string;
  voucherNo: string;
  voucherType: VoucherType;
  date: string; // YYYY-MM-DD
  dueDate?: string;
  partyId?: string;
  partyName: string;
  partyGstin?: string;
  partyAddress?: string;
  partyState?: string;
  partyStateCode?: string;
  items: VoucherItem[];
  subtotal: number;
  discount: number;
  taxableAmount: number;
  cgst: number;
  sgst: number;
  igst: number;
  cess: number;
  roundOff: number;
  grandTotal: number;
  paymentMode: 'cash' | 'bank' | 'upi' | 'credit' | 'cheque';
  bankAccountId?: string;
  narration?: string;
  templateId: InvoiceTemplateId;
  status: 'paid' | 'unpaid' | 'partial' | 'cancelled';
  paidAmount?: number;
  isCancelled?: boolean;
  createdAt: string;
}

export type InvoiceTemplateId =
  | 'modern'
  | 'classic'
  | 'minimal'
  | 'corporate'
  | 'retail'
  | 'wholesale'
  | 'custom';

export type PaperSize = 'a4' | 'a5' | 'thermal';

export interface LedgerEntry {
  id: string;
  date: string;
  voucherId: string;
  voucherNo: string;
  voucherType: VoucherType;
  partyName?: string;
  accountName: string;
  accountGroup: string;
  debit: number;
  credit: number;
  runningBalance: number;
  narration: string;
}

// GST 2B Reconciliation Types
export interface GSTR2BItem {
  gstin: string;
  supplierName: string;
  invoiceNo: string;
  invoiceDate: string;
  invoiceType: string;
  taxableValue: number;
  igst: number;
  cgst: number;
  sgst: number;
  cess: number;
  itcAvailable: 'Y' | 'N';
  filingDate?: string;
}

export type ReconStatus =
  | 'matched'
  | 'missing_in_2b'
  | 'missing_in_books'
  | 'taxable_mismatch'
  | 'gst_mismatch'
  | 'duplicate';

export interface ReconRow {
  id: string;
  gstin: string;
  supplierName: string;
  invoiceNo: string;
  invoiceDate: string;
  bookTaxable: number;
  portalTaxable: number;
  bookGst: number;
  portalGst: number;
  difference: number;
  status: ReconStatus;
  notes: string;
}

export interface HelpMeQuery {
  id: string;
  query: string;
  answer: string;
  menuPath: string;
  navigationTarget?: ScreenRoute;
  steps?: string[];
  timestamp: string;
}
