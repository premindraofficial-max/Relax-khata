import React, { useState } from 'react';
import {
  FileText,
  Download,
  FileSpreadsheet,
  FileCode,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Upload,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';
import { Voucher, BusinessProfile, GSTR2BItem } from '../types';
import {
  computeGSTR1Data,
  generateOfficialGSTR1JSON,
  computeGSTR3B,
  reconcileGSTR2B,
} from '../utils/gstEngine';
import { formatCurrency } from '../utils/accounting';
import { exportToExcel, exportToCSV, exportToJSON, exportReportToPDF } from '../utils/exportService';

interface GSTCentreViewProps {
  vouchers: Voucher[];
  profile: BusinessProfile;
  portal2B: GSTR2BItem[];
  onUpdatePortal2B?: (data: GSTR2BItem[]) => void;
  lang: 'en' | 'hi';
}

export const GSTCentreView: React.FC<GSTCentreViewProps> = ({
  vouchers,
  profile,
  portal2B,
  lang,
}) => {
  const [activeTab, setActiveTab] = useState<'gstr1' | 'gstr3b' | 'recon2b' | 'download_centre' | 'annual'>('gstr1');
  const [period, setPeriod] = useState('April 2024');

  const gstr1 = computeGSTR1Data(vouchers, profile);
  const gstr3b = computeGSTR3B(vouchers);
  const recon = reconcileGSTR2B(vouchers, portal2B);

  // 1. Download official GSTR-1 Portal JSON
  const handleDownloadGSTR1JSON = () => {
    const payload = generateOfficialGSTR1JSON(vouchers, profile, '042024');
    exportToJSON(`GSTR1_${profile.gstin}_042024`, payload);
  };

  // 2. Download GSTR-1 Excel
  const handleDownloadGSTR1Excel = () => {
    const b2bHeaders = ['GSTIN of Receiver', 'Invoice Number', 'Invoice Date', 'Invoice Value', 'Place of Supply', 'Rate', 'Taxable Value', 'Cess Amount'];
    const b2bRows: (string | number)[][] = vouchers
      .filter((v) => (v.voucherType === 'sales_invoice' || v.voucherType === 'cash_memo') && v.partyGstin)
      .map((v) => [
        v.partyGstin || '',
        v.voucherNo,
        v.date,
        v.grandTotal,
        v.partyState || profile.state,
        v.items?.[0]?.gstRate || 18,
        v.taxableAmount,
        v.cess || 0,
      ]);

    const hsnHeaders = ['HSN', 'Description', 'UQC', 'Total Quantity', 'Total Value', 'Taxable Value', 'Integrated Tax', 'Central Tax', 'State Tax', 'Cess'];
    const hsnRows = gstr1.hsnSummary.map((h) => [
      h.hsnCode,
      h.description,
      h.unit,
      h.totalQty,
      h.totalValue,
      h.taxableValue,
      h.igst,
      h.cgst,
      h.sgst,
      h.cess,
    ]);

    exportToExcel(`GSTR1_Return_${profile.gstin}_042024`, [
      { sheetName: 'B2B Invoices', headers: b2bHeaders, rows: b2bRows },
      { sheetName: 'HSN Summary', headers: hsnHeaders, rows: hsnRows },
    ]);
  };

  // 3. Download GSTR-2B Reconciliation Excel
  const handleDownloadReconExcel = () => {
    const headers = ['GSTIN', 'Supplier Name', 'Invoice No', 'Date', 'Book Taxable', 'Portal Taxable', 'Book GST', 'Portal GST', 'Difference', 'Status', 'Notes'];
    const rows = recon.rows.map((r) => [
      r.gstin,
      r.supplierName,
      r.invoiceNo,
      r.invoiceDate,
      r.bookTaxable,
      r.portalTaxable,
      r.bookGst,
      r.portalGst,
      r.difference,
      r.status.toUpperCase(),
      r.notes,
    ]);
    exportToExcel(`GSTR_2B_Reconciliation_${profile.gstin}`, [
      { sheetName: 'Reconciliation Report', headers, rows },
    ]);
  };

  return (
    <div className="space-y-6 animate-in fade-in pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 text-white rounded-2xl p-5 md:p-6 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl md:text-2xl font-black tracking-tight">
              {lang === 'hi' ? 'जीएसटी केंद्र व रिटर्न फाइलिंग' : 'GST Centre & Filing Portal'}
            </h2>
            <span className="text-[10px] font-mono font-bold bg-emerald-400 text-slate-950 px-2.5 py-0.5 rounded-full uppercase">
              GSTIN: {profile.gstin}
            </span>
          </div>
          <p className="text-xs md:text-sm text-slate-300 mt-1">
            {lang === 'hi'
              ? 'GSTR-1, GSTR-3B, GSTR-2B आईटीसी मिलान और आधिकारिक पोर्टल JSON एक्सपोर्ट'
              : 'GSTR-1, GSTR-3B, Automated GSTR-2B ITC Matching & Official GST Portal Formats'}
          </p>
        </div>

        {/* Quick Period Selector */}
        <div className="flex items-center gap-2 bg-slate-800/80 border border-slate-700 rounded-xl px-3 py-1.5 text-xs">
          <span className="text-slate-400 font-semibold">{lang === 'hi' ? 'अवधि (Period):' : 'Return Period:'}</span>
          <select
            value={period}
            onChange={(e) => setPeriod(e.target.value)}
            className="bg-transparent border-none text-white font-bold focus:outline-none cursor-pointer"
          >
            <option value="April 2024" className="bg-slate-900">April 2024 (Monthly)</option>
            <option value="May 2024" className="bg-slate-900">May 2024 (Monthly)</option>
            <option value="Q1 (Apr-Jun 2024)" className="bg-slate-900">Q1 (Apr-Jun 2024)</option>
          </select>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        {[
          { id: 'gstr1', label: lang === 'hi' ? '1. GSTR-1 (बिक्री विवरणी)' : '1. GSTR-1 (Outward Supplies)' },
          { id: 'gstr3b', label: lang === 'hi' ? '2. GSTR-3B (मासिक टैक्स भुगतान)' : '2. GSTR-3B (Tax Summary & ITC)' },
          { id: 'recon2b', label: lang === 'hi' ? '3. GSTR-2B आईटीसी मिलान (Reconciliation)' : '3. GSTR-2B ITC Reconciliation' },
          { id: 'download_centre', label: lang === 'hi' ? '4. जीएसटी डाउनलोड केंद्र (Download Centre)' : '4. GST Download Centre' },
          { id: 'annual', label: lang === 'hi' ? '5. वार्षिक रिटर्न (GSTR-9 & 4)' : '5. Annual Returns (GSTR-9/4)' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
              activeTab === tab.id
                ? 'bg-purple-900 text-white shadow-md'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB 1: GSTR-1 */}
      {activeTab === 'gstr1' && (
        <div className="space-y-5">
          {/* Action Header */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">GSTR-1 Monthly Summary: {period}</h3>
              <p className="text-xs text-slate-500">
                Official prescribed Goods and Services Tax Network table structure
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={handleDownloadGSTR1JSON}
                className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition cursor-pointer shadow"
                title="Download JSON structure for direct portal upload"
              >
                <FileCode className="w-4 h-4" />
                <span>Portal JSON (gst.gov.in)</span>
              </button>

              <button
                onClick={handleDownloadGSTR1Excel}
                className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                <span>Export Excel (.xlsx)</span>
              </button>

              <button
                onClick={() => {
                  const headers = ['Table', 'Description', 'Count', 'Taxable Value', 'Total Tax', 'Invoice Value'];
                  const rows = [
                    ['4A, 4B', 'B2B Regular Invoices', gstr1.b2bCount, gstr1.b2bTaxable, gstr1.b2bCgst + gstr1.b2bSgst + gstr1.b2bIgst, gstr1.b2bTotal],
                    ['7', 'B2C Small (Intra-state)', gstr1.b2csCount, gstr1.b2csTaxable, gstr1.b2csCgst + gstr1.b2csSgst + gstr1.b2csIgst, gstr1.b2csTotal],
                    ['12', 'HSN Summary of Outward Supplies', gstr1.hsnSummary.length, gstr1.totalTaxable, gstr1.totalTax, gstr1.totalInvoiceValue],
                  ];
                  exportReportToPDF('GSTR-1_Summary', profile.businessName, profile.gstin, headers, rows);
                }}
                className="flex items-center gap-1.5 border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold text-xs px-3 py-2 rounded-xl transition cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>PDF</span>
              </button>
            </div>
          </div>

          {/* GSTR-1 Grid Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
              <span className="text-[11px] font-bold text-purple-700 uppercase">
                4A, 4B, 6B, 6C - B2B Invoices
              </span>
              <div className="text-2xl font-black text-slate-900">
                {formatCurrency(gstr1.b2bTotal)}
              </div>
              <div className="text-xs text-slate-500 pt-1 border-t border-slate-100 space-y-1">
                <div className="flex justify-between">
                  <span>Invoices Count:</span>
                  <strong>{gstr1.b2bCount}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Taxable Value:</span>
                  <strong>{formatCurrency(gstr1.b2bTaxable)}</strong>
                </div>
                <div className="flex justify-between text-emerald-700">
                  <span>IGST / CGST+SGST:</span>
                  <strong>{formatCurrency(gstr1.b2bCgst + gstr1.b2bSgst + gstr1.b2bIgst)}</strong>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
              <span className="text-[11px] font-bold text-indigo-700 uppercase">
                7 - B2C Small Invoices
              </span>
              <div className="text-2xl font-black text-slate-900">
                {formatCurrency(gstr1.b2csTotal)}
              </div>
              <div className="text-xs text-slate-500 pt-1 border-t border-slate-100 space-y-1">
                <div className="flex justify-between">
                  <span>Cash Memos / Unregistered:</span>
                  <strong>{gstr1.b2csCount}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Taxable Value:</span>
                  <strong>{formatCurrency(gstr1.b2csTaxable)}</strong>
                </div>
                <div className="flex justify-between text-indigo-700">
                  <span>Total Tax Collected:</span>
                  <strong>{formatCurrency(gstr1.b2csCgst + gstr1.b2csSgst + gstr1.b2csIgst)}</strong>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
              <span className="text-[11px] font-bold text-emerald-700 uppercase">
                Total GSTR-1 Outward Liability
              </span>
              <div className="text-2xl font-black text-emerald-900">
                {formatCurrency(gstr1.totalInvoiceValue)}
              </div>
              <div className="text-xs text-slate-500 pt-1 border-t border-slate-100 space-y-1">
                <div className="flex justify-between">
                  <span>Total Taxable Amount:</span>
                  <strong>{formatCurrency(gstr1.totalTaxable)}</strong>
                </div>
                <div className="flex justify-between text-emerald-800 font-bold">
                  <span>Total Tax Payable:</span>
                  <strong>{formatCurrency(gstr1.totalTax)}</strong>
                </div>
              </div>
            </div>
          </div>

          {/* Table 12: HSN Summary */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 bg-slate-100 border-b border-slate-200 flex justify-between items-center">
              <span className="font-bold text-xs uppercase text-slate-700">
                Table 12: HSN Wise Summary of Outward Supplies
              </span>
              <span className="text-xs text-slate-500 font-medium">
                Mandatory for GSTR-1 Portal Filing
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                  <tr>
                    <th className="p-3 text-center">HSN Code</th>
                    <th className="p-3">Description</th>
                    <th className="p-3 text-center">UQC (Unit)</th>
                    <th className="p-3 text-center">Total Qty</th>
                    <th className="p-3 text-right">Taxable Value</th>
                    <th className="p-3 text-right">CGST</th>
                    <th className="p-3 text-right">SGST</th>
                    <th className="p-3 text-right">IGST</th>
                    <th className="p-3 text-right">Total Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {gstr1.hsnSummary.map((h, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="p-3 text-center font-mono font-bold text-slate-900">{h.hsnCode}</td>
                      <td className="p-3 font-medium">{h.description}</td>
                      <td className="p-3 text-center">{h.unit}</td>
                      <td className="p-3 text-center font-semibold">{h.totalQty}</td>
                      <td className="p-3 text-right font-medium">{formatCurrency(h.taxableValue)}</td>
                      <td className="p-3 text-right text-slate-600">{formatCurrency(h.cgst)}</td>
                      <td className="p-3 text-right text-slate-600">{formatCurrency(h.sgst)}</td>
                      <td className="p-3 text-right text-slate-600">{formatCurrency(h.igst)}</td>
                      <td className="p-3 text-right font-bold text-slate-900">{formatCurrency(h.totalValue)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: GSTR-3B */}
      {activeTab === 'gstr3b' && (
        <div className="space-y-5">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">GSTR-3B Monthly Return & Tax Calculation</h3>
              <p className="text-xs text-slate-500">
                Outward Supplies Tax vs Input Tax Credit (ITC) offset
              </p>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => {
                  const headers = ['Table', 'Supply Details', 'Taxable Value', 'IGST', 'CGST', 'SGST', 'Cess'];
                  const rows = [
                    ['3.1 (a)', 'Outward Taxable supplies', gstr3b.outwardTaxable.taxable, gstr3b.outwardTaxable.igst, gstr3b.outwardTaxable.cgst, gstr3b.outwardTaxable.sgst, gstr3b.outwardTaxable.cess],
                    ['4 (A) (5)', 'Eligible ITC (All other ITC)', '-', gstr3b.eligibleItc.allOtherItc.igst, gstr3b.eligibleItc.allOtherItc.cgst, gstr3b.eligibleItc.allOtherItc.sgst, gstr3b.eligibleItc.allOtherItc.cess],
                    ['6.1', 'Net Tax Payable in Cash', '-', gstr3b.netTaxPayable.igst, gstr3b.netTaxPayable.cgst, gstr3b.netTaxPayable.sgst, 0],
                  ];
                  exportToExcel(`GSTR3B_${profile.gstin}`, [{ sheetName: 'GSTR-3B', headers, rows }]);
                }}
                className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                <span>Download GSTR-3B Excel</span>
              </button>
            </div>
          </div>

          {/* Table 3.1 & Table 4 Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
              <span className="font-bold text-purple-700 uppercase">3.1 Outward Tax Liability</span>
              <div className="text-xl font-black text-slate-900">
                {formatCurrency(gstr3b.outwardTaxable.igst + gstr3b.outwardTaxable.cgst + gstr3b.outwardTaxable.sgst)}
              </div>
              <div className="space-y-1 text-slate-600 pt-1 border-t border-slate-100">
                <div>Taxable: {formatCurrency(gstr3b.outwardTaxable.taxable)}</div>
                <div>CGST: {formatCurrency(gstr3b.outwardTaxable.cgst)} | SGST: {formatCurrency(gstr3b.outwardTaxable.sgst)}</div>
                <div>IGST: {formatCurrency(gstr3b.outwardTaxable.igst)}</div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
              <span className="font-bold text-emerald-700 uppercase">4. Eligible ITC Available</span>
              <div className="text-xl font-black text-emerald-900">
                {formatCurrency(gstr3b.eligibleItc.totalItc)}
              </div>
              <div className="space-y-1 text-slate-600 pt-1 border-t border-slate-100">
                <div>From Valid Purchase Bills</div>
                <div>CGST ITC: {formatCurrency(gstr3b.eligibleItc.allOtherItc.cgst)}</div>
                <div>SGST ITC: {formatCurrency(gstr3b.eligibleItc.allOtherItc.sgst)}</div>
                <div>IGST ITC: {formatCurrency(gstr3b.eligibleItc.allOtherItc.igst)}</div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
              <span className="font-bold text-rose-700 uppercase">6.1 Net Tax Payable in Cash</span>
              <div className="text-xl font-black text-rose-950">
                {formatCurrency(gstr3b.netTaxPayable.total)}
              </div>
              <div className="space-y-1 text-slate-600 pt-1 border-t border-slate-100">
                <div>After ITC set-off</div>
                <div>Cash Challan required: <strong>{formatCurrency(gstr3b.netTaxPayable.total)}</strong></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: GSTR-2B ITC RECONCILIATION */}
      {activeTab === 'recon2b' && (
        <div className="space-y-5">
          {/* Recon Control Bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-900 text-sm">
                  {lang === 'hi' ? 'GSTR-2B ऑटोमेटेड आईटीसी मिलान' : 'Automated GSTR-2B ITC Reconciliation'}
                </h3>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                  Automated Engine
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Compares purchase register against GST Portal GSTR-2B data with threshold matching
              </p>
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleDownloadReconExcel}
                className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition cursor-pointer shadow"
              >
                <Download className="w-4 h-4" />
                <span>{lang === 'hi' ? 'रिकॉन्सिलिएशन रिपोर्ट डाउनलोड' : 'Download Recon Report'}</span>
              </button>
            </div>
          </div>

          {/* Recon Stats Ribbon */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3">
              <span className="text-emerald-800 font-semibold uppercase block">
                {lang === 'hi' ? 'सत्यापित इनवॉइस (Matched)' : 'Matched Invoices'}
              </span>
              <div className="text-lg font-black text-emerald-950 mt-0.5">
                {recon.matchedCount} Bills
              </div>
              <span className="text-[10px] text-emerald-700">ITC: {formatCurrency(recon.matchedItc)}</span>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
              <span className="text-amber-800 font-semibold uppercase block">
                {lang === 'hi' ? '2B में छूटे हुए (Missing in 2B)' : 'Missing in 2B Portal'}
              </span>
              <div className="text-lg font-black text-amber-950 mt-0.5">
                {recon.missingIn2bCount} Bills
              </div>
              <span className="text-[10px] text-amber-700">Vendor didn't file GSTR-1</span>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3">
              <span className="text-blue-800 font-semibold uppercase block">
                {lang === 'hi' ? 'खाते में छूटे हुए' : 'Missing in Books'}
              </span>
              <div className="text-lg font-black text-blue-950 mt-0.5">
                {recon.missingInBooksCount} Bills
              </div>
              <span className="text-[10px] text-blue-700">Unrecorded in Purchase book</span>
            </div>

            <div className="bg-rose-50 border border-rose-200 rounded-xl p-3">
              <span className="text-rose-800 font-semibold uppercase block">
                {lang === 'hi' ? 'टैक्स / राशि अंतर' : 'Value / Tax Mismatches'}
              </span>
              <div className="text-lg font-black text-rose-950 mt-0.5">
                {recon.mismatchCount} Invoices
              </div>
              <span className="text-[10px] text-rose-700">Discrepancy detected</span>
            </div>
          </div>

          {/* Detailed Reconciliation Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-100 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                  <tr>
                    <th className="p-3">GSTIN & Supplier</th>
                    <th className="p-3">Invoice No</th>
                    <th className="p-3">Date</th>
                    <th className="p-3 text-right">Book Taxable</th>
                    <th className="p-3 text-right">Portal Taxable</th>
                    <th className="p-3 text-right">Book GST</th>
                    <th className="p-3 text-right">Portal GST</th>
                    <th className="p-3 text-center">Status</th>
                    <th className="p-3">Notes & Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {recon.rows.map((row) => (
                    <tr key={row.id} className="hover:bg-slate-50">
                      <td className="p-3">
                        <div className="font-bold text-slate-900">{row.supplierName}</div>
                        <div className="font-mono text-[10px] text-slate-500">{row.gstin}</div>
                      </td>
                      <td className="p-3 font-mono font-bold text-slate-900">{row.invoiceNo}</td>
                      <td className="p-3 text-slate-600">{row.invoiceDate}</td>
                      <td className="p-3 text-right font-medium">{formatCurrency(row.bookTaxable)}</td>
                      <td className="p-3 text-right font-medium">{formatCurrency(row.portalTaxable)}</td>
                      <td className="p-3 text-right font-bold text-slate-800">{formatCurrency(row.bookGst)}</td>
                      <td className="p-3 text-right font-bold text-emerald-700">{formatCurrency(row.portalGst)}</td>
                      <td className="p-3 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            row.status === 'matched'
                              ? 'bg-emerald-100 text-emerald-800'
                              : row.status === 'missing_in_2b'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {row.status.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="p-3 text-[11px] text-slate-600 max-w-xs">{row.notes}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: GST DOWNLOAD CENTRE */}
      {activeTab === 'download_centre' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="font-bold text-slate-900 text-base mb-1">GST Multi-Format Download Centre</h3>
            <p className="text-xs text-slate-500">
              Download every GST report in PDF, Excel (.xlsx), CSV, and Official Portal JSON
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
              {/* Card 1: GSTR-1 */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-slate-50/50">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">GSTR-1 Outward Supply Return</h4>
                    <span className="text-[11px] text-slate-500">Period: {period}</span>
                  </div>
                  <span className="text-[10px] bg-purple-100 text-purple-800 font-bold px-2 py-0.5 rounded">
                    Active
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    onClick={handleDownloadGSTR1JSON}
                    className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold p-2.5 rounded-lg transition cursor-pointer shadow"
                  >
                    <FileCode className="w-4 h-4" />
                    <span>Portal JSON</span>
                  </button>

                  <button
                    onClick={handleDownloadGSTR1Excel}
                    className="flex items-center justify-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold p-2.5 rounded-lg transition cursor-pointer"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                    <span>Excel (.xlsx)</span>
                  </button>
                </div>
              </div>

              {/* Card 2: GSTR-2B Reconciliation */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-slate-50/50">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">GSTR-2B ITC Reconciliation Sheet</h4>
                    <span className="text-[11px] text-slate-500">Purchase Book vs Portal Comparison</span>
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">
                    Reconciled
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    onClick={handleDownloadReconExcel}
                    className="flex items-center justify-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold p-2.5 rounded-lg transition cursor-pointer"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                    <span>Excel (.xlsx)</span>
                  </button>

                  <button
                    onClick={() => exportToCSV('GSTR_2B_Recon', ['GSTIN', 'Invoice', 'Status', 'Diff'], recon.rows.map(r => [r.gstin, r.invoiceNo, r.status, r.difference]))}
                    className="flex items-center justify-center gap-1.5 border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold p-2.5 rounded-lg transition cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>CSV Format</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: ANNUAL RETURNS (GSTR-9 & GSTR-4) */}
      {activeTab === 'annual' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-purple-700" />
            <h3 className="font-bold text-slate-900 text-base">Annual Return Preparation: GSTR-9 & GSTR-4</h3>
          </div>
          <p className="text-xs text-slate-500">
            Automated reconciliation between monthly filed returns (GSTR-1, GSTR-3B) and audited Books of Account.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-2">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <span className="font-bold text-purple-800 uppercase block">GSTR-9 Regular Taxpayer Annual Return</span>
              <p className="text-slate-600">
                Consolidates all 12 monthly GSTR-1 outward supplies and GSTR-3B tax payment records for the entire financial year.
              </p>
              <div className="font-bold text-slate-900">
                Annual Taxable Sales: {formatCurrency(gstr1.totalTaxable * 12)} (Estimated FY)
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <span className="font-bold text-indigo-800 uppercase block">GSTR-4 Composition Scheme Return</span>
              <p className="text-slate-600">
                For taxpayers registered under the 1% or 5% composition scheme with quarterly CMP-08 filing.
              </p>
              <div className="font-bold text-slate-900">
                Applicability: Regular Dealer (GSTR-1/3B Active)
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
