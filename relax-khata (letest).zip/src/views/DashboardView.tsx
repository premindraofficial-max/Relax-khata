import React, { useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownLeft,
  Wallet,
  Building2,
  DollarSign,
  PieChart,
  Package,
  Users,
  AlertCircle,
  FileText,
  Calendar,
  PlusCircle,
  ShieldCheck,
  ChevronRight,
  Percent,
} from 'lucide-react';
import { Voucher, Item, Party, ScreenRoute } from '../types';
import { computeDashboardMetrics, formatCurrency, computeAgeingAnalysis } from '../utils/accounting';

interface DashboardViewProps {
  vouchers: Voucher[];
  items: Item[];
  parties: Party[];
  onNavigate: (route: ScreenRoute, contextId?: string) => void;
  onOpenNewVoucher: (type: any) => void;
  onOpenDownloadModal?: () => void;
  lang: 'en' | 'hi';
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  vouchers,
  items,
  parties,
  onNavigate,
  onOpenNewVoucher,
  onOpenDownloadModal,
  lang,
}) => {
  const [timeFilter, setTimeFilter] = useState<'today' | 'week' | 'month' | 'year' | 'all'>('month');
  const [financialYear, setFinancialYear] = useState('2024-2025');

  // Compute metrics based on time filter
  const todayStr = new Date().toISOString().slice(0, 10);
  const currentMonth = todayStr.slice(0, 7);

  const dateFilter = {
    startDate: timeFilter === 'today' ? todayStr : timeFilter === 'month' ? `${currentMonth}-01` : undefined,
    endDate: undefined,
  };

  const metrics = computeDashboardMetrics(vouchers, items, parties, dateFilter);
  const ageing = computeAgeingAnalysis(parties, vouchers);

  const cards = [
    {
      id: 'sales',
      title: lang === 'hi' ? 'कुल बिक्री (Sales)' : 'Total Sales',
      value: formatCurrency(metrics.totalSales),
      subtitle: lang === 'hi' ? 'मासिक: ' + formatCurrency(metrics.monthlySales) : 'This Month: ' + formatCurrency(metrics.monthlySales),
      icon: TrendingUp,
      color: 'text-emerald-700 bg-emerald-50 border-emerald-200',
      route: 'sales' as ScreenRoute,
    },
    {
      id: 'purchase',
      title: lang === 'hi' ? 'कुल खरीद (Purchase)' : 'Total Purchase',
      value: formatCurrency(metrics.totalPurchase),
      subtitle: lang === 'hi' ? 'आईटीसी सहित इनवॉइस' : 'Input Tax Credit Eligible',
      icon: TrendingDown,
      color: 'text-blue-700 bg-blue-50 border-blue-200',
      route: 'purchase' as ScreenRoute,
    },
    {
      id: 'receivables',
      title: lang === 'hi' ? 'कुल प्राप्य (उधारी)' : 'Total Receivables',
      value: formatCurrency(metrics.totalReceivables),
      subtitle: lang === 'hi' ? 'ग्राहकों से बकाया राशि' : 'Outstanding from Debtors',
      icon: ArrowUpRight,
      color: 'text-amber-700 bg-amber-50 border-amber-200',
      route: 'parties' as ScreenRoute,
    },
    {
      id: 'payables',
      title: lang === 'hi' ? 'कुल देय (देनदारी)' : 'Total Payables',
      value: formatCurrency(metrics.totalPayables),
      subtitle: lang === 'hi' ? 'सप्लायरों को देय राशि' : 'Outstanding to Creditors',
      icon: ArrowDownLeft,
      color: 'text-rose-700 bg-rose-50 border-rose-200',
      route: 'parties' as ScreenRoute,
    },
    {
      id: 'cash',
      title: lang === 'hi' ? 'नकद शेष (Cash)' : 'Cash in Hand',
      value: formatCurrency(metrics.cashInHand),
      subtitle: lang === 'hi' ? 'कैश बॉक्स वर्तमान शेष' : 'Liquid Cash Balance',
      icon: Wallet,
      color: 'text-teal-700 bg-teal-50 border-teal-200',
      route: 'payments' as ScreenRoute,
    },
    {
      id: 'bank',
      title: lang === 'hi' ? 'बैंक शेष (Bank)' : 'Bank Balance',
      value: formatCurrency(metrics.bankBalance),
      subtitle: lang === 'hi' ? 'चालू खाता (HDFC Bank)' : 'Current Account Balance',
      icon: Building2,
      color: 'text-indigo-700 bg-indigo-50 border-indigo-200',
      route: 'payments' as ScreenRoute,
    },
    {
      id: 'expenses',
      title: lang === 'hi' ? 'कुल खर्चे (Expenses)' : 'Total Expenses',
      value: formatCurrency(metrics.totalExpenses),
      subtitle: lang === 'hi' ? 'बिजली, किराया व अन्य' : 'Office & Operations',
      icon: DollarSign,
      color: 'text-orange-700 bg-orange-50 border-orange-200',
      route: 'reports' as ScreenRoute,
    },
    {
      id: 'profit',
      title: lang === 'hi' ? 'शुद्ध लाभ (Net Profit)' : 'Net Profit',
      value: formatCurrency(metrics.netProfit),
      subtitle: lang === 'hi' ? 'राजस्व - खरीद व खर्चे' : 'Revenue minus COGS & Exp',
      icon: PieChart,
      color: 'text-emerald-800 bg-emerald-100/70 border-emerald-300',
      route: 'reports' as ScreenRoute,
    },
    {
      id: 'stock',
      title: lang === 'hi' ? 'स्टॉक मूल्य (Stock)' : 'Stock Valuation',
      value: formatCurrency(metrics.stockValue),
      subtitle: `${items.length} ${lang === 'hi' ? 'उपलब्ध वस्तुएं' : 'Products in Godown'}`,
      icon: Package,
      color: 'text-cyan-700 bg-cyan-50 border-cyan-200',
      route: 'inventory' as ScreenRoute,
    },
    {
      id: 'customers',
      title: lang === 'hi' ? 'कुल ग्राहक (Customers)' : 'Total Customers',
      value: String(metrics.totalCustomers),
      subtitle: lang === 'hi' ? 'पंजीकृत व उपभोक्ता' : 'Active Client Accounts',
      icon: Users,
      color: 'text-slate-700 bg-slate-100 border-slate-300',
      route: 'parties' as ScreenRoute,
    },
    {
      id: 'gst_payable',
      title: lang === 'hi' ? 'जीएसटी देय (Payable)' : 'GST Output Liability',
      value: formatCurrency(metrics.gstPayable),
      subtitle: lang === 'hi' ? 'बिक्री पर एकत्रित कर' : 'Output Tax on Sales',
      icon: Percent,
      color: 'text-purple-700 bg-purple-50 border-purple-200',
      route: 'gst-centre' as ScreenRoute,
    },
    {
      id: 'gst_itc',
      title: lang === 'hi' ? 'इनपुट टैक्स क्रेडिट (ITC)' : 'Input Tax Credit (ITC)',
      value: formatCurrency(metrics.gstReceivable),
      subtitle: lang === 'hi' ? 'GSTR-2B मान्य क्रेडिट' : 'Eligible GSTR-2B Claim',
      icon: ShieldCheck,
      color: 'text-lime-800 bg-lime-50 border-lime-200',
      route: 'gst-centre' as ScreenRoute,
    },
  ];

  return (
    <div className="space-y-6 animate-in fade-in pb-12">
      {/* Mobile Download & Install Highlight Card */}
      <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white rounded-2xl p-4 md:p-5 shadow-lg border-2 border-emerald-400/40 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shrink-0 shadow-inner">
            <span className="text-2xl">📲</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-black text-base md:text-lg">
                {lang === 'hi' ? 'RELAX KHATA ऍप को मोबाइल में इंस्टॉल करें' : 'Install RELAX KHATA on your Mobile Phone'}
              </h3>
              <span className="text-[10px] font-black uppercase bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full shadow-xs">
                Install App
              </span>
            </div>
            <p className="text-xs text-emerald-100 mt-0.5">
              {lang === 'hi'
                ? 'बिना इंटरनेट तेज बिलिंग, ब्लूटूथ थर्मल प्रिंटिंग और मोबाइल होम स्क्रीन से सीधा एक्सेस।'
                : '100% offline billing, bluetooth thermal printing and instant launch from your mobile home screen.'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <button
            onClick={() => {
              if (onOpenDownloadModal) onOpenDownloadModal();
              else onNavigate('installer');
            }}
            className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-white hover:bg-slate-100 text-emerald-900 font-black text-xs py-2.5 px-4 rounded-xl shadow-md transition cursor-pointer"
          >
            <span>{lang === 'hi' ? '📥 APK / मोबाइल में इंस्टॉल करें' : '📥 Download / Install on Mobile'}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Top Banner & Filter Controls */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl p-5 md:p-6 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl md:text-2xl font-black tracking-tight">
              {lang === 'hi' ? 'व्यापार डैशबोर्ड' : 'Business Dashboard'}
            </h2>
            <span className="text-[11px] font-bold bg-emerald-500 text-slate-950 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              FY {financialYear}
            </span>
          </div>
          <p className="text-xs md:text-sm text-slate-300 mt-1">
            {lang === 'hi'
              ? 'दैनिक बिक्री, उधारी, स्टॉक और जीएसटी रिटर्न की लाइव स्थिति'
              : 'Real-time overview of sales, receivables, cash flow & GST position'}
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Financial Year Selector */}
          <div className="flex items-center gap-1.5 bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-200">
            <Calendar className="w-3.5 h-3.5 text-emerald-400" />
            <select
              value={financialYear}
              onChange={(e) => setFinancialYear(e.target.value)}
              className="bg-transparent border-none text-white font-semibold focus:outline-none"
            >
              <option value="2024-2025" className="bg-slate-900">FY 2024-25</option>
              <option value="2025-2026" className="bg-slate-900">FY 2025-26</option>
              <option value="2026-2027" className="bg-slate-900">FY 2026-27</option>
            </select>
          </div>

          {/* Time Presets */}
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-1 flex gap-1 text-xs font-semibold">
            {(['today', 'week', 'month', 'year', 'all'] as const).map((period) => (
              <button
                key={period}
                onClick={() => setTimeFilter(period)}
                className={`px-3 py-1 rounded-lg transition cursor-pointer capitalize ${
                  timeFilter === period
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {period === 'today'
                  ? lang === 'hi' ? 'आज' : 'Today'
                  : period === 'week'
                  ? lang === 'hi' ? 'सप्ताह' : 'Week'
                  : period === 'month'
                  ? lang === 'hi' ? 'माह' : 'Month'
                  : period === 'year'
                  ? lang === 'hi' ? 'वर्ष' : 'Year'
                  : lang === 'hi' ? 'सभी' : 'All'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <button
          onClick={() => onOpenNewVoucher('sales_invoice')}
          className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white p-3 rounded-xl font-bold text-xs shadow-md transition cursor-pointer group"
        >
          <PlusCircle className="w-4 h-4 shrink-0 group-hover:rotate-90 transition duration-200" />
          <span className="truncate">{lang === 'hi' ? '+ नया इनवॉइस' : '+ New Invoice'}</span>
        </button>

        <button
          onClick={() => onOpenNewVoucher('cash_memo')}
          className="flex items-center gap-2 bg-teal-600 hover:bg-teal-500 text-white p-3 rounded-xl font-bold text-xs shadow-md transition cursor-pointer group"
        >
          <PlusCircle className="w-4 h-4 shrink-0 group-hover:rotate-90 transition duration-200" />
          <span className="truncate">{lang === 'hi' ? '+ कैश मेमो' : '+ Cash Memo'}</span>
        </button>

        <button
          onClick={() => onOpenNewVoucher('purchase_invoice')}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white p-3 rounded-xl font-bold text-xs shadow-md transition cursor-pointer group"
        >
          <PlusCircle className="w-4 h-4 shrink-0 group-hover:rotate-90 transition duration-200" />
          <span className="truncate">{lang === 'hi' ? '+ खरीद बिल' : '+ Purchase Bill'}</span>
        </button>

        <button
          onClick={() => onOpenNewVoucher('payment_in')}
          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white p-3 rounded-xl font-bold text-xs shadow-md transition cursor-pointer group"
        >
          <PlusCircle className="w-4 h-4 shrink-0 group-hover:rotate-90 transition duration-200" />
          <span className="truncate">{lang === 'hi' ? '+ पेमेंट इन (Receipt)' : '+ Payment In'}</span>
        </button>

        <button
          onClick={() => onNavigate('gst-centre')}
          className="flex items-center gap-2 bg-purple-700 hover:bg-purple-600 text-white p-3 rounded-xl font-bold text-xs shadow-md transition cursor-pointer"
        >
          <FileText className="w-4 h-4 shrink-0" />
          <span className="truncate">{lang === 'hi' ? 'GSTR-1 रिटर्न' : 'File GSTR-1'}</span>
        </button>

        <button
          onClick={() => onNavigate('inventory')}
          className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white p-3 rounded-xl font-bold text-xs shadow-md transition cursor-pointer"
        >
          <Package className="w-4 h-4 shrink-0" />
          <span className="truncate">{lang === 'hi' ? '+ नया स्टॉक आइटम' : '+ Add Stock'}</span>
        </button>
      </div>

      {/* Main Clickable 12+ Metrics Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.id}
              onClick={() => onNavigate(card.route)}
              className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md hover:border-emerald-300 transition cursor-pointer group flex flex-col justify-between"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                    {card.title}
                  </span>
                  <h3 className="text-xl md:text-2xl font-black text-slate-900 mt-1 tracking-tight">
                    {card.value}
                  </h3>
                </div>
                <div className={`p-2.5 rounded-xl border ${card.color} group-hover:scale-110 transition shrink-0`}>
                  <Icon className="w-5 h-5" />
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span className="truncate">{card.subtitle}</span>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 group-hover:translate-x-1 transition shrink-0" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Charts & Financial Summaries */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sales & Purchase Trends SVG Visualizer */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h4 className="font-bold text-slate-900 text-base">
                {lang === 'hi' ? 'बिक्री व खरीद रुझान (Monthly Trends)' : 'Sales & Purchase Monthly Comparison'}
              </h4>
              <p className="text-xs text-slate-500">
                {lang === 'hi' ? 'माहवार राजस्व व खरीद का तुलनात्मक ग्राफ' : 'Visual performance of revenue vs procurement'}
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs font-semibold">
              <span className="flex items-center gap-1.5 text-emerald-700">
                <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block" />
                Sales
              </span>
              <span className="flex items-center gap-1.5 text-blue-700">
                <span className="w-3 h-3 rounded-full bg-blue-500 inline-block" />
                Purchase
              </span>
            </div>
          </div>

          {/* SVG Bar Chart */}
          <div className="h-56 w-full flex items-end justify-between gap-3 pt-6 pb-2 px-2 border-b border-slate-100">
            {[
              { month: 'Nov', sales: 65, pur: 45 },
              { month: 'Dec', sales: 85, pur: 55 },
              { month: 'Jan', sales: 75, pur: 50 },
              { month: 'Feb', sales: 95, pur: 68 },
              { month: 'Mar', sales: 120, pur: 88 },
              { month: 'Apr (Current)', sales: 132, pur: 92 },
            ].map((bar, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end gap-1.5 group">
                <div className="w-full flex items-end justify-center gap-1.5 h-full">
                  <div
                    className="w-1/2 max-w-[28px] bg-emerald-500 group-hover:bg-emerald-400 rounded-t-md transition-all duration-300 relative"
                    style={{ height: `${(bar.sales / 140) * 100}%` }}
                    title={`Sales: ₹${bar.sales * 1000}`}
                  />
                  <div
                    className="w-1/2 max-w-[28px] bg-blue-500 group-hover:bg-blue-400 rounded-t-md transition-all duration-300 relative"
                    style={{ height: `${(bar.pur / 140) * 100}%` }}
                    title={`Purchase: ₹${bar.pur * 1000}`}
                  />
                </div>
                <span className="text-[11px] font-semibold text-slate-500 group-hover:text-slate-900 mt-2">
                  {bar.month}
                </span>
              </div>
            ))}
          </div>

          <div className="flex justify-between items-center text-xs text-slate-500 pt-1">
            <span>Peak Month: <strong>April 2024 (₹ 1,32,000)</strong></span>
            <button
              onClick={() => onNavigate('reports')}
              className="font-bold text-emerald-600 hover:text-emerald-700 cursor-pointer"
            >
              {lang === 'hi' ? 'विस्तृत रिपोर्ट देखें →' : 'View Full Reports →'}
            </button>
          </div>
        </div>

        {/* Receivables & Payables Ageing Analysis */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-amber-600" />
              <h4 className="font-bold text-slate-900 text-base">
                {lang === 'hi' ? 'बकाया उधारी विश्लेषण (Ageing)' : 'Outstanding Payment Ageing'}
              </h4>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {lang === 'hi' ? 'दिनों के अनुसार देय और प्राप्य उधारी' : 'Days overdue distribution of receivables'}
            </p>

            <div className="space-y-3 mt-4 text-xs">
              {ageing.slice(0, 3).map((ag, idx) => (
                <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5">
                  <div className="flex justify-between font-bold text-slate-800">
                    <span>{ag.partyName}</span>
                    <span className="text-amber-700">{formatCurrency(ag.totalDue)}</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden flex">
                    <div style={{ width: '60%' }} className="bg-emerald-500 h-full" title="0-30 Days" />
                    <div style={{ width: '25%' }} className="bg-amber-500 h-full" title="31-60 Days" />
                    <div style={{ width: '15%' }} className="bg-rose-500 h-full" title="60+ Days" />
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-500">
                    <span>0-30d: {formatCurrency(ag.days0to30)}</span>
                    <span className="text-rose-600 font-semibold">60d+: {formatCurrency(ag.daysAbove90)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => onNavigate('parties')}
            className="w-full mt-4 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs py-2.5 rounded-xl transition cursor-pointer text-center"
          >
            {lang === 'hi' ? 'सभी पार्टियों का लेजर देखें' : 'Manage All Party Ledgers'}
          </button>
        </div>
      </div>
    </div>
  );
};
