import React, { useState } from 'react';
import {
  Plus,
  Printer,
  FileSpreadsheet,
  Search,
  ShieldCheck,
} from 'lucide-react';
import { Voucher, VoucherType, BusinessProfile } from '../types';
import { formatCurrency } from '../utils/accounting';
import { exportToExcel, exportToCSV } from '../utils/exportService';

interface PurchaseViewProps {
  vouchers: Voucher[];
  profile: BusinessProfile;
  onOpenNewVoucher: (type: VoucherType) => void;
  onOpenPreview: (voucher: Voucher) => void;
  lang: 'en' | 'hi';
}

export const PurchaseView: React.FC<PurchaseViewProps> = ({
  vouchers,
  onOpenNewVoucher,
  onOpenPreview,
  lang,
}) => {
  const [search, setSearch] = useState('');

  const purchaseVouchers = vouchers.filter((v) => {
    const isPur = ['purchase_invoice', 'purchase_order', 'debit_note'].includes(v.voucherType);
    if (!isPur) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        v.voucherNo.toLowerCase().includes(q) ||
        v.partyName.toLowerCase().includes(q) ||
        (v.partyGstin && v.partyGstin.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const totalPurchase = purchaseVouchers.reduce((sum, v) => sum + (v.grandTotal || 0), 0);
  const totalItc = purchaseVouchers.reduce((sum, v) => sum + (v.cgst || 0) + (v.sgst || 0) + (v.igst || 0), 0);

  const handleExportExcel = () => {
    const headers = ['Bill No', 'Type', 'Date', 'Supplier Name', 'GSTIN', 'Taxable', 'CGST', 'SGST', 'IGST', 'Grand Total', 'Status'];
    const rows = purchaseVouchers.map((v) => [
      v.voucherNo,
      v.voucherType,
      v.date,
      v.partyName,
      v.partyGstin || '',
      v.taxableAmount,
      v.cgst || 0,
      v.sgst || 0,
      v.igst || 0,
      v.grandTotal,
      v.status,
    ]);
    exportToExcel(`Purchase_Register_${Date.now()}`, [{ sheetName: 'Purchases', headers, rows }]);
  };

  const handleExportCSV = () => {
    const headers = ['Bill No', 'Date', 'Supplier', 'GSTIN', 'Taxable', 'ITC GST', 'Total'];
    const rows = purchaseVouchers.map((v) => [
      v.voucherNo,
      v.date,
      v.partyName,
      v.partyGstin || '',
      v.taxableAmount,
      (v.cgst || 0) + (v.sgst || 0) + (v.igst || 0),
      v.grandTotal,
    ]);
    exportToCSV(`Purchase_Register_${Date.now()}`, headers, rows);
  };

  return (
    <div className="space-y-5 animate-in fade-in pb-12">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {lang === 'hi' ? 'खरीद और परचेज बिल्स (Purchases)' : 'Purchase & Procurement Centre'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'hi' ? 'सप्लायर बिल, डेबिट नोट और GSTR-2B इनपुट टैक्स क्रेडिट' : 'Supplier Invoices, Debit Notes & ITC Eligibility'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onOpenNewVoucher('purchase_invoice')}
            className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition cursor-pointer shadow"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'hi' ? '+ नया खरीद बिल' : '+ New Purchase Bill'}</span>
          </button>

          <button
            onClick={() => onOpenNewVoucher('debit_note')}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'hi' ? 'डेबिट नोट' : 'Debit Note'}</span>
          </button>

          <div className="flex items-center gap-1 border-l border-slate-200 pl-2">
            <button
              onClick={handleExportExcel}
              className="p-2 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition border border-slate-200 cursor-pointer"
              title="Export to Excel"
            >
              <FileSpreadsheet className="w-4 h-4 text-blue-600" />
            </button>
            <button
              onClick={handleExportCSV}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition border border-slate-200 cursor-pointer text-xs font-bold"
              title="Export to CSV"
            >
              CSV
            </button>
          </div>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
          <span className="text-xs font-semibold text-blue-800 uppercase">
            {lang === 'hi' ? 'कुल खरीद खर्च' : 'Total Procurement Value'}
          </span>
          <div className="text-xl md:text-2xl font-black text-blue-950 mt-1">
            {formatCurrency(totalPurchase)}
          </div>
          <span className="text-[11px] text-blue-700">{purchaseVouchers.length} Total Bills</span>
        </div>

        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-emerald-800 uppercase flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              {lang === 'hi' ? 'मान्य इनपुट टैक्स क्रेडिट (ITC)' : 'Eligible ITC on Purchases'}
            </span>
            <div className="text-xl md:text-2xl font-black text-emerald-950 mt-1">
              {formatCurrency(totalItc)}
            </div>
            <span className="text-[11px] text-emerald-700">Available to offset against GSTR-3B tax</span>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex items-center gap-2">
        <Search className="w-4 h-4 text-slate-400 shrink-0" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={lang === 'hi' ? 'सप्लायर का नाम, बिल संख्या खोजें...' : 'Search supplier name, bill number...'}
          className="w-full bg-transparent border-none outline-none text-xs text-slate-800"
        />
      </div>

      {/* Purchase Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-100 border-b border-slate-200 text-slate-600 font-semibold uppercase">
              <tr>
                <th className="p-3">Bill No</th>
                <th className="p-3">Type</th>
                <th className="p-3">Date</th>
                <th className="p-3">Supplier Name</th>
                <th className="p-3 text-right">Taxable</th>
                <th className="p-3 text-right">Eligible ITC</th>
                <th className="p-3 text-right">Total Bill</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {purchaseVouchers.map((v) => {
                const itc = (v.cgst || 0) + (v.sgst || 0) + (v.igst || 0);
                return (
                  <tr key={v.id} className="hover:bg-slate-50/80 transition">
                    <td className="p-3 font-mono font-bold text-slate-900">{v.voucherNo}</td>
                    <td className="p-3">
                      <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-slate-100">
                        {v.voucherType.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="p-3 text-slate-600">{v.date}</td>
                    <td className="p-3">
                      <div className="font-bold text-slate-900">{v.partyName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {v.partyGstin || 'Unregistered'}
                      </div>
                    </td>
                    <td className="p-3 text-right font-medium">{formatCurrency(v.taxableAmount)}</td>
                    <td className="p-3 text-right font-bold text-emerald-700">{formatCurrency(itc)}</td>
                    <td className="p-3 text-right font-bold text-slate-900 text-sm">
                      {formatCurrency(v.grandTotal)}
                    </td>
                    <td className="p-3 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          v.status === 'paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {v.status}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => onOpenPreview(v)}
                        className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition cursor-pointer"
                        title="Preview & Print Bill"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
