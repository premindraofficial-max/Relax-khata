import React, { useState } from 'react';
import {
  Building2,
  Percent,
  FileText,
  Languages,
  Type,
  Printer,
  Database,
  Cloud,
  ShieldCheck,
  CheckCircle2,
  Download,
  Upload,
  RefreshCw,
  Sliders,
} from 'lucide-react';
import { BusinessProfile, Language, InvoiceTemplateId } from '../types';
import { LocalKhataDB } from '../utils/storage';

interface SettingsViewProps {
  profile: BusinessProfile;
  onUpdateProfile: (p: BusinessProfile) => void;
  lang: Language;
  onUpdateLanguage: (l: Language) => void;
  fontScale: number;
  onUpdateFontScale: (s: number) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  profile,
  onUpdateProfile,
  lang,
  onUpdateLanguage,
  fontScale,
  onUpdateFontScale,
}) => {
  const [formData, setFormData] = useState<BusinessProfile>(profile);
  const [syncStatus, setSyncStatus] = useState<string>('Connected & Ready');
  const [isSyncing, setIsSyncing] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(formData);
    LocalKhataDB.saveProfile(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleBackupDownload = () => {
    const jsonStr = LocalKhataDB.exportFullBackupJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RELAX_KHATA_Full_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleRestoreUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const ok = LocalKhataDB.restoreFromBackupJSON(content);
        if (ok) {
          alert(lang === 'hi' ? 'डेटाबेस सफलतापूर्वक रीस्टोर कर लिया गया है! पेज रीलोड हो रहा है।' : 'Backup restored successfully! Reloading...');
          window.location.reload();
        } else {
          alert('Invalid backup JSON file.');
        }
      }
    };
    reader.readAsText(file);
  };

  const handleManualSync = async () => {
    setIsSyncing(true);
    setSyncStatus('Synchronizing local database with cloud storage...');
    try {
      const fullBackup = LocalKhataDB.exportFullBackupJSON();
      const res = await fetch('/api/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessId: formData.id || 'shree_shyam',
          data: JSON.parse(fullBackup),
          timestamp: new Date().toISOString(),
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSyncStatus(`Synchronized successfully at ${new Date().toLocaleTimeString()}`);
      } else {
        setSyncStatus('Local offline engine active. Ready for sync.');
      }
    } catch {
      setSyncStatus('Operating in High-Performance Local Offline Mode.');
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in pb-16">
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {lang === 'hi' ? 'सेटिंग्स व व्यापार प्रोफ़ाइल' : 'Settings & Business Configuration'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'hi'
              ? 'जीएसटी विवरण, फॉन्ट स्केलिंग, द्विभाषी भाषा, इनवॉइस टेम्प्लेट व क्लाउड सिंक'
              : 'GST Registration, Arial Font Scaling, Bilingual Language, Thermal Printer & Cloud Backup'}
          </p>
        </div>

        {saveSuccess && (
          <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            {lang === 'hi' ? 'सेटिंग्स सुरक्षित कर ली गईं!' : 'Settings Saved Successfully!'}
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Business Profile Form */}
        <div className="lg:col-span-2 space-y-6">
          <form onSubmit={handleSaveProfile} className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-5 text-xs">
            <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
              <Building2 className="w-5 h-5 text-emerald-600" />
              <h3 className="font-bold text-sm text-slate-900">
                {lang === 'hi' ? 'कंपनी / फर्म प्रोफाइल व जीएसटी विवरण' : 'Company Profile & Legal Details'}
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  {lang === 'hi' ? 'फर्म का नाम (Legal Business Name) *' : 'Legal Business Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={formData.businessName}
                  onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  {lang === 'hi' ? 'व्यापारिक नाम (Trade Name Hindi/English)' : 'Trade Name'}
                </label>
                <input
                  type="text"
                  value={formData.tradeName}
                  onChange={(e) => setFormData({ ...formData, tradeName: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">GSTIN Number (15 Digits)</label>
                <input
                  type="text"
                  maxLength={15}
                  value={formData.gstin}
                  onChange={(e) => setFormData({ ...formData, gstin: e.target.value.toUpperCase() })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-mono font-bold uppercase"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">State & State Code</label>
                <input
                  type="text"
                  value={`${formData.state} (${formData.stateCode})`}
                  onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-semibold"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Financial Year</label>
                <select
                  value={formData.financialYear}
                  onChange={(e) => setFormData({ ...formData, financialYear: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-bold"
                >
                  <option value="2024-2025">2024-2025</option>
                  <option value="2025-2026">2025-2026</option>
                  <option value="2026-2027">2026-2027</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Business Mobile / Phone</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-mono"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Business Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2"
                />
              </div>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Full Business Address</label>
              <textarea
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                rows={2}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2"
              />
            </div>

            {/* Bank & UPI Details */}
            <div className="border-t border-slate-200 pt-4 space-y-4">
              <span className="font-bold text-slate-800 text-xs uppercase block">Bank Account & Scan to Pay (UPI)</span>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Bank Name</label>
                  <input
                    type="text"
                    value={formData.bankName}
                    onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-medium"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Account Number</label>
                  <input
                    type="text"
                    value={formData.bankAccountNo}
                    onChange={(e) => setFormData({ ...formData, bankAccountNo: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">IFSC Code</label>
                  <input
                    type="text"
                    value={formData.bankIfsc}
                    onChange={(e) => setFormData({ ...formData, bankIfsc: e.target.value.toUpperCase() })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-mono uppercase"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">UPI ID for Invoices (e.g. VPA)</label>
                <input
                  type="text"
                  value={formData.upiId}
                  onChange={(e) => setFormData({ ...formData, upiId: e.target.value })}
                  placeholder="business@bank"
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-medium text-emerald-700"
                />
              </div>
            </div>

            {/* Terms and Conditions */}
            <div className="border-t border-slate-200 pt-4">
              <label className="font-semibold text-slate-700 block mb-1">Invoice Terms & Conditions</label>
              <textarea
                value={formData.termsAndConditions}
                onChange={(e) => setFormData({ ...formData, termsAndConditions: e.target.value })}
                rows={3}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2"
              />
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-6 py-2.5 rounded-xl transition cursor-pointer shadow"
              >
                {lang === 'hi' ? 'प्रोफ़ाइल सुरक्षित करें' : 'Save Business Profile'}
              </button>
            </div>
          </form>
        </div>

        {/* Right Column: Preferences, Font Scaling, Backup & Restore */}
        <div className="space-y-6">
          {/* Language & Font Settings Card */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-5 text-xs">
            <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
              <Languages className="w-5 h-5 text-indigo-600" />
              <h3 className="font-bold text-sm text-slate-900">
                {lang === 'hi' ? 'भाषा व फॉन्ट सेटिंग्स' : 'Language & Font Preferences'}
              </h3>
            </div>

            {/* Bilingual Toggle */}
            <div>
              <label className="font-semibold text-slate-700 block mb-2">
                {lang === 'hi' ? 'एप्लिकेशन भाषा (App Language)' : 'Application Language'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => onUpdateLanguage('hi')}
                  className={`p-2.5 rounded-xl font-bold transition cursor-pointer border ${
                    lang === 'hi'
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  हिन्दी (Hindi)
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateLanguage('en')}
                  className={`p-2.5 rounded-xl font-bold transition cursor-pointer border ${
                    lang === 'en'
                      ? 'bg-slate-900 text-white border-slate-900 shadow'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  English
                </button>
              </div>
            </div>

            {/* Font Scaling Settings (With Accessible 30px Option) */}
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <div className="flex justify-between items-center">
                <label className="font-semibold text-slate-700 flex items-center gap-1.5">
                  <Type className="w-4 h-4 text-slate-500" />
                  <span>{lang === 'hi' ? 'फॉन्ट आकार (Font Scaling - Arial)' : 'Font Scale (Default: Arial)'}</span>
                </label>
                <span className="font-mono font-bold text-emerald-700">{Math.round(fontScale * 100)}%</span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => onUpdateFontScale(1)}
                  className={`py-2 px-2 text-center rounded-lg border text-xs font-semibold cursor-pointer transition ${
                    fontScale === 1 ? 'bg-slate-900 text-white border-slate-900' : 'bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  Standard (14px)
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateFontScale(1.3)}
                  className={`py-2 px-2 text-center rounded-lg border text-xs font-semibold cursor-pointer transition ${
                    fontScale === 1.3 ? 'bg-slate-900 text-white border-slate-900' : 'bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  Large (18px)
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateFontScale(1.8)}
                  className={`py-2 px-2 text-center rounded-lg border text-xs font-semibold cursor-pointer transition ${
                    fontScale >= 1.8 ? 'bg-emerald-700 text-white border-emerald-700' : 'bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                  title="30px Accessible Mode"
                >
                  30px Accessible
                </button>
              </div>
              <p className="text-[10px] text-slate-400">
                Default Font: Arial + Hindi Unicode fonts with automatic layout adjustments.
              </p>
            </div>
          </div>

          {/* Backup, Restore & Cloud Sync Card */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4 text-xs">
            <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
              <Database className="w-5 h-5 text-teal-600" />
              <h3 className="font-bold text-sm text-slate-900">
                {lang === 'hi' ? 'बैकअप, रीस्टोर व क्लाउड सिंक' : 'Backup, Restore & Cloud Sync'}
              </h3>
            </div>

            {/* Cloud Sync Section */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex justify-between items-center">
                <span className="font-bold text-slate-800 flex items-center gap-1.5">
                  <Cloud className="w-4 h-4 text-emerald-600" />
                  <span>Shared Database Sync</span>
                </span>
                <button
                  onClick={handleManualSync}
                  disabled={isSyncing}
                  className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 rounded-lg font-bold text-[11px] cursor-pointer"
                >
                  <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>Sync</span>
                </button>
              </div>
              <p className="text-[11px] text-slate-500">{syncStatus}</p>
            </div>

            {/* Backup JSON Download */}
            <div>
              <button
                type="button"
                onClick={handleBackupDownload}
                className="w-full flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 rounded-xl transition cursor-pointer shadow"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'hi' ? 'पूरा व्यापार डेटा बैकअप लें (.json)' : 'Export Complete Business Backup (.json)'}</span>
              </button>
            </div>

            {/* Restore JSON Upload */}
            <div className="pt-2 border-t border-slate-100">
              <label className="w-full flex items-center justify-center gap-2 border-2 border-dashed border-slate-300 hover:border-emerald-500 hover:bg-emerald-50/30 text-slate-700 font-bold py-2.5 rounded-xl transition cursor-pointer">
                <Upload className="w-4 h-4 text-slate-500" />
                <span>{lang === 'hi' ? 'बैकअप फ़ाइल रीस्टोर करें' : 'Restore from JSON File'}</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleRestoreUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
