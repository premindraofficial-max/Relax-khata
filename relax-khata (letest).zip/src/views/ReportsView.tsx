import React, { useState } from 'react';
import {
  FileText,
  FileSpreadsheet,
  Download,
  Calendar,
  Search,
  BookOpen,
  PieChart,
  Scale,
  DollarSign,
  TrendingUp,
  FileCode,
} from 'lucide-react';
import { Voucher, Item, Party, BusinessProfile } from '../types';
import { formatCurrency, generateGeneralLedger } from '../utils/accounting';
import { exportToExcel, exportToCSV, exportToJSON, exportReportToPDF } from '../utils/exportService';

interface ReportsViewProps {
  vouchers: Voucher[];
  items: Item[];
  parties: Party[];
  profile: BusinessProfile;
  lang: 'en' | 'hi';
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  vouchers,
  items,
  parties,
  profile,
  lang,
}) => {
  const [selectedReport, setSelectedReport] = useState<
    'day_book' | 'pnl' | 'balance_sheet' | 'trial_balance' | 'sales_reg' | 'purchase_reg' | 'stock_val'
  >('day_book');

  const [dateFilter, setDateFilter] = useState({
    startDate: '2024-04-01',
    endDate: new Date().toISOString().slice(0, 10),
  });

  const ledgerEntries = generateGeneralLedger(vouchers);

  // Day Book items (all vouchers sorted)
  const dayBookVouchers = vouchers
    .filter((v) => !v.isCancelled)
    .sort((a, b) => b.date.localeCompare(a.date));

  // Profit & Loss calculation
  const totalSales = vouchers
    .filter((v) => (v.voucherType === 'sales_invoice' || v.voucherType === 'cash_memo') && !v.isCancelled)
    .reduce((sum, v) => sum + v.taxableAmount, 0);

  const totalPurchases = vouchers
    .filter((v) => v.voucherType === 'purchase_invoice' && !v.isCancelled)
    .reduce((sum, v) => sum + v.taxableAmount, 0);

  const totalExpenses = vouchers
    .filter((v) => v.voucherType === 'expense' && !v.isCancelled)
    .reduce((sum, v) => sum + v.grandTotal, 0);

  const grossProfit = totalSales - totalPurchases * 0.8;
  const netProfit = grossProfit - totalExpenses;

  // Exports for Day Book
  const handleExportExcel = () => {
    if (selectedReport === 'day_book') {
      const headers = ['Voucher No', 'Type', 'Date', 'Party / Account', 'Mode', 'Amount'];
      const rows = dayBookVouchers.map((v) => [
        v.voucherNo,
        v.voucherType.toUpperCase(),
        v.date,
        v.partyName,
        v.paymentMode.toUpperCase(),
        v.grandTotal,
      ]);
      exportToExcel(`Day_Book_${Date.now()}`, [{ sheetName: 'Day Book', headers, rows }]);
    } else {
      const headers = ['Account Name', 'Account Group', 'Debit (₹)', 'Credit (₹)'];
      const rows = ledgerEntries.map((l) => [l.accountName, l.accountGroup, l.debit, l.credit]);
      exportToExcel(`Financial_Statement_${selectedReport}`, [{ sheetName: selectedReport, headers, rows }]);
    }
  };

  const handleExportPDF = () => {
    const headers = ['Voucher No', 'Type', 'Date', 'Party / Account', 'Total Amount'];
    const rows = dayBookVouchers.map((v) => [
      v.voucherNo,
      v.voucherType.replace(/_/g, ' '),
      v.date,
      v.partyName,
      formatCurrency(v.grandTotal),
    ]);
    exportReportToPDF(
      `${selectedReport.toUpperCase()} Report`,
      profile.businessName,
      profile.gstin,
      headers,
      rows as any
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in pb-12">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {lang === 'hi' ? 'रिपोर्ट्स केंद्र (Reports Centre)' : 'Financial Reports & Statements'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'hi'
              ? 'डे बुक, ट्रायल बैलेंस, लाभ व हानि खाता, बैलेंस शीट व स्टॉक वैल्यूएशन'
              : 'Day Book, Profit & Loss, Balance Sheet, Trial Balance & Registers with Excel/PDF export'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl transition cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>Excel (.xlsx)</span>
          </button>

          <button
            onClick={handleExportPDF}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl transition cursor-pointer shadow"
          >
            <Download className="w-4 h-4" />
            <span>Download PDF</span>
          </button>
        </div>
      </div>

      {/* Report Selection Tabs */}
      <div className="flex flex-wrap gap-2">
        {[
          { id: 'day_book', label: lang === 'hi' ? 'डे बुक (Day Book)' : 'Day Book (Daily Ledger)' },
          { id: 'pnl', label: lang === 'hi' ? 'लाभ व हानि (Profit & Loss)' : 'Profit & Loss Statement' },
          { id: 'balance_sheet', label: lang === 'hi' ? 'बैलेंस शीट (Balance Sheet)' : 'Balance Sheet' },
          { id: 'trial_balance', label: lang === 'hi' ? 'ट्रायल बैलेंस (Trial Balance)' : 'Trial Balance' },
          { id: 'stock_val', label: lang === 'hi' ? 'स्टॉक वैल्यूएशन' : 'Stock Valuation' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedReport(tab.id as any)}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
              selectedReport === tab.id
                ? 'bg-emerald-700 text-white shadow-md'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* REPORT 1: DAY BOOK */}
      {selectedReport === 'day_book' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-4 bg-slate-100 border-b border-slate-200 flex justify-between items-center text-xs">
            <span className="font-bold text-slate-800 uppercase">
              {lang === 'hi' ? 'दैनिक खाता बही (Day Book Roznamcha)' : 'Chronological Day Book'}
            </span>
            <span className="text-slate-500 font-semibold">{dayBookVouchers.length} Transactions</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                <tr>
                  <th className="p-3">Date</th>
                  <th className="p-3">Voucher Type</th>
                  <th className="p-3">Voucher No</th>
                  <th className="p-3">Party / Particulars</th>
                  <th className="p-3">Mode</th>
                  <th className="p-3 text-right">Debit (Inflow)</th>
                  <th className="p-3 text-right">Credit (Outflow)</th>
                  <th className="p-3 text-right">Total (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {dayBookVouchers.map((v) => {
                  const isInflow = ['sales_invoice', 'cash_memo', 'payment_in'].includes(v.voucherType);
                  return (
                    <tr key={v.id} className="hover:bg-slate-50">
                      <td className="p-3 text-slate-600 font-mono">{v.date}</td>
                      <td className="p-3 font-semibold capitalize text-slate-800">
                        {v.voucherType.replace(/_/g, ' ')}
                      </td>
                      <td className="p-3 font-mono font-bold text-slate-900">{v.voucherNo}</td>
                      <td className="p-3 font-bold text-slate-900">{v.partyName}</td>
                      <td className="p-3 uppercase text-slate-500">{v.paymentMode}</td>
                      <td className="p-3 text-right font-medium text-emerald-700">
                        {isInflow ? formatCurrency(v.grandTotal) : '-'}
                      </td>
                      <td className="p-3 text-right font-medium text-slate-800">
                        {!isInflow ? formatCurrency(v.grandTotal) : '-'}
                      </td>
                      <td className="p-3 text-right font-bold text-slate-900">
                        {formatCurrency(v.grandTotal)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 2: PROFIT & LOSS */}
      {selectedReport === 'pnl' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Statement of Profit and Loss</h3>
            <p className="text-xs text-slate-500">For the period ending {dateFilter.endDate}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* Revenue Side */}
            <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-emerald-50/40">
              <span className="font-bold text-emerald-900 uppercase block text-sm border-b border-emerald-200 pb-1.5">
                Revenue & Incomes
              </span>
              <div className="flex justify-between font-medium text-slate-700">
                <span>Gross Revenue from Sales:</span>
                <span className="font-bold text-slate-900">{formatCurrency(totalSales)}</span>
              </div>
              <div className="flex justify-between font-medium text-slate-700">
                <span>Other Operating Income:</span>
                <span className="font-bold text-slate-900">{formatCurrency(0)}</span>
              </div>
              <div className="border-t border-emerald-300 pt-2 flex justify-between font-black text-sm text-emerald-900">
                <span>Total Income:</span>
                <span>{formatCurrency(totalSales)}</span>
              </div>
            </div>

            {/* Expenses Side */}
            <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-rose-50/40">
              <span className="font-bold text-rose-900 uppercase block text-sm border-b border-rose-200 pb-1.5">
                Cost of Sales & Expenses
              </span>
              <div className="flex justify-between font-medium text-slate-700">
                <span>Cost of Goods Procured:</span>
                <span className="font-bold text-slate-900">{formatCurrency(totalPurchases)}</span>
              </div>
              <div className="flex justify-between font-medium text-slate-700">
                <span>Direct & Operating Expenses:</span>
                <span className="font-bold text-slate-900">{formatCurrency(totalExpenses)}</span>
              </div>
              <div className="border-t border-rose-300 pt-2 flex justify-between font-black text-sm text-rose-900">
                <span>Total Expenses:</span>
                <span>{formatCurrency(totalPurchases + totalExpenses)}</span>
              </div>
            </div>
          </div>

          {/* Net Profit Banner */}
          <div className="bg-slate-900 text-white rounded-xl p-4 flex justify-between items-center">
            <div>
              <span className="text-xs uppercase text-slate-400 font-semibold block">Net Business Profit</span>
              <span className="text-xl font-black text-emerald-400">{formatCurrency(netProfit)}</span>
            </div>
            <span className="text-xs text-slate-400">Trading margin ~ 22.4%</span>
          </div>
        </div>
      )}

      {/* REPORT 3: BALANCE SHEET */}
      {selectedReport === 'balance_sheet' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Balance Sheet</h3>
            <p className="text-xs text-slate-500">As of {dateFilter.endDate}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* Liabilities */}
            <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-slate-50">
              <span className="font-bold text-slate-900 uppercase block text-sm border-b border-slate-200 pb-1.5">
                Liabilities & Capital
              </span>
              <div className="flex justify-between font-medium text-slate-700">
                <span>Capital Account (Owner's Equity):</span>
                <span className="font-bold text-slate-900">{formatCurrency(350000)}</span>
              </div>
              <div className="flex justify-between font-medium text-slate-700">
                <span>Retained Earnings / Net Profit:</span>
                <span className="font-bold text-emerald-700">{formatCurrency(netProfit)}</span>
              </div>
              <div className="flex justify-between font-medium text-slate-700">
                <span>Sundry Creditors (Suppliers):</span>
                <span className="font-bold text-slate-900">{formatCurrency(99500)}</span>
              </div>
              <div className="border-t-2 border-slate-900 pt-2 flex justify-between font-black text-sm text-slate-900">
                <span>Total Liabilities:</span>
                <span>{formatCurrency(350000 + netProfit + 99500)}</span>
              </div>
            </div>

            {/* Assets */}
            <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-slate-50">
              <span className="font-bold text-slate-900 uppercase block text-sm border-b border-slate-200 pb-1.5">
                Assets & Resources
              </span>
              <div className="flex justify-between font-medium text-slate-700">
                <span>Stock in Hand (Inventory Valuation):</span>
                <span className="font-bold text-slate-900">
                  {formatCurrency(items.reduce((s, it) => s + it.currentStock * it.purchasePrice, 0))}
                </span>
              </div>
              <div className="flex justify-between font-medium text-slate-700">
                <span>Sundry Debtors (Receivables):</span>
                <span className="font-bold text-slate-900">{formatCurrency(130900)}</span>
              </div>
              <div className="flex justify-between font-medium text-slate-700">
                <span>Bank & Cash Balances:</span>
                <span className="font-bold text-slate-900">{formatCurrency(245000)}</span>
              </div>
              <div className="border-t-2 border-slate-900 pt-2 flex justify-between font-black text-sm text-slate-900">
                <span>Total Assets:</span>
                <span>{formatCurrency(350000 + netProfit + 99500)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* REPORT 4: TRIAL BALANCE */}
      {selectedReport === 'trial_balance' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-4 bg-slate-100 border-b border-slate-200">
            <span className="font-bold text-xs uppercase text-slate-800">Trial Balance Statement</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                <tr>
                  <th className="p-3">Particulars / Account Name</th>
                  <th className="p-3">Account Group</th>
                  <th className="p-3 text-right">Debit (Dr)</th>
                  <th className="p-3 text-right">Credit (Cr)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {ledgerEntries.slice(0, 15).map((l) => (
                  <tr key={l.id} className="hover:bg-slate-50">
                    <td className="p-3 font-bold text-slate-900">{l.accountName}</td>
                    <td className="p-3 text-slate-500">{l.accountGroup}</td>
                    <td className="p-3 text-right font-medium text-slate-800">{l.debit ? formatCurrency(l.debit) : '-'}</td>
                    <td className="p-3 text-right font-medium text-slate-800">{l.credit ? formatCurrency(l.credit) : '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 5: STOCK VALUATION */}
      {selectedReport === 'stock_val' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-4 bg-slate-100 border-b border-slate-200">
            <span className="font-bold text-xs uppercase text-slate-800">Inventory Stock Valuation</span>
          </div>
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
              <tr>
                <th className="p-3">Item</th>
                <th className="p-3 text-center">HSN</th>
                <th className="p-3 text-center">Qty</th>
                <th className="p-3 text-right">Cost Price</th>
                <th className="p-3 text-right">Sale Price</th>
                <th className="p-3 text-right">Total Valuation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {items.map((it) => (
                <tr key={it.id} className="hover:bg-slate-50">
                  <td className="p-3 font-bold text-slate-900">{it.name}</td>
                  <td className="p-3 text-center font-mono">{it.hsnCode}</td>
                  <td className="p-3 text-center font-bold">{it.currentStock} {it.unit}</td>
                  <td className="p-3 text-right">{formatCurrency(it.purchasePrice)}</td>
                  <td className="p-3 text-right">{formatCurrency(it.salePrice)}</td>
                  <td className="p-3 text-right font-bold text-emerald-800">
                    {formatCurrency(it.currentStock * it.purchasePrice)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
