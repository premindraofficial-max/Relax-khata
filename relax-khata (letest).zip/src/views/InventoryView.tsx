import React, { useState } from 'react';
import {
  Plus,
  Package,
  AlertTriangle,
  FileSpreadsheet,
  Search,
  Barcode,
  Layers,
  ArrowUpDown,
  Edit2,
  Trash2,
  X,
  CheckCircle,
} from 'lucide-react';
import { Item } from '../types';
import { formatCurrency, formatNumber } from '../utils/accounting';
import { exportToExcel, exportToCSV } from '../utils/exportService';

interface InventoryViewProps {
  items: Item[];
  onSaveItem: (item: Item) => void;
  onDeleteItem: (id: string) => void;
  lang: 'en' | 'hi';
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  items,
  onSaveItem,
  onDeleteItem,
  lang,
}) => {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Item | null>(null);

  // Stock Adjustment Modal
  const [adjustingItem, setAdjustingItem] = useState<Item | null>(null);
  const [adjustQty, setAdjustQty] = useState(0);

  const categories = Array.from(new Set(items.map((i) => i.category)));

  const filteredItems = items.filter((item) => {
    if (categoryFilter !== 'all' && item.category !== categoryFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        item.name.toLowerCase().includes(q) ||
        item.hsnCode.includes(q) ||
        (item.barcode && item.barcode.includes(q)) ||
        (item.batchNo && item.batchNo.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const totalStockValue = items.reduce((sum, it) => sum + Math.max(0, it.currentStock) * it.purchasePrice, 0);
  const lowStockItems = items.filter((it) => it.currentStock <= it.minStockAlert);

  const handleOpenAdd = () => {
    setEditingItem({
      id: `item-${Date.now()}`,
      name: '',
      category: categories[0] || 'General',
      unit: 'PCS',
      hsnCode: '8528',
      gstRate: 18,
      purchasePrice: 1000,
      salePrice: 1300,
      wholesalePrice: 1200,
      retailPrice: 1350,
      openingStock: 10,
      currentStock: 10,
      minStockAlert: 5,
      negativeStockAllowed: false,
      batchNo: `B-${new Date().getFullYear()}`,
      barcode: String(Math.floor(1000000000000 + Math.random() * 9000000000000)),
      updatedAt: new Date().toISOString().slice(0, 10),
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (it: Item) => {
    setEditingItem(it);
    setIsModalOpen(true);
  };

  const handleSaveModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingItem && editingItem.name.trim()) {
      onSaveItem(editingItem);
      setIsModalOpen(false);
    }
  };

  const handleStockAdjustSubmit = () => {
    if (adjustingItem) {
      const updated: Item = {
        ...adjustingItem,
        currentStock: Math.max(0, adjustingItem.currentStock + adjustQty),
        updatedAt: new Date().toISOString().slice(0, 10),
      };
      onSaveItem(updated);
      setAdjustingItem(null);
      setAdjustQty(0);
    }
  };

  const handleExportExcel = () => {
    const headers = ['Product Name', 'Category', 'HSN Code', 'GST %', 'Purchase Price', 'Sale Price', 'Current Stock', 'Unit', 'Stock Value', 'Min Alert'];
    const rows = filteredItems.map((i) => [
      i.name,
      i.category,
      i.hsnCode,
      i.gstRate,
      i.purchasePrice,
      i.salePrice,
      i.currentStock,
      i.unit,
      i.currentStock * i.purchasePrice,
      i.minStockAlert,
    ]);
    exportToExcel(`Stock_Report_${Date.now()}`, [{ sheetName: 'Inventory Valuation', headers, rows }]);
  };

  const handleExportCSV = () => {
    const headers = ['Product', 'Category', 'HSN', 'GST Rate', 'Cost', 'Sale Price', 'Stock', 'Unit', 'Value'];
    const rows = filteredItems.map((i) => [
      i.name,
      i.category,
      i.hsnCode,
      i.gstRate,
      i.purchasePrice,
      i.salePrice,
      i.currentStock,
      i.unit,
      i.currentStock * i.purchasePrice,
    ]);
    exportToCSV(`Stock_Valuation_${Date.now()}`, headers, rows);
  };

  return (
    <div className="space-y-5 animate-in fade-in pb-12">
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {lang === 'hi' ? 'इन्वेंटरी और स्टॉक प्रबंधन' : 'Inventory & Stock Valuation'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'hi'
              ? 'HSN कोड, GST दरें, बैच नंबर, बारकोड व स्टॉक समायोजन'
              : 'HSN/SAC Classification, Tax Rates, Batch & Expiry, Barcodes and Multi-tier Pricing'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition cursor-pointer shadow"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'hi' ? '+ नया उत्पाद जोड़ें' : '+ Add Product'}</span>
          </button>

          <button
            onClick={handleExportExcel}
            className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition border border-slate-200 cursor-pointer"
            title="Export to Excel"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
          </button>
          <button
            onClick={handleExportCSV}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition border border-slate-200 cursor-pointer text-xs font-bold"
            title="Export CSV"
          >
            CSV
          </button>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
          <span className="text-xs font-semibold text-emerald-800 uppercase">
            {lang === 'hi' ? 'कुल स्टॉक मूल्य (Godown Value)' : 'Total Stock Valuation'}
          </span>
          <div className="text-xl md:text-2xl font-black text-emerald-950 mt-1">
            {formatCurrency(totalStockValue)}
          </div>
          <span className="text-[11px] text-emerald-700">Calculated at purchase price</span>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
          <span className="text-xs font-semibold text-slate-600 uppercase">
            {lang === 'hi' ? 'कुल उत्पाद किस्में' : 'Active Items / SKUs'}
          </span>
          <div className="text-xl md:text-2xl font-black text-slate-900 mt-1">
            {items.length}
          </div>
          <span className="text-[11px] text-slate-500">{categories.length} Categories</span>
        </div>

        <div className="bg-rose-50 border border-rose-200 rounded-xl p-4">
          <span className="text-xs font-semibold text-rose-800 uppercase flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
            {lang === 'hi' ? 'कम स्टॉक अलर्ट' : 'Low Stock Alerts'}
          </span>
          <div className="text-xl md:text-2xl font-black text-rose-950 mt-1">
            {lowStockItems.length}
          </div>
          <span className="text-[11px] text-rose-700">Below minimum safety threshold</span>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-3">
        <div className="flex flex-wrap gap-1 w-full md:w-auto">
          <button
            onClick={() => setCategoryFilter('all')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
              categoryFilter === 'all' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {lang === 'hi' ? 'सभी श्रेणियां' : 'All Categories'}
          </button>
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCategoryFilter(c)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
                categoryFilter === c ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 w-full md:w-72 bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs">
          <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={lang === 'hi' ? 'आइटम नाम, HSN, बारकोड खोजें...' : 'Search item, HSN, barcode...'}
            className="w-full bg-transparent border-none outline-none text-slate-800"
          />
        </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-100 border-b border-slate-200 text-slate-600 font-semibold uppercase">
              <tr>
                <th className="p-3">Product Name</th>
                <th className="p-3">Category</th>
                <th className="p-3 text-center">HSN</th>
                <th className="p-3 text-center">GST %</th>
                <th className="p-3 text-right">Cost Price</th>
                <th className="p-3 text-right">Sale Price</th>
                <th className="p-3 text-center">Available Stock</th>
                <th className="p-3 text-right">Stock Value</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredItems.map((item) => {
                const isLow = item.currentStock <= item.minStockAlert;
                const value = Math.max(0, item.currentStock) * item.purchasePrice;
                const profitMargin = Math.round(
                  ((item.salePrice - item.purchasePrice) / item.purchasePrice) * 100
                );

                return (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition">
                    <td className="p-3">
                      <div className="font-bold text-slate-900 text-sm">{item.name}</div>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                        {item.batchNo && <span>Batch: {item.batchNo}</span>}
                        {item.barcode && <span className="font-mono">Barcode: {item.barcode}</span>}
                      </div>
                    </td>
                    <td className="p-3">
                      <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[10px] font-medium">
                        {item.category}
                      </span>
                    </td>
                    <td className="p-3 text-center font-mono font-bold text-slate-700">{item.hsnCode}</td>
                    <td className="p-3 text-center font-bold text-emerald-700">{item.gstRate}%</td>
                    <td className="p-3 text-right font-medium">{formatCurrency(item.purchasePrice)}</td>
                    <td className="p-3 text-right font-bold text-slate-900">
                      <div>{formatCurrency(item.salePrice)}</div>
                      <div className="text-[10px] text-emerald-600 font-medium">+{profitMargin}% Margin</div>
                    </td>
                    <td className="p-3 text-center">
                      <div className="inline-flex items-center gap-1.5">
                        <span
                          className={`font-black text-sm px-2.5 py-0.5 rounded-lg ${
                            isLow ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-900'
                          }`}
                        >
                          {item.currentStock} {item.unit}
                        </span>
                        {isLow && <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />}
                      </div>
                    </td>
                    <td className="p-3 text-right font-bold text-slate-900">
                      {formatCurrency(value)}
                    </td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setAdjustingItem(item);
                            setAdjustQty(0);
                          }}
                          className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition cursor-pointer"
                          title="Stock Adjustment (+/-)"
                        >
                          <ArrowUpDown className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleOpenEdit(item)}
                          className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition cursor-pointer"
                          title="Edit Item"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onDeleteItem(item.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                          title="Delete Item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {isModalOpen && editingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <form
            onSubmit={handleSaveModal}
            className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]"
          >
            <div className="p-4 bg-slate-900 text-white flex justify-between items-center shrink-0">
              <h3 className="font-bold text-base">
                {editingItem.id.startsWith('item-new') || !items.some((i) => i.id === editingItem.id)
                  ? lang === 'hi' ? 'नया उत्पाद जोड़ें' : 'Add New Product'
                  : lang === 'hi' ? 'उत्पाद संपादित करें' : 'Edit Product'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  {lang === 'hi' ? 'उत्पाद का नाम *' : 'Product / Item Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={editingItem.name}
                  onChange={(e) => setEditingItem({ ...editingItem, name: e.target.value })}
                  placeholder="e.g. LED Smart Android TV 43 Inch"
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 font-bold text-slate-900"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'श्रेणी (Category)' : 'Category'}
                  </label>
                  <input
                    type="text"
                    value={editingItem.category}
                    onChange={(e) => setEditingItem({ ...editingItem, category: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'इकाई (Unit)' : 'Unit of Measurement'}
                  </label>
                  <select
                    value={editingItem.unit}
                    onChange={(e) => setEditingItem({ ...editingItem, unit: e.target.value as any })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-semibold"
                  >
                    <option value="PCS">PCS (Pieces)</option>
                    <option value="BOX">BOX (Cartons)</option>
                    <option value="KG">KG (Kilograms)</option>
                    <option value="MTR">MTR (Meters)</option>
                    <option value="LTR">LTR (Liters)</option>
                    <option value="SET">SET (Cookware/Tools)</option>
                    <option value="BAG">BAG (Rice/Grains)</option>
                    <option value="PACK">PACK (Bundles)</option>
                    <option value="NOS">NOS (Numbers)</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'HSN / SAC कोड *' : 'HSN / SAC Code *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={editingItem.hsnCode}
                    onChange={(e) => setEditingItem({ ...editingItem, hsnCode: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'GST टैक्स दर (%)' : 'GST Rate (%)'}
                  </label>
                  <select
                    value={editingItem.gstRate}
                    onChange={(e) => setEditingItem({ ...editingItem, gstRate: parseInt(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-bold text-emerald-700"
                  >
                    <option value="0">0% (Nil / Exempt)</option>
                    <option value="5">5% GST</option>
                    <option value="12">12% GST</option>
                    <option value="18">18% GST (Standard)</option>
                    <option value="28">28% GST</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'खरीद दर (Cost Price)' : 'Purchase Price (₹)'}
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={editingItem.purchasePrice}
                    onChange={(e) => setEditingItem({ ...editingItem, purchasePrice: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-medium"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'बिक्री दर (Sale Price)' : 'Sale Price (₹)'}
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={editingItem.salePrice}
                    onChange={(e) => setEditingItem({ ...editingItem, salePrice: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'वर्तमान स्टॉक' : 'Current Stock Qty'}
                  </label>
                  <input
                    type="number"
                    value={editingItem.currentStock}
                    onChange={(e) => setEditingItem({ ...editingItem, currentStock: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-bold text-emerald-700"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'कम स्टॉक चेतावनी (Alert)' : 'Min Alert Qty'}
                  </label>
                  <input
                    type="number"
                    value={editingItem.minStockAlert}
                    onChange={(e) => setEditingItem({ ...editingItem, minStockAlert: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'बैच संख्या (Batch No)' : 'Batch No'}
                  </label>
                  <input
                    type="text"
                    value={editingItem.batchNo || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, batchNo: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2"
                  />
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 border border-slate-300 hover:bg-slate-100 rounded-xl font-semibold text-slate-700 cursor-pointer"
              >
                {lang === 'hi' ? 'रद्द करें' : 'Cancel'}
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold cursor-pointer shadow"
              >
                {lang === 'hi' ? 'उत्पाद सुरक्षित करें' : 'Save Product'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Stock Adjustment Modal */}
      {adjustingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-sm w-full p-5 space-y-4">
            <h4 className="font-bold text-slate-900 text-base">
              {lang === 'hi' ? 'स्टॉक समायोजन (Adjustment)' : 'Stock Adjustment'}
            </h4>
            <p className="text-xs text-slate-500">
              {adjustingItem.name} (Current: <strong>{adjustingItem.currentStock} {adjustingItem.unit}</strong>)
            </p>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                {lang === 'hi' ? 'जोड़ें (+) या घटाएं (-)' : 'Adjustment Quantity (+/-)'}
              </label>
              <input
                type="number"
                value={adjustQty}
                onChange={(e) => setAdjustQty(parseFloat(e.target.value) || 0)}
                placeholder="e.g. +5 or -2"
                className="w-full text-center text-xl font-bold py-2 bg-slate-50 border border-slate-300 rounded-xl"
              />
              <span className="text-[11px] text-slate-400 mt-1 block text-center">
                New Stock will be: <strong>{Math.max(0, adjustingItem.currentStock + adjustQty)} {adjustingItem.unit}</strong>
              </span>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setAdjustingItem(null)}
                className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleStockAdjustSubmit}
                className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-bold cursor-pointer shadow"
              >
                Apply Adjustment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
