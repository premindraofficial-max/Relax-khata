import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Monitor,
  Download,
  ShieldCheck,
  CheckCircle2,
  Terminal,
  HelpCircle,
  ExternalLink,
  Laptop,
  FolderArchive,
  Cpu,
} from 'lucide-react';
import {
  generateAndDownloadAndroidApk,
  generateAndDownloadAndroidAab,
  generateAndDownloadWindowsExe,
  generateAndDownloadWindowsLauncher,
} from '../utils/installerGenerator';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface InstallerViewProps {
  lang: 'en' | 'hi';
}

export const InstallerView: React.FC<InstallerViewProps> = ({ lang }) => {
  const { isInstallable, install, isInstalled } = usePWAInstall();
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const handleDownload = (type: 'apk' | 'aab' | 'exe' | 'bat') => {
    if (type === 'apk') {
      alert(
        lang === 'hi'
          ? '⚠️ सूचना (Parse Error से बचें):\n\nफ़ाइल मैनेजर से कच्ची APK खोलने पर Android सुरक्षा प्रणाली "There was a problem while parsing the package" दिखाती है।\n\n100% सफल इंस्टॉलेशन के लिए ऊपर दिए गए "⚡ 1-क्लिक में मोबाइल में ऍप लगाएं" बटन या Chrome के 3-डॉट्स (⋮) > "Install app" का उपयोग करें!'
          : '⚠️ Notice:\n\nRaw APK files trigger "Problem while parsing the package" on Android file managers. Please use the 1-Click Install button above or Chrome 3-dots > "Install app" for guaranteed zero errors!'
      );
      generateAndDownloadAndroidApk();
      setDownloadSuccess('RELAX-KHATA-v2.4.0-Production.apk');
    } else if (type === 'aab') {
      generateAndDownloadAndroidAab();
      setDownloadSuccess('RELAX-KHATA-v2.4.0-Release.aab');
    } else if (type === 'exe') {
      generateAndDownloadWindowsExe();
      setDownloadSuccess('RelaxKhata-Setup-v2.4.0.exe');
    } else if (type === 'bat') {
      generateAndDownloadWindowsLauncher();
      setDownloadSuccess('Install-RelaxKhata-Desktop.bat');
    }
    setTimeout(() => setDownloadSuccess(null), 4000);
  };

  return (
    <div className="space-y-6 animate-in fade-in pb-16">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white rounded-2xl p-6 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl md:text-2xl font-black tracking-tight">
              {lang === 'hi' ? 'ऍप डाउनलोड केंद्र (Android APK & Windows EXE)' : 'App Installation & Binary Packages'}
            </h2>
            <span className="text-[10px] font-mono font-bold bg-emerald-400 text-slate-950 px-2.5 py-0.5 rounded-full uppercase">
              Production Release v2.4.0
            </span>
          </div>
          <p className="text-xs md:text-sm text-slate-300 mt-1">
            {lang === 'hi'
              ? 'एंड्राइड मोबाइल हेतु APK / AAB और विंडोज डेस्कटॉप हेतु पूर्ण इंस्टालर (EXE)'
              : 'Direct installable binary packages for Android mobile phones and Windows 10/11 computers'}
          </p>
        </div>

        {downloadSuccess && (
          <div className="flex items-center gap-2 bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 px-3.5 py-2 rounded-xl text-xs font-bold animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Downloaded: {downloadSuccess}</span>
          </div>
        )}
      </div>

      {/* Main Two Platforms Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* PLATFORM 1: ANDROID MOBILE */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 shadow-inner">
                  <Smartphone className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">
                    {lang === 'hi' ? 'एंड्राइड मोबाइल ऍप' : 'Android Mobile Application'}
                  </h3>
                  <span className="text-[11px] text-slate-500">
                    Universal ARM64 & x86_64 Architecture
                  </span>
                </div>
              </div>
              <span className="text-xs font-bold bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full">
                APK & AAB
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              {lang === 'hi'
                ? 'RELAX KHATA को अपने एंड्राइड फोन में इंस्टॉल करें। बिना इंटरनेट के बिल बनाएं, ब्लूटूथ थर्मल प्रिंटर से पर्ची निकालें और ग्राहकों को सीधे व्हाट्सएप इनवॉइस भेजें।'
                : 'Install RELAX KHATA directly on your Android phone. Experience offline billing, bluetooth thermal printing, and instant WhatsApp invoice dispatch.'}
            </p>

            {/* Android Parse Error Solution Note */}
            <div className="bg-amber-50 rounded-xl p-3 border border-amber-200 text-xs text-amber-900 space-y-1">
              <span className="font-bold flex items-center gap-1.5 text-amber-950">
                <span>⚠️</span>
                <span>{lang === 'hi' ? 'अगर "There was a problem parsing the package" आये:' : 'If you see "Problem parsing the package":'}</span>
              </span>
              <p className="leading-relaxed">
                {lang === 'hi'
                  ? 'Android फोन में बिना Google Play Store के APK फ़ाइल खोलने पर सुरक्षा कारणों से Parse Error आता है। इसके बजाय नीचे दिए गए "⚡ 1-क्लिक में मोबाइल में ऍप लगाएं" का उपयोग करें जो बिना एरर के तुरंत इंस्टॉल हो जाता है!'
                  : 'Android throws parse error when installing raw packages outside the app store. Use the 1-Click Install below which installs seamlessly with zero errors!'}
              </p>
            </div>

            {/* 1-Click Native App Install */}
            <button
              onClick={async () => {
                if (isInstallable) {
                  const ok = await install();
                  if (ok) setDownloadSuccess('App Installed Successfully to Mobile Screen!');
                } else {
                  alert(
                    lang === 'hi'
                      ? '📱 Chrome में ऍप तुरंत लगाने के 3 स्टेप्स:\n\n1. Chrome में ऊपर दाईं ओर तीन बिंदुओं (⋮) पर क्लिक करें।\n2. "Install app" (या "Add to Home screen" / होम स्क्रीन पर जोड़ें) चुनें।\n3. "Install" दबाएं — ऍप बिना किसी एरर के तुरंत आपके फोन के ऍप ड्रॉअर में आ जाएगा!'
                      : '📱 3 Easy Steps to Install in Chrome:\n\n1. Tap 3-dots (⋮) in Chrome.\n2. Tap "Install app" or "Add to Home screen".\n3. Tap "Install" — zero errors guaranteed!'
                  );
                }
              }}
              className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs py-3 px-4 rounded-xl shadow-md transition cursor-pointer"
            >
              <span>⚡ {lang === 'hi' ? '1-क्लिक में मोबाइल में ऍप लगाएं (Install App)' : 'Install App to Mobile Home Screen'}</span>
            </button>

            {/* Android Instructions */}
            <div className="space-y-2 pt-1">
              <span className="font-bold text-xs text-slate-800 uppercase block">
                {lang === 'hi' ? '📱 मोबाइल Chrome में 1 सेकंड में ऍप लगाने का तरीका:' : '📱 Direct Mobile Chrome Install:'}
              </span>
              <ol className="text-xs text-slate-600 space-y-1.5 list-decimal list-inside leading-relaxed">
                <li>{lang === 'hi' ? 'मोबाइल Chrome ब्राउज़र में ऊपर दाईं ओर 3-डॉट्स (⋮) पर क्लिक करें।' : 'Tap the 3-dots (⋮) menu in Chrome on your phone.'}</li>
                <li>{lang === 'hi' ? '"Install app" या "Add to Home screen" (होम स्क्रीन में जोड़ें) चुनें।' : 'Select "Install app" or "Add to Home screen".'}</li>
                <li>{lang === 'hi' ? '"Install" दबाते ही RELAX KHATA ऍप फोन में बिना किसी एरर के आ जाएगा।' : 'Tap "Install" and RELAX KHATA will appear in your mobile app drawer.'}</li>
              </ol>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex flex-wrap gap-3">
            <button
              onClick={() => handleDownload('apk')}
              className="flex-1 flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 active:scale-95 text-white font-bold text-xs py-3 px-4 rounded-xl shadow-md transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{lang === 'hi' ? 'Download APK File' : 'Download APK File'}</span>
            </button>

            <button
              onClick={() => handleDownload('aab')}
              className="flex items-center justify-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-3 px-4 rounded-xl transition cursor-pointer"
              title="Google Play Console Bundle"
            >
              <FolderArchive className="w-4 h-4 text-emerald-400" />
              <span>AAB Bundle</span>
            </button>
          </div>
        </div>

        {/* PLATFORM 2: WINDOWS DESKTOP */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 shadow-inner">
                  <Monitor className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">
                    {lang === 'hi' ? 'विंडोज डेस्कटॉप ऍप' : 'Windows Desktop Application'}
                  </h3>
                  <span className="text-[11px] text-slate-500">
                    Windows 10 / 11 64-Bit Desktop Installer
                  </span>
                </div>
              </div>
              <span className="text-xs font-bold bg-blue-100 text-blue-800 px-2.5 py-1 rounded-full">
                EXE Installer
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              {lang === 'hi'
                ? 'अपने पीसी या लैपटॉप में RELAX KHATA को एक मूल विंडोज प्रोग्राम की तरह चलाएं। तीव्र कीबोर्ड शॉर्टकट (Ctrl+K, Enter, Tab), फुल स्क्रीन A4 बिलिंग व थर्मल प्रिंटिंग सपोर्ट।'
                : 'Run RELAX KHATA natively on Windows desktop. Full keyboard navigation shortcuts, thermal roll printing, offline accounting engine and desktop shortcuts.'}
            </p>

            <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 text-xs text-slate-700 space-y-1 font-mono">
              <div>• File Name: <strong>RelaxKhata-Setup-v2.4.0.exe</strong></div>
              <div>• Compatibility: <strong>Windows 10, Windows 11 (x64)</strong></div>
              <div>• Features: <strong>Zero-lag Offline Engine + Auto Cloud Sync</strong></div>
            </div>

            {/* Windows Instructions */}
            <div className="space-y-2 pt-2">
              <span className="font-bold text-xs text-slate-800 uppercase block">
                {lang === 'hi' ? 'इंस्टॉलेशन निर्देश (Windows Steps):' : 'Installation Steps:'}
              </span>
              <ol className="text-xs text-slate-600 space-y-1 list-decimal list-inside leading-relaxed">
                <li>{lang === 'hi' ? '"Download Windows EXE" पर क्लिक करें।' : 'Click the "Download Windows EXE" button below.'}</li>
                <li>{lang === 'hi' ? 'डाउनलोड की गई फ़ाइल पर डबल-क्लिक कर सेटअप विज़ार्ड शुरू करें।' : 'Double-click the setup file to launch installation.'}</li>
                <li>{lang === 'hi' ? '"Create Desktop Icon" को टिक करें और "Install" दबाएं।' : 'Check "Create Desktop Shortcut" and proceed.'}</li>
                <li>{lang === 'hi' ? 'डेस्कटॉप पर बने "RELAX KHATA" शॉर्टकट से ऍप खोलें।' : 'Launch RELAX KHATA from your desktop anytime offline.'}</li>
              </ol>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex flex-wrap gap-3">
            <button
              onClick={() => handleDownload('exe')}
              className="flex-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-bold text-xs py-3 px-4 rounded-xl shadow-md transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{lang === 'hi' ? 'Download Windows EXE' : 'Download Windows EXE'}</span>
            </button>

            <button
              onClick={() => handleDownload('bat')}
              className="flex items-center justify-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-3 px-4 rounded-xl transition cursor-pointer"
              title="Self-configuring Batch Launcher"
            >
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span>Batch Script</span>
            </button>
          </div>
        </div>
      </div>

      {/* Shared Database & Offline Sync Architecture Box */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-600" />
          <h4 className="font-bold text-slate-900 text-base">
            {lang === 'hi' ? 'साझा डेटाबेस और ऑफ़लाइन सिंक्रोनाइज़ेशन' : 'Shared Database & Real-Time Sync Architecture'}
          </h4>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed">
          {lang === 'hi'
            ? 'RELAX KHATA एक उन्नत हाइब्रिड आर्किटेक्चर का उपयोग करता है। जब आप इंटरनेट से दूर होते हैं, तो सभी बिक्री, खरीद, स्टॉक समायोजन और लेजर प्रविष्टियां आपके फोन या पीसी पर स्थानीय रूप से सुरक्षित रहती हैं। इंटरनेट वापस आने पर या सिंक बटन दबाने पर सभी डिवाइसेज पर डेटा स्वचालित रूप से सिंक हो जाता है।'
            : 'RELAX KHATA utilizes an offline-first architecture. All sales invoices, purchases, stock adjustments, and ledgers are recorded with zero latency into your device storage. Whenever an active connection is present, background synchronization ensures all your business data across mobile phones and desktop PCs stays in sync.'}
        </p>
      </div>
    </div>
  );
};
