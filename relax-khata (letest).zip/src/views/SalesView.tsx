import React, { useState } from 'react';
import {
  Plus,
  Printer,
  Download,
  Share2,
  FileSpreadsheet,
  Search,
  Filter,
} from 'lucide-react';
import { Voucher, VoucherType, BusinessProfile } from '../types';
import { formatCurrency } from '../utils/accounting';
import { exportToExcel, exportToCSV, generateWhatsAppShareLink } from '../utils/exportService';

interface SalesViewProps {
  vouchers: Voucher[];
  profile: BusinessProfile;
  onOpenNewVoucher: (type: VoucherType) => void;
  onOpenPreview: (voucher: Voucher) => void;
  onDeleteVoucher: (id: string) => void;
  lang: 'en' | 'hi';
}

export const SalesView: React.FC<SalesViewProps> = ({
  vouchers,
  profile,
  onOpenNewVoucher,
  onOpenPreview,
  lang,
}) => {
  const [subTab, setSubTab] = useState<'all' | 'sales_invoice' | 'cash_memo' | 'quotation' | 'delivery_challan' | 'credit_note'>('all');
  const [search, setSearch] = useState('');

  const salesVouchers = vouchers.filter((v) => {
    const isSale = ['sales_invoice', 'cash_memo', 'quotation', 'proforma_invoice', 'delivery_challan', 'credit_note', 'sales_order'].includes(v.voucherType);
    if (!isSale) return false;
    if (subTab !== 'all' && v.voucherType !== subTab) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        v.voucherNo.toLowerCase().includes(q) ||
        v.partyName.toLowerCase().includes(q) ||
        (v.partyGstin && v.partyGstin.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const totalSalesAmount = salesVouchers.reduce((sum, v) => sum + (v.grandTotal || 0), 0);
  const totalTaxable = salesVouchers.reduce((sum, v) => sum + (v.taxableAmount || 0), 0);
  const totalGst = salesVouchers.reduce((sum, v) => sum + (v.cgst || 0) + (v.sgst || 0) + (v.igst || 0), 0);

  const handleExportExcel = () => {
    const headers = ['Voucher No', 'Type', 'Date', 'Customer Name', 'GSTIN', 'Taxable', 'CGST', 'SGST', 'IGST', 'Grand Total', 'Status', 'Payment'];
    const rows = salesVouchers.map((v) => [
      v.voucherNo,
      v.voucherType.toUpperCase(),
      v.date,
      v.partyName,
      v.partyGstin || 'Unregistered',
      v.taxableAmount,
      v.cgst || 0,
      v.sgst || 0,
      v.igst || 0,
      v.grandTotal,
      v.status.toUpperCase(),
      v.paymentMode.toUpperCase(),
    ]);

    exportToExcel(`Sales_Register_${Date.now()}`, [
      { sheetName: 'Sales Register', headers, rows },
    ]);
  };

  const handleExportCSV = () => {
    const headers = ['Voucher No', 'Type', 'Date', 'Customer Name', 'GSTIN', 'Taxable', 'GST', 'Total', 'Status'];
    const rows = salesVouchers.map((v) => [
      v.voucherNo,
      v.voucherType,
      v.date,
      v.partyName,
      v.partyGstin || '',
      v.taxableAmount,
      (v.cgst || 0) + (v.sgst || 0) + (v.igst || 0),
      v.grandTotal,
      v.status,
    ]);
    exportToCSV(`Sales_Register_${Date.now()}`, headers, rows);
  };

  return (
    <div className="space-y-5 animate-in fade-in pb-12">
      {/* Top Header & Metrics Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {lang === 'hi' ? 'बिक्री और बिलिंग (Sales & Billing)' : 'Sales & Invoicing Centre'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'hi' ? 'GST टैक्स इनवॉइस, कैश मेमो, कोटेशन और चालान' : 'GST Compliant Tax Invoices, Cash Memos, Estimates & Challans'}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onOpenNewVoucher('sales_invoice')}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition cursor-pointer shadow"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'hi' ? 'नया इनवॉइस' : 'New Invoice'}</span>
          </button>

          <button
            onClick={() => onOpenNewVoucher('cash_memo')}
            className="flex items-center gap-1.5 bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl transition cursor-pointer shadow"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'hi' ? 'कैश मेमो' : 'Cash Memo'}</span>
          </button>

          <button
            onClick={() => onOpenNewVoucher('quotation')}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-3 py-2.5 rounded-xl transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'hi' ? 'कोटेशन' : 'Quotation'}</span>
          </button>

          <div className="flex items-center gap-1 border-l border-slate-200 pl-2">
            <button
              onClick={handleExportExcel}
              className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition border border-slate-200 cursor-pointer"
              title="Export to Excel (.xlsx)"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            </button>
            <button
              onClick={handleExportCSV}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition border border-slate-200 cursor-pointer text-xs font-bold"
              title="Export to CSV"
            >
              CSV
            </button>
          </div>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
          <span className="text-xs font-semibold text-emerald-800 uppercase">
            {lang === 'hi' ? 'कुल बिक्री मूल्य' : 'Total Invoiced Sales'}
          </span>
          <div className="text-xl md:text-2xl font-black text-emerald-950 mt-1">
            {formatCurrency(totalSalesAmount)}
          </div>
          <span className="text-[11px] text-emerald-700">{salesVouchers.length} Total Vouchers</span>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
          <span className="text-xs font-semibold text-slate-600 uppercase">
            {lang === 'hi' ? 'कर योग्य मूल्य (Taxable)' : 'Total Taxable Value'}
          </span>
          <div className="text-xl md:text-2xl font-black text-slate-900 mt-1">
            {formatCurrency(totalTaxable)}
          </div>
          <span className="text-[11px] text-slate-500">Excluding GST taxes</span>
        </div>

        <div className="bg-purple-50 border border-purple-200 rounded-xl p-4">
          <span className="text-xs font-semibold text-purple-800 uppercase">
            {lang === 'hi' ? 'कुल जीएसटी कर (Tax Collected)' : 'GST Tax Output'}
          </span>
          <div className="text-xl md:text-2xl font-black text-purple-950 mt-1">
            {formatCurrency(totalGst)}
          </div>
          <span className="text-[11px] text-purple-700">CGST + SGST + IGST</span>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-3">
        {/* Tabs */}
        <div className="flex flex-wrap gap-1 w-full md:w-auto">
          {[
            { id: 'all', label: lang === 'hi' ? 'सभी' : 'All' },
            { id: 'sales_invoice', label: lang === 'hi' ? 'टैक्स इनवॉइस' : 'Tax Invoices' },
            { id: 'cash_memo', label: lang === 'hi' ? 'कैश मेमो' : 'Cash Memos' },
            { id: 'quotation', label: lang === 'hi' ? 'कोटेशन' : 'Quotations' },
            { id: 'delivery_challan', label: lang === 'hi' ? 'चालान' : 'Challans' },
            { id: 'credit_note', label: lang === 'hi' ? 'क्रेडिट नोट' : 'Credit Notes' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSubTab(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
                subTab === tab.id
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="flex items-center gap-2 w-full md:w-72 bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs">
          <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={lang === 'hi' ? 'इनवॉइस नं, पार्टी खोजें...' : 'Search invoice, party...'}
            className="w-full bg-transparent border-none outline-none text-slate-800"
          />
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-100 border-b border-slate-200 text-slate-600 font-semibold uppercase">
              <tr>
                <th className="p-3">Invoice No</th>
                <th className="p-3">Type</th>
                <th className="p-3">Date</th>
                <th className="p-3">Customer Name</th>
                <th className="p-3 text-right">Taxable</th>
                <th className="p-3 text-right">GST</th>
                <th className="p-3 text-right">Total Amount</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {salesVouchers.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-400 font-medium">
                    {lang === 'hi' ? 'कोई बिक्री रिकॉर्ड नहीं मिला' : 'No sales invoices found.'}
                  </td>
                </tr>
              ) : (
                salesVouchers.map((v) => {
                  const gst = (v.cgst || 0) + (v.sgst || 0) + (v.igst || 0);
                  return (
                    <tr key={v.id} className="hover:bg-slate-50/80 transition">
                      <td className="p-3 font-mono font-bold text-slate-900">{v.voucherNo}</td>
                      <td className="p-3">
                        <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                          {v.voucherType.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="p-3 text-slate-600">{v.date}</td>
                      <td className="p-3">
                        <div className="font-bold text-slate-900">{v.partyName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {v.partyGstin || 'Unregistered'}
                        </div>
                      </td>
                      <td className="p-3 text-right font-medium">{formatCurrency(v.taxableAmount)}</td>
                      <td className="p-3 text-right font-medium text-emerald-700">{formatCurrency(gst)}</td>
                      <td className="p-3 text-right font-bold text-slate-900 text-sm">
                        {formatCurrency(v.grandTotal)}
                      </td>
                      <td className="p-3 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            v.status === 'paid'
                              ? 'bg-emerald-100 text-emerald-800'
                              : v.status === 'partial'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {v.status}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onOpenPreview(v)}
                            className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition cursor-pointer"
                            title="Preview & Print"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              const link = generateWhatsAppShareLink(
                                v.partyAddress || '',
                                profile.businessName,
                                v.voucherNo,
                                v.grandTotal,
                                v.date,
                                v.dueDate
                              );
                              window.open(link, '_blank');
                            }}
                            className="p-1.5 text-slate-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition cursor-pointer"
                            title="WhatsApp Share"
                          >
                            <Share2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
