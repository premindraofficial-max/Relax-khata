import React, { useState } from 'react';
import {
  Plus,
  Users,
  Search,
  FileSpreadsheet,
  Phone,
  MapPin,
  Share2,
  BookOpen,
  ArrowRight,
  X,
  CreditCard,
  Edit2,
  Trash2,
} from 'lucide-react';
import { Party, Voucher, BusinessProfile } from '../types';
import { formatCurrency } from '../utils/accounting';
import { exportToExcel, exportToCSV } from '../utils/exportService';

interface PartiesViewProps {
  parties: Party[];
  vouchers: Voucher[];
  profile: BusinessProfile;
  onSaveParty: (party: Party) => void;
  onDeleteParty: (id: string) => void;
  lang: 'en' | 'hi';
}

export const PartiesView: React.FC<PartiesViewProps> = ({
  parties,
  vouchers,
  profile,
  onSaveParty,
  onDeleteParty,
  lang,
}) => {
  const [activeTab, setActiveTab] = useState<'customer' | 'supplier'>('customer');
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingParty, setEditingParty] = useState<Party | null>(null);
  const [selectedLedgerParty, setSelectedLedgerParty] = useState<Party | null>(null);

  const filteredParties = parties.filter((p) => {
    if (p.type !== activeTab) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        p.name.toLowerCase().includes(q) ||
        (p.gstin && p.gstin.toLowerCase().includes(q)) ||
        p.mobile.includes(q) ||
        p.state.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const totalOutstanding = filteredParties.reduce((sum, p) => sum + (p.currentBalance > 0 ? p.currentBalance : 0), 0);

  const handleOpenAdd = () => {
    setEditingParty({
      id: `party-${Date.now()}`,
      type: activeTab,
      name: '',
      mobile: '',
      email: '',
      gstin: '',
      address: '',
      state: profile.state,
      stateCode: profile.stateCode,
      openingBalance: 0,
      balanceType: activeTab === 'customer' ? 'dr' : 'cr',
      creditLimit: 100000,
      paymentTerms: 'Net 15 Days',
      currentBalance: 0,
      createdAt: new Date().toISOString().slice(0, 10),
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: Party) => {
    setEditingParty(p);
    setIsModalOpen(true);
  };

  const handleSaveModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingParty && editingParty.name.trim()) {
      onSaveParty(editingParty);
      setIsModalOpen(false);
    }
  };

  const handleSendReminder = (p: Party) => {
    const cleanPhone = p.mobile.replace(/[^0-9]/g, '');
    const phone = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
    const msg = `Namaste ${p.name}! 🙏\n\nThis is a gentle payment reminder from *${profile.businessName}*.\n💰 *Outstanding Balance Due:* ${formatCurrency(p.currentBalance)}\nKindly arrange for settlement at your earliest convenience.\nUPI ID: ${profile.upiId}\nBank: ${profile.bankName} (A/C: ${profile.bankAccountNo})\n\nThank you!\n_Sent via RELAX KHATA_`;
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  const handleExportExcel = () => {
    const headers = ['Party Name', 'Type', 'Mobile', 'GSTIN', 'Address', 'State', 'Credit Limit', 'Current Balance'];
    const rows = filteredParties.map((p) => [
      p.name,
      p.type.toUpperCase(),
      p.mobile,
      p.gstin || 'Unregistered',
      p.address || '',
      p.state,
      p.creditLimit,
      p.currentBalance,
    ]);
    exportToExcel(`${activeTab.toUpperCase()}_Directory`, [{ sheetName: 'Parties', headers, rows }]);
  };

  return (
    <div className="space-y-5 animate-in fade-in pb-12">
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {lang === 'hi' ? 'ग्राहक व सप्लायर (Parties & Ledgers)' : 'Parties & Ledger Accounts'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'hi'
              ? 'खाता बही, रनिंग बैलेंस, क्रेडिट लिमिट व व्हाट्सएप पेमेंट रिमाइंडर'
              : 'Party running ledgers, credit terms, and instant WhatsApp reminders'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition cursor-pointer shadow"
          >
            <Plus className="w-4 h-4" />
            <span>
              {activeTab === 'customer'
                ? lang === 'hi' ? '+ नया ग्राहक' : '+ New Customer'
                : lang === 'hi' ? '+ नया सप्लायर' : '+ New Supplier'}
            </span>
          </button>

          <button
            onClick={handleExportExcel}
            className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition border border-slate-200 cursor-pointer"
            title="Export to Excel"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
          </button>
        </div>
      </div>

      {/* Tabs & Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="sm:col-span-2 bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('customer')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
                activeTab === 'customer' ? 'bg-emerald-600 text-white shadow' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {lang === 'hi' ? 'ग्राहक सूची (Customers)' : 'Customers Directory'}
            </button>
            <button
              onClick={() => setActiveTab('supplier')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
                activeTab === 'supplier' ? 'bg-slate-900 text-white shadow' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {lang === 'hi' ? 'सप्लायर सूची (Suppliers)' : 'Suppliers Directory'}
            </button>
          </div>

          <span className="text-xs font-bold text-slate-500 hidden sm:inline-block">
            {filteredParties.length} {activeTab === 'customer' ? 'Clients' : 'Vendors'}
          </span>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-amber-800 uppercase">
              {activeTab === 'customer'
                ? lang === 'hi' ? 'कुल बकाया उधारी (Receivable)' : 'Total Outstanding Debt'
                : lang === 'hi' ? 'कुल देय राशि (Payable)' : 'Total Payable to Vendors'}
            </span>
            <div className="text-lg font-black text-amber-950 mt-0.5">
              {formatCurrency(totalOutstanding)}
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex items-center gap-2">
        <Search className="w-4 h-4 text-slate-400 shrink-0" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={lang === 'hi' ? 'पार्टी नाम, फोन, जीएसटी नंबर खोजें...' : 'Search party name, mobile, GSTIN...'}
          className="w-full bg-transparent border-none outline-none text-xs text-slate-800"
        />
      </div>

      {/* Parties Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredParties.map((p) => {
          const hasDue = p.currentBalance > 0;
          return (
            <div
              key={p.id}
              className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-1">
                <div className="flex justify-between items-start">
                  <h3 className="font-bold text-slate-900 text-sm">{p.name}</h3>
                  <span
                    className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                      hasDue ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {hasDue ? formatCurrency(p.currentBalance) : 'Settled'}
                  </span>
                </div>

                <div className="text-xs text-slate-500 space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{p.mobile}</span>
                  </div>
                  {p.gstin && (
                    <div className="font-mono text-[10px] text-slate-600">
                      GSTIN: <strong>{p.gstin}</strong>
                    </div>
                  )}
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>{p.address || p.state} ({p.stateCode})</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => setSelectedLedgerParty(p)}
                  className="flex items-center gap-1 text-xs font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-lg transition cursor-pointer"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>{lang === 'hi' ? 'खाता लेजर' : 'Ledger'}</span>
                </button>

                {hasDue && (
                  <button
                    onClick={() => handleSendReminder(p)}
                    className="flex items-center gap-1 text-xs font-bold text-emerald-800 hover:bg-emerald-50 px-2.5 py-1.5 rounded-lg transition cursor-pointer"
                    title="Send WhatsApp Payment Reminder"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </button>
                )}

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEdit(p)}
                    className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
                    title="Edit Party"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteParty(p.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg cursor-pointer"
                    title="Delete Party"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Party Modal */}
      {isModalOpen && editingParty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <form
            onSubmit={handleSaveModal}
            className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden flex flex-col max-h-[90vh]"
          >
            <div className="p-4 bg-slate-900 text-white flex justify-between items-center shrink-0">
              <h3 className="font-bold text-base">
                {editingParty.name ? 'Edit Party' : `Add New ${activeTab === 'customer' ? 'Customer' : 'Supplier'}`}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  {lang === 'hi' ? 'पार्टी / फर्म का नाम *' : 'Party / Business Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={editingParty.name}
                  onChange={(e) => setEditingParty({ ...editingParty, name: e.target.value })}
                  placeholder="e.g. Ramesh Trading Co."
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 font-bold text-slate-900"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'मोबाइल नंबर *' : 'Mobile Number *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={editingParty.mobile}
                    onChange={(e) => setEditingParty({ ...editingParty, mobile: e.target.value })}
                    placeholder="9876543210"
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'ईमेल' : 'Email Address'}
                  </label>
                  <input
                    type="email"
                    value={editingParty.email || ''}
                    onChange={(e) => setEditingParty({ ...editingParty, email: e.target.value })}
                    placeholder="party@domain.com"
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'GSTIN नंबर' : 'GSTIN Number (15 Digits)'}
                  </label>
                  <input
                    type="text"
                    maxLength={15}
                    value={editingParty.gstin || ''}
                    onChange={(e) => setEditingParty({ ...editingParty, gstin: e.target.value.toUpperCase() })}
                    placeholder="07AAAAA0000A1Z5"
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-mono uppercase"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'राज्य (State)' : 'State & Code'}
                  </label>
                  <input
                    type="text"
                    value={editingParty.state}
                    onChange={(e) => setEditingParty({ ...editingParty, state: e.target.value })}
                    placeholder="Delhi"
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  {lang === 'hi' ? 'पता (Address)' : 'Billing Address'}
                </label>
                <textarea
                  value={editingParty.address || ''}
                  onChange={(e) => setEditingParty({ ...editingParty, address: e.target.value })}
                  placeholder="Street, City, Pincode"
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'ओपनिंग बैलेंस (Opening Balance)' : 'Opening Balance (₹)'}
                  </label>
                  <input
                    type="number"
                    value={editingParty.openingBalance}
                    onChange={(e) => setEditingParty({ ...editingParty, openingBalance: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-bold"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {lang === 'hi' ? 'क्रेडिट लिमिट (Credit Limit)' : 'Credit Limit (₹)'}
                  </label>
                  <input
                    type="number"
                    value={editingParty.creditLimit}
                    onChange={(e) => setEditingParty({ ...editingParty, creditLimit: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2"
                  />
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 border border-slate-300 hover:bg-slate-100 rounded-xl font-semibold text-slate-700 cursor-pointer"
              >
                {lang === 'hi' ? 'रद्द करें' : 'Cancel'}
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold cursor-pointer shadow"
              >
                {lang === 'hi' ? 'पार्टी सुरक्षित करें' : 'Save Party'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Party Running Ledger Statement Modal */}
      {selectedLedgerParty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl h-[85vh] flex flex-col overflow-hidden">
            <div className="p-4 bg-slate-900 text-white flex justify-between items-center shrink-0">
              <div>
                <h3 className="font-bold text-base">{selectedLedgerParty.name} - Statement of Account</h3>
                <p className="text-xs text-slate-400">
                  GSTIN: {selectedLedgerParty.gstin || 'Unregistered'} | Mobile: {selectedLedgerParty.mobile}
                </p>
              </div>
              <button
                onClick={() => setSelectedLedgerParty(null)}
                className="p-1 text-slate-400 hover:text-white rounded cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 bg-slate-50">
              {/* Ledger Summary */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white p-4 rounded-xl border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500">Opening Balance:</span>
                  <div className="font-bold text-slate-800 text-sm">
                    {formatCurrency(selectedLedgerParty.openingBalance)}
                  </div>
                </div>
                <div>
                  <span className="text-slate-500">Credit Limit:</span>
                  <div className="font-bold text-slate-800 text-sm">
                    {formatCurrency(selectedLedgerParty.creditLimit)}
                  </div>
                </div>
                <div>
                  <span className="text-slate-500">Current Outstanding:</span>
                  <div className="font-bold text-amber-700 text-base">
                    {formatCurrency(selectedLedgerParty.currentBalance)}
                  </div>
                </div>
              </div>

              {/* Transactions Table */}
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-100 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                    <tr>
                      <th className="p-2.5">Date</th>
                      <th className="p-2.5">Voucher Type</th>
                      <th className="p-2.5">Voucher No</th>
                      <th className="p-2.5 text-right">Debit (Dr)</th>
                      <th className="p-2.5 text-right">Credit (Cr)</th>
                      <th className="p-2.5 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {vouchers
                      .filter((v) => v.partyId === selectedLedgerParty.id || v.partyName === selectedLedgerParty.name)
                      .map((v) => {
                        const isDr = v.voucherType === 'sales_invoice' || v.voucherType === 'payment_out';
                        return (
                          <tr key={v.id} className="hover:bg-slate-50">
                            <td className="p-2.5">{v.date}</td>
                            <td className="p-2.5 font-semibold capitalize">{v.voucherType.replace(/_/g, ' ')}</td>
                            <td className="p-2.5 font-mono font-bold text-slate-900">{v.voucherNo}</td>
                            <td className="p-2.5 text-right font-medium">{isDr ? formatCurrency(v.grandTotal) : '-'}</td>
                            <td className="p-2.5 text-right font-medium">{!isDr ? formatCurrency(v.grandTotal) : '-'}</td>
                            <td className="p-2.5 text-center">
                              <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[10px] uppercase font-bold">
                                {v.status}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="p-3 bg-white border-t border-slate-200 flex justify-end shrink-0">
              <button
                onClick={() => setSelectedLedgerParty(null)}
                className="px-4 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-semibold cursor-pointer"
              >
                Close Statement
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
