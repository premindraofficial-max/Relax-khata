import React, { useState } from 'react';
import {
  Plus,
  Wallet,
  Building2,
  ArrowDownLeft,
  ArrowUpRight,
  RefreshCw,
  Search,
  FileSpreadsheet,
} from 'lucide-react';
import { Voucher, VoucherType, Party, BusinessProfile } from '../types';
import { formatCurrency } from '../utils/accounting';
import { exportToExcel, exportToCSV } from '../utils/exportService';

interface PaymentsViewProps {
  vouchers: Voucher[];
  parties: Party[];
  profile: BusinessProfile;
  onOpenNewVoucher: (type: VoucherType) => void;
  lang: 'en' | 'hi';
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({
  vouchers,
  onOpenNewVoucher,
  lang,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'payment_in' | 'payment_out' | 'contra' | 'expense'>('all');
  const [search, setSearch] = useState('');

  const paymentVouchers = vouchers.filter((v) => {
    const isPayment = ['payment_in', 'payment_out', 'contra', 'expense', 'income', 'journal'].includes(v.voucherType);
    if (!isPayment) return false;
    if (filterType !== 'all' && v.voucherType !== filterType) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        v.voucherNo.toLowerCase().includes(q) ||
        v.partyName.toLowerCase().includes(q) ||
        (v.narration && v.narration.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const totalReceipts = paymentVouchers
    .filter((v) => v.voucherType === 'payment_in')
    .reduce((sum, v) => sum + v.grandTotal, 0);

  const totalPayments = paymentVouchers
    .filter((v) => v.voucherType === 'payment_out' || v.voucherType === 'expense')
    .reduce((sum, v) => sum + v.grandTotal, 0);

  const handleExportExcel = () => {
    const headers = ['Voucher No', 'Type', 'Date', 'Party / Account', 'Mode', 'Amount', 'Narration'];
    const rows = paymentVouchers.map((v) => [
      v.voucherNo,
      v.voucherType.toUpperCase(),
      v.date,
      v.partyName,
      v.paymentMode.toUpperCase(),
      v.grandTotal,
      v.narration || '',
    ]);
    exportToExcel(`Banking_Payments_${Date.now()}`, [{ sheetName: 'Transactions', headers, rows }]);
  };

  return (
    <div className="space-y-5 animate-in fade-in pb-12">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {lang === 'hi' ? 'बैंकिंग व भुगतान (Banking & Payments)' : 'Banking & Cash Transactions'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'hi'
              ? 'पेमेंट इन (रसीद), पेमेंट आउट, कॉन्ट्रा एंट्री व व्यावसायिक खर्चे'
              : 'Customer receipts, supplier payments, cash/bank contra transfers & expenses'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onOpenNewVoucher('payment_in')}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl transition cursor-pointer shadow"
          >
            <ArrowDownLeft className="w-4 h-4" />
            <span>{lang === 'hi' ? '+ पेमेंट इन (Receipt)' : '+ Payment In'}</span>
          </button>

          <button
            onClick={() => onOpenNewVoucher('payment_out')}
            className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl transition cursor-pointer shadow"
          >
            <ArrowUpRight className="w-4 h-4" />
            <span>{lang === 'hi' ? '+ पेमेंट आउट' : '+ Payment Out'}</span>
          </button>

          <button
            onClick={() => onOpenNewVoucher('contra')}
            className="flex items-center gap-1.5 bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs px-3 py-2.5 rounded-xl transition cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>{lang === 'hi' ? 'कॉन्ट्रा (Cash/Bank)' : 'Contra Entry'}</span>
          </button>

          <button
            onClick={() => onOpenNewVoucher('expense')}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-3 py-2.5 rounded-xl transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'hi' ? 'खर्च (Expense)' : 'Expense'}</span>
          </button>

          <button
            onClick={handleExportExcel}
            className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition border border-slate-200 cursor-pointer"
            title="Export Excel"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
          <span className="text-xs font-semibold text-emerald-800 uppercase">
            {lang === 'hi' ? 'कुल प्राप्तियां (Receipts In)' : 'Total Customer Receipts'}
          </span>
          <div className="text-xl md:text-2xl font-black text-emerald-950 mt-1">
            {formatCurrency(totalReceipts)}
          </div>
          <span className="text-[11px] text-emerald-700">Inflows deposited to bank & cash</span>
        </div>

        <div className="bg-rose-50 border border-rose-200 rounded-xl p-4">
          <span className="text-xs font-semibold text-rose-800 uppercase">
            {lang === 'hi' ? 'कुल भुगतान व खर्चे (Outflows)' : 'Total Payments & Expenses'}
          </span>
          <div className="text-xl md:text-2xl font-black text-rose-950 mt-1">
            {formatCurrency(totalPayments)}
          </div>
          <span className="text-[11px] text-rose-700">Outflows to suppliers & office expenses</span>
        </div>
      </div>

      {/* Tabs & Search */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-3">
        <div className="flex flex-wrap gap-1 w-full md:w-auto">
          {[
            { id: 'all', label: lang === 'hi' ? 'सभी' : 'All' },
            { id: 'payment_in', label: lang === 'hi' ? 'पेमेंट इन' : 'Payment In' },
            { id: 'payment_out', label: lang === 'hi' ? 'पेमेंट आउट' : 'Payment Out' },
            { id: 'contra', label: lang === 'hi' ? 'कॉन्ट्रा' : 'Contra' },
            { id: 'expense', label: lang === 'hi' ? 'खर्चे' : 'Expenses' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
                filterType === tab.id ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 w-full md:w-72 bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs">
          <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={lang === 'hi' ? 'खोजें...' : 'Search vouchers, narration...'}
            className="w-full bg-transparent border-none outline-none text-slate-800"
          />
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-100 border-b border-slate-200 text-slate-600 font-semibold uppercase">
              <tr>
                <th className="p-3">Voucher No</th>
                <th className="p-3">Type</th>
                <th className="p-3">Date</th>
                <th className="p-3">Party / Particulars</th>
                <th className="p-3">Payment Mode</th>
                <th className="p-3 text-right">Amount</th>
                <th className="p-3">Narration</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {paymentVouchers.map((v) => {
                const isInflow = v.voucherType === 'payment_in' || v.voucherType === 'income';
                return (
                  <tr key={v.id} className="hover:bg-slate-50/80 transition">
                    <td className="p-3 font-mono font-bold text-slate-900">{v.voucherNo}</td>
                    <td className="p-3">
                      <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        {v.voucherType.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="p-3 text-slate-600">{v.date}</td>
                    <td className="p-3 font-bold text-slate-900">{v.partyName}</td>
                    <td className="p-3 uppercase font-semibold text-slate-600">{v.paymentMode}</td>
                    <td className={`p-3 text-right font-black text-sm ${isInflow ? 'text-emerald-700' : 'text-slate-900'}`}>
                      {isInflow ? `+${formatCurrency(v.grandTotal)}` : `-${formatCurrency(v.grandTotal)}`}
                    </td>
                    <td className="p-3 text-slate-500 italic max-w-xs truncate">{v.narration || '-'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
