import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Send,
  ArrowRight,
  ShieldAlert,
  Loader2,
  CheckCircle,
  HelpCircle,
} from 'lucide-react';
import { ScreenRoute } from '../types';

interface HelpMeAIModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (route: ScreenRoute) => void;
  lang: 'en' | 'hi';
  businessName: string;
}

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  menuPath?: string;
  navigationTarget?: ScreenRoute;
  actionButtonText?: string;
  steps?: string[];
  timestamp: string;
}

export const HelpMeAIModal: React.FC<HelpMeAIModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  lang,
  businessName,
}) => {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text:
        lang === 'hi'
          ? `नमस्ते! 🙏 मैं हूँ HELP ME – आपका RELAX KHATA एआई सहायक। आप मुझसे कोई भी सवाल पूछ सकते हैं जैसे: "सेल्स इनवॉइस कैसे बनाएं?", "GSTR-1 JSON कैसे डाउनलोड करें?", "कस्टमर लेजर कहाँ है?", या "स्टॉक कैसे जोड़ें?"`
          : `Hello! 🙏 I am HELP ME – your RELAX KHATA AI Assistant. Ask me anything like: "How to create sales invoice?", "How to download GSTR-1 JSON?", "Where is customer ledger?", or "How to add stock?"`,
      menuPath: 'RELAX KHATA Help Centre',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const suggestedQuestions = [
    lang === 'hi' ? 'Sales invoice kaise banaye?' : 'How to create a sales invoice?',
    lang === 'hi' ? 'GSTR-1 JSON kaise download kare?' : 'How to download GSTR-1 JSON for portal?',
    lang === 'hi' ? 'Customer ledger aur running balance kaise dekhe?' : 'Where can I see customer ledger statement?',
    lang === 'hi' ? 'GSTR-2B reconciliation kaise karte hai?' : 'How does GSTR-2B ITC reconciliation work?',
    lang === 'hi' ? 'Naya product aur opening stock kaise jode?' : 'How to add new product and opening stock?',
    lang === 'hi' ? 'Full business data backup kaise le?' : 'How to take a complete backup of business data?',
  ];

  if (!isOpen) return null;

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || input;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai/help', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: textToSend,
          language: lang,
          businessName,
          currentScreen: 'dashboard',
        }),
      });

      const data = await response.json();

      const assistantMsg: Message = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text: data.explanation || (lang === 'hi' ? 'यहाँ प्रक्रिया दी गई है:' : 'Here is the step-by-step guidance:'),
        menuPath: data.menuPath,
        navigationTarget: data.navigationTarget as ScreenRoute,
        actionButtonText: data.actionButtonText || (lang === 'hi' ? 'स्क्रीन खोलें' : 'Open Screen'),
        steps: data.steps,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      // Local graceful fallback
      const assistantMsg: Message = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text:
          lang === 'hi'
            ? 'RELAX KHATA में आप साइडबार मेन्यू से सेल्स, खरीद, पार्टीज, इन्वेंटरी या GST सेंटर में आसानी से जा सकते हैं।'
            : 'You can navigate to Sales, Purchases, Parties, Inventory, or GST Centre from the side navigation menu.',
        menuPath: 'Main Menu',
        navigationTarget: 'dashboard',
        actionButtonText: lang === 'hi' ? 'डैशबोर्ड खोलें' : 'Open Dashboard',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl h-[85vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-emerald-900 via-slate-900 to-emerald-950 text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400 shadow-inner">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base md:text-lg">HELP ME – AI Assistant</h3>
                <span className="text-[10px] font-semibold bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-400/30">
                  Hindi + English
                </span>
              </div>
              <p className="text-xs text-slate-300">
                {lang === 'hi'
                  ? 'सटीक मेन्यू पथ व डायरेक्ट नेविगेशन बटन सहित मार्गदर्शन'
                  : 'Grounded accounting guidance with exact menu paths & instant screen navigation'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Privacy Disclosure Notice */}
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 text-xs text-amber-900 flex items-center gap-2 shrink-0">
          <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
          <span>
            {lang === 'hi'
              ? 'गोपनीयता सूचना: आपके प्रश्न केवल सहायता हेतु दर्ज किए जाते हैं। निजी एकाउंटिंग बैलेंस या पासवर्ड कभी नहीं भेजे जाते।'
              : 'Privacy Notice: Help queries are logged strictly for product assistance. Private ledgers, vouchers, and passwords are never accessed.'}
          </span>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[88%] rounded-2xl p-4 text-sm shadow-sm ${
                  m.sender === 'user'
                    ? 'bg-emerald-600 text-white rounded-br-sm'
                    : 'bg-white border border-slate-200 text-slate-800 rounded-bl-sm space-y-2'
                }`}
              >
                <div className="whitespace-pre-line leading-relaxed font-normal">{m.text}</div>

                {/* Steps Breakdown */}
                {m.steps && m.steps.length > 0 && (
                  <div className="mt-2 space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs text-slate-700">
                    <span className="font-bold text-slate-900 block mb-1">
                      {lang === 'hi' ? 'चरणबद्ध प्रक्रिया:' : 'Step-by-Step Instructions:'}
                    </span>
                    {m.steps.map((st, idx) => (
                      <div key={idx} className="flex items-start gap-1.5">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{st}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Exact Menu Path */}
                {m.menuPath && (
                  <div className="text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-100 flex items-center gap-1.5">
                    <span className="font-bold">{lang === 'hi' ? 'मेन्यू पथ:' : 'Menu Path:'}</span>
                    <span>{m.menuPath}</span>
                  </div>
                )}

                {/* Direct Screen Navigation Button */}
                {m.navigationTarget && (
                  <button
                    onClick={() => {
                      onNavigate(m.navigationTarget!);
                      onClose();
                    }}
                    className="mt-2 w-full flex items-center justify-center gap-2 bg-slate-900 hover:bg-emerald-700 text-white font-semibold text-xs py-2 px-3 rounded-xl transition cursor-pointer shadow"
                  >
                    <span>{m.actionButtonText || (lang === 'hi' ? 'सीधे खोलें' : 'Open Screen')}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <span className="text-[10px] text-slate-400 mt-1 px-1">{m.timestamp}</span>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-slate-500 text-xs p-3 bg-white rounded-xl border border-slate-200 w-fit">
              <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
              <span>{lang === 'hi' ? 'HELP ME सोच रहा है...' : 'HELP ME is formulating instructions...'}</span>
            </div>
          )}
        </div>

        {/* Frequently Asked Quick Chips */}
        <div className="p-2.5 bg-slate-100 border-t border-slate-200 overflow-x-auto flex gap-2 shrink-0">
          <div className="text-[11px] font-semibold text-slate-500 flex items-center gap-1 shrink-0 px-1">
            <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
            <span>{lang === 'hi' ? 'सुझाव:' : 'Suggestions:'}</span>
          </div>
          {suggestedQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="text-xs bg-white hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 border border-slate-200 px-2.5 py-1 rounded-lg shrink-0 transition cursor-pointer"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={
              lang === 'hi'
                ? 'सवाल पूछें (उदा. GST रिपोर्ट कहाँ से डाउनलोड करें?)...'
                : 'Ask a question (e.g. How to download GSTR-1 JSON?)...'
            }
            className="flex-1 bg-slate-100 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500"
          />
          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || isLoading}
            className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white p-2.5 rounded-xl transition cursor-pointer shadow shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
