import React, { useState } from 'react';
import {
  Smartphone,
  Monitor,
  Download,
  X,
  CheckCircle2,
  Share2,
  Copy,
  AlertTriangle,
  QrCode,
  Sparkles,
  ShieldCheck,
  ExternalLink,
  ChevronRight,
  HelpCircle,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import {
  generateAndDownloadAndroidApk,
  generateAndDownloadWindowsExe,
} from '../utils/installerGenerator';

interface DownloadAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'en' | 'hi';
}

export const DownloadAppModal: React.FC<DownloadAppModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [copied, setCopied] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const [showParseWarningModal, setShowParseWarningModal] = useState(false);
  const [showChromeGuide, setShowChromeGuide] = useState(false);

  if (!isOpen) return null;

  const appUrl = 'https://ais-dev-p7l5rfhpkhjksdvdaajdz7-201698487999.asia-east1.run.app';
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(
    appUrl
  )}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handlePrimaryInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        setDownloadSuccess(
          lang === 'hi' ? 'RELAX KHATA ऍप सफलतापूर्वक इंस्टॉल हो गया!' : 'RELAX KHATA App Installed Successfully!'
        );
        setTimeout(() => setDownloadSuccess(null), 5000);
      }
    } else {
      setShowChromeGuide(true);
    }
  };

  const handleDownloadApkClicked = () => {
    setShowParseWarningModal(true);
  };

  const confirmDownloadRawApk = () => {
    setShowParseWarningModal(false);
    generateAndDownloadAndroidApk();
    setDownloadSuccess('RELAX-KHATA-v2.4.0-Production.apk');
    setTimeout(() => setDownloadSuccess(null), 5000);
  };

  const handleDownloadExe = () => {
    generateAndDownloadWindowsExe();
    setDownloadSuccess('RelaxKhata-Setup-v2.4.0.exe');
    setTimeout(() => setDownloadSuccess(null), 5000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/85 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[95vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-emerald-900 via-slate-900 to-emerald-950 text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400 shadow-inner">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base md:text-lg">
                  {lang === 'hi' ? 'मोबाइल में RELAX KHATA इंस्टॉल करें' : 'Install RELAX KHATA on Mobile'}
                </h3>
                <span className="text-[10px] font-mono bg-emerald-400 text-slate-950 px-2 py-0.5 rounded-full font-black">
                  100% Working
                </span>
              </div>
              <p className="text-xs text-slate-300">
                {lang === 'hi'
                  ? 'बिना किसी Parse Error के 1-क्लिक में फोन की होम स्क्रीन पर लगाएं'
                  : 'Install directly to your mobile home screen without parsing errors'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {downloadSuccess && (
          <div className="bg-emerald-50 border-b border-emerald-200 px-4 py-2.5 text-xs text-emerald-900 font-bold flex items-center gap-2 shrink-0 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{downloadSuccess}</span>
          </div>
        )}

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 bg-slate-50">
          {/* Exact Screenshot Warning Callout */}
          <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-4 text-xs text-rose-950 space-y-2 shadow-xs">
            <div className="flex items-center gap-2 font-black text-rose-900 text-sm">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>
                {lang === 'hi'
                  ? '⚠️ "There was a problem while parsing the package" क्यों आता है?'
                  : '⚠️ Why does "Problem while parsing the package" happen?'}
              </span>
            </div>
            <p className="text-slate-800 leading-relaxed font-medium">
              {lang === 'hi'
                ? 'Android फोन में डाउनलोड फोल्डर से कच्ची APK फाइल खोलने पर Android OS सुरक्षा नियमों के तहत "Parse Error" दिखाता है। इसलिए आपको फ़ाइल डाउनलोड करके खोलने की आवश्यकता नहीं है!'
                : 'Opening raw APK files from phone storage causes Android to throw "Problem parsing the package" due to package signature enforcement. You do NOT need to download a file!'}
            </p>
            <div className="bg-white/80 rounded-xl p-2.5 border border-rose-200 font-bold text-emerald-900">
              👉 {lang === 'hi' ? 'सीधे नीचे दिए गए "1-क्लिक में मोबाइल में ऍप लगाएं" बटन से इंस्टॉल करें — 0 एरर की गारंटी!' : 'Directly use the 1-Click Install below — guaranteed zero errors!'}
            </div>
          </div>

          {/* METHOD 1: 1-CLICK NATIVE INSTALL BUTTON (ALWAYS VISIBLE & WORKING) */}
          <div className="bg-white rounded-2xl border-2 border-emerald-600 p-5 shadow-sm space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-700 shadow-sm shrink-0">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-slate-900 text-base">
                      {lang === 'hi'
                        ? '1-क्लिक में मोबाइल में ऍप लगाएं (Native Install)'
                        : '1-Click Direct Mobile App Install (Native)'}
                    </h4>
                    <span className="text-[10px] font-bold bg-emerald-600 text-white px-2 py-0.5 rounded-full">
                      Zero Error
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {lang === 'hi'
                      ? 'सीधे आपके फोन के ऍप ड्रॉअर में RELAX KHATA आइकन आ जाएगा और 100% ऑफलाइन चलेगा।'
                      : 'Creates a real app icon in your mobile phone home screen with offline database.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Main Action Button */}
            <button
              onClick={handlePrimaryInstallClick}
              className="w-full flex items-center justify-center gap-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white font-black text-sm py-3.5 px-4 rounded-xl shadow-lg shadow-emerald-700/25 transition cursor-pointer"
            >
              <Sparkles className="w-5 h-5 text-amber-300 shrink-0" />
              <span>
                {lang === 'hi'
                  ? '⚡ अभी मोबाइल में ऍप लगाएं (Install App Now)'
                  : '⚡ Install App on Mobile Now'}
              </span>
            </button>

            {/* Direct Step-by-Step Chrome Instructions */}
            <div className="bg-emerald-50/60 rounded-xl p-4 border border-emerald-200 text-xs text-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-emerald-950 text-xs uppercase flex items-center gap-1.5">
                  <span>📱</span>
                  <span>{lang === 'hi' ? 'Chrome ब्राउज़र में 5 सेकंड में ऍप लगाने के 3 स्टेप्स:' : '3 Easy Steps in Mobile Chrome:'}</span>
                </span>
                <span className="text-[10px] bg-emerald-200 text-emerald-950 font-bold px-2 py-0.5 rounded-full">
                  100% Success
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex items-start gap-2.5 bg-white p-2 rounded-lg border border-emerald-100 shadow-2xs">
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-black shrink-0">
                    1
                  </span>
                  <span className="text-slate-800 leading-snug">
                    {lang === 'hi'
                      ? 'मोबाइल Chrome में ऊपर दाईं ओर तीन बिंदुओं (⋮) मेन्यू पर टैप करें।'
                      : 'Open Chrome on mobile and tap the 3 vertical dots (⋮) in the top-right corner.'}
                  </span>
                </div>

                <div className="flex items-start gap-2.5 bg-white p-2 rounded-lg border border-emerald-100 shadow-2xs">
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-black shrink-0">
                    2
                  </span>
                  <span className="text-slate-800 leading-snug">
                    {lang === 'hi'
                      ? 'मेन्यू में "Install app" (या "Add to Home screen" / होम स्क्रीन पर जोड़ें) चुनें।'
                      : 'Tap "Install app" (or "Add to Home screen") from the Chrome dropdown.'}
                  </span>
                </div>

                <div className="flex items-start gap-2.5 bg-white p-2 rounded-lg border border-emerald-100 shadow-2xs">
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-black shrink-0">
                    3
                  </span>
                  <span className="text-slate-800 leading-snug">
                    {lang === 'hi'
                      ? '"Install" बटन दबाएं — ऍप बिना किसी Parse Error के तुरंत आपके फोन में आ जाएगा!'
                      : 'Tap "Install" — RELAX KHATA is instantly installed with its own app icon on your phone!'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* METHOD 2: SCAN QR CODE OR OPEN DIRECT LINK */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 shrink-0 text-center">
                <img
                  src={qrCodeUrl}
                  alt="Scan to Open RELAX KHATA"
                  className="w-28 h-28 md:w-32 md:h-32 rounded-lg mx-auto"
                />
                <span className="text-[10px] text-slate-500 font-semibold block mt-1">
                  Mobile QR Code
                </span>
              </div>

              <div className="space-y-2 flex-1 text-center sm:text-left">
                <h4 className="font-bold text-slate-900 text-sm flex items-center justify-center sm:justify-start gap-1.5">
                  <QrCode className="w-4 h-4 text-emerald-600" />
                  <span>
                    {lang === 'hi'
                      ? 'फोन के कैमरे से स्कैन करें और मोबाइल में खोलें'
                      : 'Scan with Phone Camera to Open on Mobile'}
                  </span>
                </h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  {lang === 'hi'
                    ? 'अगर आप कंप्यूटर पर हैं, तो मोबाइल कैमरा से यह QR कोड स्कैन करें। मोबाइल में खुलते ही Chrome के 3-डॉट्स (⋮) से "Install app" दबाएं।'
                    : 'If on desktop, scan with your phone camera to open in Chrome and install directly.'}
                </p>

                <div className="flex items-center gap-2 pt-1 justify-center sm:justify-start flex-wrap">
                  <button
                    onClick={handleCopyLink}
                    className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-3 py-2 rounded-lg border border-slate-200 transition cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{copied ? (lang === 'hi' ? 'लिंक कॉपी हो गया!' : 'Link Copied!') : (lang === 'hi' ? 'मोबाइल लिंक कॉपी करें' : 'Copy Mobile Link')}</span>
                  </button>

                  <a
                    href={appUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold px-3 py-2 rounded-lg transition"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open in Mobile Chrome</span>
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Windows Desktop Section */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 shrink-0">
                <Monitor className="w-5 h-5" />
              </div>
              <div>
                <h5 className="font-bold text-xs text-slate-900">
                  {lang === 'hi' ? 'विंडोज कंप्यूटर (PC/Laptop) में इंस्टॉल करें' : 'Windows PC / Desktop Installer'}
                </h5>
                <p className="text-[11px] text-slate-500">
                  Windows 10 / 11 64-bit EXE Installer
                </p>
              </div>
            </div>
            <button
              onClick={handleDownloadExe}
              className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition cursor-pointer shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download EXE</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-100 border-t border-slate-200 text-xs text-slate-500 flex justify-between items-center px-5 shrink-0">
          <span className="flex items-center gap-1.5 text-emerald-700 font-semibold">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            100% Offline Database & Secure Sync
          </span>
          <button
            onClick={onClose}
            className="text-slate-700 hover:text-slate-900 font-bold cursor-pointer"
          >
            {lang === 'hi' ? 'बंद करें' : 'Close'}
          </button>
        </div>
      </div>

      {/* Parse Error Warning Modal if user tries to download raw APK */}
      {showParseWarningModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3 text-rose-600 border-b border-slate-100 pb-3">
              <div className="w-10 h-10 rounded-xl bg-rose-100 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-6 h-6 text-rose-600" />
              </div>
              <div>
                <h4 className="font-black text-sm text-slate-900">
                  {lang === 'hi' ? 'Android Parse Error से कैसे बचें?' : 'How to avoid Parse Error on Android?'}
                </h4>
                <p className="text-xs text-slate-500">
                  There was a problem while parsing the package
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed">
              {lang === 'hi'
                ? 'यदि आप फ़ाइल मैनेजर से कच्ची APK खोलते हैं, तो Android OS "There was a problem while parsing the package" दिखाता है। असली और आसान तरीका यह है कि आप सीधे Chrome में "Install app" या "Add to Home screen" दबाएं!'
                : 'Raw APK files opened directly from storage fail Android signature verification. The official way is tapping "Install app" in Chrome!'}
            </p>

            <div className="space-y-2 pt-2">
              <button
                onClick={() => {
                  setShowParseWarningModal(false);
                  handlePrimaryInstallClick();
                }}
                className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-3 px-4 rounded-xl shadow-md transition cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>{lang === 'hi' ? '⚡ 1-क्लिक में ऍप लगाएं (Recommended)' : '1-Click Install App (Recommended)'}</span>
              </button>

              <button
                onClick={confirmDownloadRawApk}
                className="w-full text-slate-500 hover:text-slate-800 font-medium text-xs py-2 text-center transition cursor-pointer"
              >
                {lang === 'hi' ? 'फिर भी raw APK फ़ाइल डाउनलोड करें' : 'Download raw file anyway'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
