import React, { useState, useEffect, useMemo } from 'react';
import { Search, X, Users, Package, FileText, ArrowRight, Clock, Building, DollarSign } from 'lucide-react';
import { Party, Item, Voucher, ScreenRoute } from '../types';
import { LocalKhataDB } from '../utils/storage';
import { formatCurrency } from '../utils/accounting';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  parties: Party[];
  items: Item[];
  vouchers: Voucher[];
  onNavigate: (route: ScreenRoute, contextId?: string) => void;
  lang: 'en' | 'hi';
}

interface SearchResultItem {
  id: string;
  title: string;
  subtitle: string;
  category: 'party' | 'item' | 'voucher' | 'report';
  categoryLabel: string;
  route: ScreenRoute;
  badge?: string;
  extra?: string;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  parties,
  items,
  vouchers,
  onNavigate,
  lang,
}) => {
  const [query, setQuery] = useState('');
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  useEffect(() => {
    if (isOpen) {
      setRecentSearches(LocalKhataDB.getRecentSearches());
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Compute matched items (Strictly NO Settings search as required)
  const results = useMemo<SearchResultItem[]>(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];

    const matches: SearchResultItem[] = [];

    // 1. Customers and Suppliers (Parties)
    parties.forEach((p) => {
      if (
        p.name.toLowerCase().includes(q) ||
        (p.gstin && p.gstin.toLowerCase().includes(q)) ||
        p.mobile.includes(q) ||
        p.state.toLowerCase().includes(q)
      ) {
        matches.push({
          id: p.id,
          title: p.name,
          subtitle: `GSTIN: ${p.gstin || 'Unregistered'} | Mobile: ${p.mobile} | Balance: ${formatCurrency(p.currentBalance)}`,
          category: 'party',
          categoryLabel: p.type === 'customer' ? (lang === 'hi' ? 'ग्राहक' : 'Customer') : (lang === 'hi' ? 'सप्लायर' : 'Supplier'),
          route: 'parties',
          badge: p.type === 'customer' ? 'Customer' : 'Supplier',
          extra: formatCurrency(p.currentBalance),
        });
      }
    });

    // 2. Products and Items
    items.forEach((item) => {
      if (
        item.name.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.hsnCode.includes(q) ||
        (item.barcode && item.barcode.includes(q)) ||
        (item.batchNo && item.batchNo.toLowerCase().includes(q))
      ) {
        matches.push({
          id: item.id,
          title: item.name,
          subtitle: `Category: ${item.category} | HSN: ${item.hsnCode} | GST: ${item.gstRate}% | Stock: ${item.currentStock} ${item.unit}`,
          category: 'item',
          categoryLabel: lang === 'hi' ? 'उत्पाद / इन्वेंटरी' : 'Product / Stock',
          route: 'inventory',
          badge: `${item.currentStock} ${item.unit}`,
          extra: formatCurrency(item.salePrice),
        });
      }
    });

    // 3. Vouchers & Transactions (Sales, Purchase, Quotations, Challans, Payments, Expenses)
    vouchers.forEach((v) => {
      if (
        v.voucherNo.toLowerCase().includes(q) ||
        v.partyName.toLowerCase().includes(q) ||
        (v.partyGstin && v.partyGstin.toLowerCase().includes(q)) ||
        (v.narration && v.narration.toLowerCase().includes(q)) ||
        v.voucherType.toLowerCase().includes(q) ||
        (v.dueDate && v.dueDate.includes(q))
      ) {
        let route: ScreenRoute = 'sales';
        if (v.voucherType.startsWith('purchase')) route = 'purchase';
        else if (['payment_in', 'payment_out', 'contra', 'journal', 'expense'].includes(v.voucherType)) route = 'payments';

        matches.push({
          id: v.id,
          title: `${v.voucherNo} - ${v.partyName}`,
          subtitle: `Date: ${v.date} | Mode: ${v.paymentMode.toUpperCase()} | Taxable: ${formatCurrency(v.taxableAmount)}`,
          category: 'voucher',
          categoryLabel: v.voucherType.replace(/_/g, ' ').toUpperCase(),
          route,
          badge: v.status.toUpperCase(),
          extra: formatCurrency(v.grandTotal),
        });
      }
    });

    // 4. Reports Shortcuts
    const reportKeywords = [
      { name: 'GSTR-1 Outward Supplies', route: 'gst-centre', keys: ['gstr1', 'gstr-1', 'gst return', 'b2b', 'hsn'] },
      { name: 'GSTR-3B Tax Summary', route: 'gst-centre', keys: ['gstr3b', 'gstr-3b', 'itc', 'tax payment'] },
      { name: 'GSTR-2B ITC Reconciliation', route: 'gst-centre', keys: ['2b', 'reconciliation', 'reconcil', 'portal match'] },
      { name: 'Day Book & Daily Transactions', route: 'reports', keys: ['day book', 'daily', 'roznamcha'] },
      { name: 'Trial Balance & Ledgers', route: 'reports', keys: ['trial balance', 'general ledger', 'tb'] },
      { name: 'Profit & Loss Statement', route: 'reports', keys: ['profit', 'loss', 'pnl', 'munafa', 'kamai'] },
      { name: 'Balance Sheet', route: 'reports', keys: ['balance sheet', 'assets', 'liabilities'] },
      { name: 'Stock Valuation & Inventory Summary', route: 'reports', keys: ['stock report', 'valuation', 'godown'] },
    ];

    reportKeywords.forEach((r) => {
      if (r.keys.some((k) => k.includes(q) || q.includes(k))) {
        matches.push({
          id: `rep-${r.name}`,
          title: r.name,
          subtitle: lang === 'hi' ? 'सीधे रिपोर्ट देखें और PDF/Excel डाउनलोड करें' : 'Directly view report and download PDF/Excel',
          category: 'report',
          categoryLabel: lang === 'hi' ? 'वित्तीय रिपोर्ट' : 'Financial Report',
          route: r.route as ScreenRoute,
          badge: 'Report',
        });
      }
    });

    return matches.slice(0, 15);
  }, [query, parties, items, vouchers, lang]);

  if (!isOpen) return null;

  const handleSelect = (item: SearchResultItem) => {
    LocalKhataDB.addRecentSearch(query || item.title);
    onNavigate(item.route, item.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-12 md:pt-20 p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden flex flex-col max-h-[80vh]">
        {/* Search Header Input */}
        <div className="flex items-center gap-3 p-4 border-b border-slate-100 bg-slate-50">
          <Search className="w-5 h-5 text-emerald-600 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={lang === 'hi' ? 'ग्राहक, उत्पाद, इनवॉइस, वाउचर, HSN, GSTIN खोजें...' : 'Search customers, items, invoices, vouchers, HSN, GSTIN...'}
            autoFocus
            className="w-full bg-transparent border-none outline-none text-base text-slate-800 placeholder-slate-400 font-medium"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="hidden md:inline-block text-[11px] font-semibold text-slate-400 bg-slate-200/70 px-2 py-0.5 rounded border border-slate-300">
            ESC
          </kbd>
        </div>

        {/* Results / Recent Searches Area */}
        <div className="p-2 overflow-y-auto flex-1 divide-y divide-slate-100">
          {query.trim().length === 0 ? (
            <div className="p-4">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
                <Clock className="w-3.5 h-3.5" />
                <span>{lang === 'hi' ? 'हाल की खोजें' : 'Recent Searches'}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map((rec, i) => (
                  <button
                    key={i}
                    onClick={() => setQuery(rec)}
                    className="text-xs bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200 transition cursor-pointer"
                  >
                    {rec}
                  </button>
                ))}
              </div>
              <div className="mt-6 p-3 bg-emerald-50 rounded-xl border border-emerald-100 text-xs text-emerald-800 flex items-start gap-2">
                <Building className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold">{lang === 'hi' ? 'गोपनीयता नियम:' : 'Privacy Protection:'}</span>{' '}
                  {lang === 'hi'
                    ? 'आपकी सुरक्षा के लिए सेटिंग्स मेनू को ग्लोबल खोज से बाहर रखा गया है।'
                    : 'Settings are excluded from global search to protect sensitive credentials.'}
                </div>
              </div>
            </div>
          ) : results.length === 0 ? (
            <div className="p-8 text-center text-slate-500">
              <Search className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="font-medium text-sm">
                {lang === 'hi' ? 'कोई रिकॉर्ड नहीं मिला' : 'No records found matching your query'}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                {lang === 'hi' ? 'कृपया स्पेलिंग जांचें या दूसरा शब्द खोजें' : 'Try checking the invoice number, party name, or HSN code.'}
              </p>
            </div>
          ) : (
            results.map((item) => (
              <div
                key={item.id}
                onClick={() => handleSelect(item)}
                className="p-3 hover:bg-slate-50 transition flex items-center justify-between cursor-pointer rounded-xl group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-slate-100 group-hover:bg-emerald-100 flex items-center justify-center text-slate-600 group-hover:text-emerald-700 transition shrink-0">
                    {item.category === 'party' && <Users className="w-4 h-4" />}
                    {item.category === 'item' && <Package className="w-4 h-4" />}
                    {item.category === 'voucher' && <FileText className="w-4 h-4" />}
                    {item.category === 'report' && <DollarSign className="w-4 h-4" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-slate-900 group-hover:text-emerald-700 transition">
                        {item.title}
                      </span>
                      <span className="text-[10px] font-medium bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full border border-slate-200">
                        {item.categoryLabel}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">{item.subtitle}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0 ml-2">
                  {item.extra && (
                    <span className="text-sm font-bold text-slate-800 hidden sm:inline-block">
                      {item.extra}
                    </span>
                  )}
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 group-hover:translate-x-1 transition" />
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 text-xs text-slate-500 flex justify-between items-center px-4">
          <span>{lang === 'hi' ? 'नेविगेट करने के लिए क्लिक करें' : 'Click to navigate directly to record'}</span>
          <button
            onClick={onClose}
            className="text-slate-600 hover:text-slate-900 font-medium cursor-pointer"
          >
            {lang === 'hi' ? 'बंद करें' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
