import React, { useState } from 'react';
import {
  X,
  Plus,
  Trash2,
  Save,
  Printer,
  Sparkles,
} from 'lucide-react';
import {
  Voucher,
  VoucherType,
  VoucherItem,
  Party,
  Item,
  BusinessProfile,
  InvoiceTemplateId,
} from '../../types';
import { formatCurrency } from '../../utils/accounting';

interface VoucherModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (voucher: Voucher, printAfter?: boolean) => void;
  voucherType: VoucherType;
  parties: Party[];
  items: Item[];
  profile: BusinessProfile;
  initialVoucher?: Voucher;
  lang: 'en' | 'hi';
}

export const VoucherModal: React.FC<VoucherModalProps> = ({
  isOpen,
  onClose,
  onSave,
  voucherType,
  parties,
  items,
  profile,
  initialVoucher,
  lang,
}) => {
  const isSalesType = [
    'sales_invoice',
    'cash_memo',
    'quotation',
    'proforma_invoice',
    'delivery_challan',
    'sales_order',
    'credit_note',
  ].includes(voucherType);

  const applicableParties = parties.filter((p) =>
    isSalesType ? p.type === 'customer' : p.type === 'supplier'
  );

  const defaultVoucherNo = `${isSalesType ? 'SK' : 'PUR'}/${profile.financialYear || '24-25'}/${String(
    Math.floor(Math.random() * 800) + 100
  )}`;

  const [partyId, setPartyId] = useState(initialVoucher?.partyId || applicableParties[0]?.id || '');
  const [partyName, setPartyName] = useState(
    initialVoucher?.partyName || applicableParties[0]?.name || ''
  );
  const [partyGstin, setPartyGstin] = useState(
    initialVoucher?.partyGstin || applicableParties[0]?.gstin || ''
  );
  const [partyAddress, setPartyAddress] = useState(
    initialVoucher?.partyAddress || applicableParties[0]?.address || ''
  );
  const [partyState, setPartyState] = useState(
    initialVoucher?.partyState || applicableParties[0]?.state || profile.state
  );
  const [partyStateCode, setPartyStateCode] = useState(
    initialVoucher?.partyStateCode || applicableParties[0]?.stateCode || profile.stateCode
  );

  const [voucherNo, setVoucherNo] = useState(initialVoucher?.voucherNo || defaultVoucherNo);
  const [date, setDate] = useState(
    initialVoucher?.date || new Date().toISOString().slice(0, 10)
  );
  const [dueDate, setDueDate] = useState(
    initialVoucher?.dueDate || new Date(Date.now() + 15 * 86400000).toISOString().slice(0, 10)
  );
  const [paymentMode, setPaymentMode] = useState<Voucher['paymentMode']>(
    initialVoucher?.paymentMode || 'credit'
  );
  const [templateId, setTemplateId] = useState<InvoiceTemplateId>(
    initialVoucher?.templateId || 'modern'
  );
  const [narration, setNarration] = useState(initialVoucher?.narration || '');

  // Line Items
  const [lineItems, setLineItems] = useState<VoucherItem[]>(
    initialVoucher?.items?.length
      ? initialVoucher.items
      : [
          {
            id: 'vi-init-1',
            itemId: items[0]?.id || '',
            itemName: items[0]?.name || 'Standard Product',
            hsnCode: items[0]?.hsnCode || '8528',
            quantity: 1,
            unit: items[0]?.unit || 'PCS',
            rate: isSalesType ? items[0]?.salePrice || 1000 : items[0]?.purchasePrice || 800,
            discountPercent: 0,
            discountAmount: 0,
            taxableAmount: isSalesType ? items[0]?.salePrice || 1000 : items[0]?.purchasePrice || 800,
            gstRate: items[0]?.gstRate || 18,
            cgstAmount: 0,
            sgstAmount: 0,
            igstAmount: 0,
            cessAmount: 0,
            totalAmount: 0,
          },
        ]
  );

  if (!isOpen) return null;

  const handlePartyChange = (id: string) => {
    setPartyId(id);
    const selected = parties.find((p) => p.id === id);
    if (selected) {
      setPartyName(selected.name);
      setPartyGstin(selected.gstin || '');
      setPartyAddress(selected.address || '');
      setPartyState(selected.state);
      setPartyStateCode(selected.stateCode);
    }
  };

  const handleItemSelect = (index: number, itemId: string) => {
    const item = items.find((i) => i.id === itemId);
    if (!item) return;

    const rate = isSalesType ? item.salePrice : item.purchasePrice;
    const updated = [...lineItems];
    updated[index] = {
      ...updated[index],
      itemId: item.id,
      itemName: item.name,
      hsnCode: item.hsnCode,
      unit: item.unit,
      rate,
      gstRate: item.gstRate,
      batchNo: item.batchNo,
    };
    setLineItems(updated);
  };

  const handleLineItemChange = (index: number, field: keyof VoucherItem, val: any) => {
    const updated = [...lineItems];
    updated[index] = { ...updated[index], [field]: val };
    setLineItems(updated);
  };

  const addLine = () => {
    const defaultItem = items[0];
    setLineItems((prev) => [
      ...prev,
      {
        id: `vi-${Date.now()}`,
        itemId: defaultItem?.id || '',
        itemName: defaultItem?.name || '',
        hsnCode: defaultItem?.hsnCode || '8528',
        quantity: 1,
        unit: defaultItem?.unit || 'PCS',
        rate: isSalesType ? defaultItem?.salePrice || 500 : defaultItem?.purchasePrice || 400,
        discountPercent: 0,
        discountAmount: 0,
        taxableAmount: 0,
        gstRate: defaultItem?.gstRate || 18,
        cgstAmount: 0,
        sgstAmount: 0,
        igstAmount: 0,
        cessAmount: 0,
        totalAmount: 0,
      },
    ]);
  };

  const removeLine = (index: number) => {
    if (lineItems.length === 1) return;
    setLineItems((prev) => prev.filter((_, i) => i !== index));
  };

  // Check intra vs inter state for GST
  const isInterState = partyStateCode && profile.stateCode && partyStateCode !== profile.stateCode;

  // Calculate Subtotals & Taxes
  let totalTaxable = 0;
  let totalCgst = 0;
  let totalSgst = 0;
  let totalIgst = 0;
  let totalGross = 0;

  const calculatedLines = lineItems.map((item) => {
    const gross = (item.quantity || 0) * (item.rate || 0);
    const discAmt = gross * ((item.discountPercent || 0) / 100);
    const taxable = Math.max(0, gross - discAmt);

    let cgst = 0;
    let sgst = 0;
    let igst = 0;

    if (isInterState) {
      igst = (taxable * (item.gstRate || 0)) / 100;
    } else {
      cgst = (taxable * ((item.gstRate || 0) / 2)) / 100;
      sgst = (taxable * ((item.gstRate || 0) / 2)) / 100;
    }

    const lineTotal = taxable + cgst + sgst + igst;

    totalTaxable += taxable;
    totalCgst += cgst;
    totalSgst += sgst;
    totalIgst += igst;
    totalGross += lineTotal;

    return {
      ...item,
      discountAmount: discAmt,
      taxableAmount: taxable,
      cgstAmount: cgst,
      sgstAmount: sgst,
      igstAmount: igst,
      totalAmount: lineTotal,
    };
  });

  const roundedGrandTotal = Math.round(totalGross);
  const roundOff = Number((roundedGrandTotal - totalGross).toFixed(2));

  const handleFormSubmit = (printAfter = false) => {
    const newVoucher: Voucher = {
      id: initialVoucher?.id || `v-${Date.now()}`,
      voucherNo,
      voucherType,
      date,
      dueDate,
      partyId,
      partyName,
      partyGstin,
      partyAddress,
      partyState,
      partyStateCode,
      items: calculatedLines,
      subtotal: totalTaxable,
      discount: 0,
      taxableAmount: totalTaxable,
      cgst: totalCgst,
      sgst: totalSgst,
      igst: totalIgst,
      cess: 0,
      roundOff,
      grandTotal: roundedGrandTotal,
      paymentMode,
      narration,
      templateId,
      status: paymentMode === 'credit' ? 'unpaid' : 'paid',
      paidAmount: paymentMode === 'credit' ? 0 : roundedGrandTotal,
      createdAt: initialVoucher?.createdAt || new Date().toISOString(),
    };

    onSave(newVoucher, printAfter);
  };

  const getVoucherTitle = () => {
    const titles: Record<string, string> = {
      sales_invoice: lang === 'hi' ? 'नया बिक्री इनवॉइस (Sales Invoice)' : 'New Sales Tax Invoice',
      purchase_invoice: lang === 'hi' ? 'नया खरीद बिल (Purchase Invoice)' : 'New Purchase Invoice',
      cash_memo: lang === 'hi' ? 'कैश मेमो (Cash Memo)' : 'New Cash Memo',
      quotation: lang === 'hi' ? 'कोटेशन / अनुमान (Quotation)' : 'New Quotation / Estimate',
      proforma_invoice: lang === 'hi' ? 'प्रोफार्मा इनवॉइस' : 'New Proforma Invoice',
      delivery_challan: lang === 'hi' ? 'डिलीवरी चालान (Challan)' : 'New Delivery Challan',
      credit_note: lang === 'hi' ? 'क्रेडिट नोट (Sales Return)' : 'New Credit Note',
      debit_note: lang === 'hi' ? 'डेबिट नोट (Purchase Return)' : 'New Debit Note',
      sales_order: lang === 'hi' ? 'सेल्स ऑर्डर' : 'New Sales Order',
      purchase_order: lang === 'hi' ? 'परचेज ऑर्डर' : 'New Purchase Order',
      payment_in: lang === 'hi' ? 'पेमेंट इन (रसीद)' : 'Payment In (Receipt)',
      payment_out: lang === 'hi' ? 'पेमेंट आउट' : 'Payment Out',
      expense: lang === 'hi' ? 'खर्च प्रविष्टि' : 'Expense Entry',
    };
    return titles[voucherType] || 'Voucher Entry';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-5xl h-[92vh] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 bg-slate-900 text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base md:text-lg">{getVoucherTitle()}</h3>
              <p className="text-xs text-slate-400">
                {lang === 'hi' ? 'स्वचालित जीएसटी गणना व स्टॉक नियंत्रण' : 'Automatic GST Tax calculation & stock ledger integration'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-5 bg-slate-50">
          {/* Top Metadata Row */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-sm text-xs">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                {lang === 'hi' ? 'पार्टी चुनें (ग्राहक/सप्लायर)' : 'Select Party'}
              </label>
              <select
                value={partyId}
                onChange={(e) => handlePartyChange(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-medium text-slate-800"
              >
                {applicableParties.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} {p.gstin ? `(${p.gstin.slice(0, 6)}...)` : '(Unreg)'}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                {lang === 'hi' ? 'वाउचर / इनवॉइस नंबर' : 'Voucher / Invoice No'}
              </label>
              <input
                type="text"
                value={voucherNo}
                onChange={(e) => setVoucherNo(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-mono font-bold text-slate-800"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                {lang === 'hi' ? 'दिनांक' : 'Date'}
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-medium text-slate-800"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                {lang === 'hi' ? 'भुगतान माध्यम' : 'Payment Mode'}
              </label>
              <select
                value={paymentMode}
                onChange={(e) => setPaymentMode(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-semibold text-slate-800 uppercase"
              >
                <option value="credit">Credit / उधारी</option>
                <option value="cash">Cash / नकद</option>
                <option value="bank">Bank / NEFT / RTGS</option>
                <option value="upi">UPI / PhonePe / GPay</option>
                <option value="cheque">Cheque</option>
              </select>
            </div>
          </div>

          {/* Party Details Ribbon */}
          <div className="bg-emerald-50/60 border border-emerald-100 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs text-emerald-950">
            <div>
              <span className="text-emerald-700 font-semibold">{lang === 'hi' ? 'बिलिंग विवरण:' : 'Billing To:'}</span>{' '}
              <span className="font-bold">{partyName}</span> | GSTIN: <span className="font-mono font-bold">{partyGstin || 'Unregistered'}</span>
            </div>
            <div className="flex items-center gap-3">
              <span>State: <strong>{partyState} ({partyStateCode})</strong></span>
              <span className="bg-emerald-200/80 text-emerald-900 font-bold px-2 py-0.5 rounded text-[10px] uppercase">
                {isInterState ? 'Inter-State (IGST)' : 'Intra-State (CGST + SGST)'}
              </span>
            </div>
          </div>

          {/* Line Items Grid */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-3 bg-slate-100 border-b border-slate-200 flex justify-between items-center">
              <span className="font-bold text-xs uppercase tracking-wider text-slate-700">
                {lang === 'hi' ? 'आइटम व उत्पाद विवरण' : 'Items & Products Specification'}
              </span>
              <button
                type="button"
                onClick={addLine}
                className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{lang === 'hi' ? 'नया आइटम जोड़ें' : 'Add Item'}</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                  <tr>
                    <th className="p-2.5 w-8 text-center">#</th>
                    <th className="p-2.5 min-w-[200px]">Item Description</th>
                    <th className="p-2.5 text-center w-20">HSN</th>
                    <th className="p-2.5 text-center w-20">Qty</th>
                    <th className="p-2.5 text-center w-16">Unit</th>
                    <th className="p-2.5 text-right w-24">Rate (₹)</th>
                    <th className="p-2.5 text-center w-16">Disc %</th>
                    <th className="p-2.5 text-center w-16">GST %</th>
                    <th className="p-2.5 text-right w-28">Total (₹)</th>
                    <th className="p-2.5 w-10 text-center"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {lineItems.map((item, idx) => {
                    const gross = (item.quantity || 0) * (item.rate || 0);
                    const disc = gross * ((item.discountPercent || 0) / 100);
                    const taxable = gross - disc;
                    const taxAmt = (taxable * (item.gstRate || 0)) / 100;
                    const rowTotal = taxable + taxAmt;

                    return (
                      <tr key={idx} className="hover:bg-slate-50/80">
                        <td className="p-2.5 text-center font-bold text-slate-400">{idx + 1}</td>
                        <td className="p-2">
                          <select
                            value={item.itemId}
                            onChange={(e) => handleItemSelect(idx, e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded p-1.5 font-medium text-slate-800"
                          >
                            {items.map((i) => (
                              <option key={i.id} value={i.id}>
                                {i.name} (Stock: {i.currentStock})
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={item.hsnCode}
                            onChange={(e) => handleLineItemChange(idx, 'hsnCode', e.target.value)}
                            className="w-full text-center bg-slate-50 border border-slate-200 rounded p-1.5 font-mono"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => handleLineItemChange(idx, 'quantity', parseFloat(e.target.value) || 0)}
                            className="w-full text-center bg-slate-50 border border-slate-200 rounded p-1.5 font-bold text-slate-900"
                          />
                        </td>
                        <td className="p-2">
                          <span className="block text-center font-semibold text-slate-500 py-1.5">{item.unit}</span>
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            step="0.01"
                            value={item.rate}
                            onChange={(e) => handleLineItemChange(idx, 'rate', parseFloat(e.target.value) || 0)}
                            className="w-full text-right bg-slate-50 border border-slate-200 rounded p-1.5 font-semibold text-slate-900"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            value={item.discountPercent}
                            onChange={(e) => handleLineItemChange(idx, 'discountPercent', parseFloat(e.target.value) || 0)}
                            className="w-full text-center bg-slate-50 border border-slate-200 rounded p-1.5"
                          />
                        </td>
                        <td className="p-2">
                          <select
                            value={item.gstRate}
                            onChange={(e) => handleLineItemChange(idx, 'gstRate', parseInt(e.target.value))}
                            className="w-full text-center bg-slate-50 border border-slate-200 rounded p-1.5 font-bold text-emerald-700"
                          >
                            <option value="0">0%</option>
                            <option value="5">5%</option>
                            <option value="12">12%</option>
                            <option value="18">18%</option>
                            <option value="28">28%</option>
                          </select>
                        </td>
                        <td className="p-2 text-right font-bold text-slate-900">
                          {formatCurrency(rowTotal)}
                        </td>
                        <td className="p-2 text-center">
                          <button
                            type="button"
                            onClick={() => removeLine(idx)}
                            className="p-1 text-slate-400 hover:text-red-500 rounded cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Bottom Totals & Template Configuration */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  {lang === 'hi' ? 'इनवॉइस टेम्पलेट (7 डिज़ाइन उपलब्ध)' : 'Invoice Template Design'}
                </label>
                <select
                  value={templateId}
                  onChange={(e) => setTemplateId(e.target.value as InvoiceTemplateId)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-medium"
                >
                  <option value="modern">1. Modern Professional (Sleek Slate-Emerald)</option>
                  <option value="classic">2. Classic Business (Framed Ledger Boxed)</option>
                  <option value="minimal">3. Minimal GST Invoice (Ultra Clean)</option>
                  <option value="corporate">4. Premium Corporate (Navy Gold Accent)</option>
                  <option value="retail">5. Retail Counter Invoice (Quick POS)</option>
                  <option value="wholesale">6. Wholesale Invoice (Bulk & Batches)</option>
                  <option value="custom">7. Custom Invoice (Full Seal & QR)</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  {lang === 'hi' ? 'रिमार्क / नरेशन (Narration)' : 'Notes / Narration'}
                </label>
                <textarea
                  value={narration}
                  onChange={(e) => setNarration(e.target.value)}
                  placeholder={lang === 'hi' ? 'इस प्रविष्टि का विवरण...' : 'Add payment terms or notes...'}
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-800"
                />
              </div>
            </div>

            {/* Calculations Box */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Taxable Amount:</span>
                <span className="font-semibold">{formatCurrency(totalTaxable)}</span>
              </div>
              {totalCgst > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>Central GST (CGST):</span>
                  <span className="font-semibold">{formatCurrency(totalCgst)}</span>
                </div>
              )}
              {totalSgst > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>State GST (SGST):</span>
                  <span className="font-semibold">{formatCurrency(totalSgst)}</span>
                </div>
              )}
              {totalIgst > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>Integrated GST (IGST):</span>
                  <span className="font-semibold">{formatCurrency(totalIgst)}</span>
                </div>
              )}
              {roundOff !== 0 && (
                <div className="flex justify-between text-slate-500">
                  <span>Round Off:</span>
                  <span>{roundOff > 0 ? `+${roundOff.toFixed(2)}` : roundOff.toFixed(2)}</span>
                </div>
              )}
              <div className="border-t-2 border-slate-900 pt-2 flex justify-between items-baseline text-slate-900 font-bold text-base">
                <span>Grand Total:</span>
                <span className="text-emerald-700 text-lg">{formatCurrency(roundedGrandTotal)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 bg-white border-t border-slate-200 flex justify-between items-center shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-xs rounded-xl transition cursor-pointer"
          >
            {lang === 'hi' ? 'रद्द करें' : 'Cancel'}
          </button>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => handleFormSubmit(true)}
              className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs px-4 py-2.5 rounded-xl transition cursor-pointer shadow"
            >
              <Printer className="w-4 h-4" />
              <span>{lang === 'hi' ? 'सेव व प्रिंट करें' : 'Save & Print'}</span>
            </button>

            <button
              type="button"
              onClick={() => handleFormSubmit(false)}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs px-5 py-2.5 rounded-xl transition cursor-pointer shadow"
            >
              <Save className="w-4 h-4" />
              <span>{lang === 'hi' ? 'सेव करें' : 'Save Voucher'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
