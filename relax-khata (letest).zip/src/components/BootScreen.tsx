import React, { useEffect, useState } from 'react';
import { ShieldCheck, Sparkles, CheckCircle2 } from 'lucide-react';

interface BootScreenProps {
  onComplete: () => void;
  lang?: 'en' | 'hi';
}

export const BootScreen: React.FC<BootScreenProps> = ({ onComplete, lang = 'hi' }) => {
  const [progress, setProgress] = useState(15);
  const [statusText, setStatusText] = useState(lang === 'hi' ? 'डेटाबेस लोड हो रहा है...' : 'Loading local database...');

  useEffect(() => {
    const timer1 = setTimeout(() => {
      setProgress(45);
      setStatusText(lang === 'hi' ? 'जीएसटी और टैक्स इंजन सक्रिय किया जा रहा है...' : 'Initializing GST Tax Engine...');
    }, 400);

    const timer2 = setTimeout(() => {
      setProgress(80);
      setStatusText(lang === 'hi' ? 'ऑफलाइन लेजर और इन्वेंटरी तैयार...' : 'Verifying offline ledgers & inventory...');
    }, 800);

    const timer3 = setTimeout(() => {
      setProgress(100);
      setStatusText(lang === 'hi' ? 'खाता तैयार है! स्वागत है।' : 'Ready! Welcome to RELAX KHATA.');
    }, 1200);

    const timer4 = setTimeout(() => {
      onComplete();
    }, 1600);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [onComplete, lang]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-slate-950 via-emerald-950 to-slate-900 text-white overflow-hidden select-none">
      {/* Background Decorative Glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Main Container - Responsive for 9:16 mobile and wide desktop */}
      <div className="relative z-10 w-full h-full flex flex-col justify-between items-center p-6 md:p-12 max-w-4xl mx-auto">
        {/* Top Header Badge */}
        <div className="w-full flex justify-between items-center pt-2">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-emerald-400 uppercase bg-emerald-950/80 border border-emerald-500/30 px-3 py-1 rounded-full shadow-inner">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>100% Offline-First & GST Ready</span>
          </div>
          <span className="text-xs text-slate-400 font-mono">v2.4.0 Pro Enterprise</span>
        </div>

        {/* Center Branding & Logo */}
        <div className="flex flex-col items-center text-center my-auto">
          {/* Logo Emblem */}
          <div className="relative mb-6 group">
            <div className="w-24 h-24 md:w-32 md:h-32 rounded-3xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-amber-400 p-1 shadow-2xl shadow-emerald-500/30 flex items-center justify-center animate-pulse">
              <div className="w-full h-full bg-slate-950 rounded-[22px] flex flex-col items-center justify-center p-2">
                <span className="text-3xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-amber-300 tracking-tighter">
                  RK
                </span>
                <span className="text-[9px] md:text-[11px] font-bold text-emerald-400 tracking-widest uppercase">
                  RELAX
                </span>
              </div>
            </div>
            <Sparkles className="w-6 h-6 text-amber-400 absolute -top-2 -right-2 animate-bounce" />
          </div>

          {/* App Title */}
          <h1 className="text-3xl md:text-5xl font-black tracking-tight text-white mb-2">
            RELAX KHATA
          </h1>
          <p className="text-base md:text-xl font-medium text-emerald-300 max-w-md">
            {lang === 'hi' ? 'रिलैक्स खाता – सम्पूर्ण व्यापार और जीएसटी समाधान' : 'Professional Accounting, Billing, Inventory & GST'}
          </p>

          <p className="text-xs md:text-sm text-slate-400 mt-2 max-w-sm">
            {lang === 'hi'
              ? 'बिना इंटरनेट तेज बिलिंग, स्वचालित लेजर व आसान जीएसटी रिटर्न।'
              : 'Lightning fast offline billing, double-entry ledgers & instant GST returns.'}
          </p>
        </div>

        {/* Bottom Loading Indicator & Direct Enter Button */}
        <div className="w-full max-w-md flex flex-col items-center pb-4">
          <div className="w-full flex justify-between text-xs text-slate-400 mb-2 font-mono">
            <span>{statusText}</span>
            <span className="text-emerald-400 font-bold">{progress}%</span>
          </div>

          <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700/50 shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-amber-400 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>

          {/* Skip / Enter Now Button */}
          <button
            onClick={onComplete}
            className="mt-6 flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-semibold text-sm px-6 py-2.5 rounded-xl shadow-lg shadow-emerald-900/50 transition cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{lang === 'hi' ? 'डैशबोर्ड में प्रवेश करें' : 'Open Dashboard'}</span>
          </button>

          <div className="mt-4 text-[11px] text-slate-500 text-center">
            Android APK & Windows Desktop Installation Ready
          </div>
        </div>
      </div>
    </div>
  );
};
