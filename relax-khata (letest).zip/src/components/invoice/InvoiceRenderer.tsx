import React from 'react';
import { Voucher, BusinessProfile, PaperSize, InvoiceTemplateId } from '../../types';
import { formatCurrency, numberToWordsINR } from '../../utils/accounting';

interface InvoiceRendererProps {
  voucher: Voucher;
  profile: BusinessProfile;
  templateId?: InvoiceTemplateId;
  paperSize?: PaperSize;
}

export const InvoiceRenderer: React.FC<InvoiceRendererProps> = ({
  voucher,
  profile,
  templateId = 'modern',
  paperSize = 'a4',
}) => {
  const isThermal = paperSize === 'thermal';
  const isA5 = paperSize === 'a5';
  const paperClass = isThermal
    ? 'invoice-paper-thermal font-mono text-[10pt] max-w-[80mm] p-2 bg-white text-black'
    : isA5
    ? 'invoice-paper-a5 text-[10pt] max-w-[148mm] min-h-[210mm] p-4 bg-white text-slate-900 shadow-lg'
    : 'invoice-paper-a4 text-[10pt] max-w-[210mm] min-h-[297mm] p-8 bg-white text-slate-900 shadow-xl';

  const isInterState = voucher.igst > 0 || (voucher.partyStateCode && voucher.partyStateCode !== profile.stateCode);

  // Thermal 80mm compact receipt layout
  if (isThermal) {
    return (
      <div className={paperClass}>
        <div className="text-center border-b border-dashed border-black pb-2 mb-2">
          <h2 className="font-bold text-[12pt] uppercase">{profile.businessName}</h2>
          <p className="text-[9pt]">{profile.address}</p>
          <p className="text-[9pt]">GSTIN: {profile.gstin}</p>
          <p className="text-[9pt]">Phone: {profile.phone}</p>
          <div className="font-bold text-[10pt] mt-1 border-t border-dashed border-black pt-1">
            TAX INVOICE / CASH MEMO
          </div>
        </div>

        <div className="text-[9pt] border-b border-dashed border-black pb-2 mb-2">
          <div>Inv No: <span className="font-bold">{voucher.voucherNo}</span></div>
          <div>Date: {voucher.date}</div>
          <div>Customer: <span className="font-bold">{voucher.partyName}</span></div>
          {voucher.partyGstin && <div>Cust GSTIN: {voucher.partyGstin}</div>}
        </div>

        <table className="w-full text-left text-[9pt] mb-2 border-b border-dashed border-black pb-2">
          <thead>
            <tr className="border-b border-dashed border-black">
              <th className="py-1">Item</th>
              <th className="py-1 text-center">Qty</th>
              <th className="py-1 text-right">Rate</th>
              <th className="py-1 text-right">Amt</th>
            </tr>
          </thead>
          <tbody>
            {voucher.items.map((item, idx) => (
              <tr key={idx} className="border-b border-dotted border-gray-300">
                <td className="py-1">
                  <div className="font-semibold">{item.itemName}</div>
                  <div className="text-[8pt] text-gray-600">HSN: {item.hsnCode} | GST: {item.gstRate}%</div>
                </td>
                <td className="py-1 text-center">{item.quantity} {item.unit}</td>
                <td className="py-1 text-right">{item.rate.toFixed(2)}</td>
                <td className="py-1 text-right font-medium">{item.totalAmount.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="text-[9pt] space-y-1 border-b border-dashed border-black pb-2 mb-2">
          <div className="flex justify-between">
            <span>Taxable Amount:</span>
            <span>{formatCurrency(voucher.taxableAmount)}</span>
          </div>
          {voucher.cgst > 0 && (
            <div className="flex justify-between">
              <span>CGST:</span>
              <span>{formatCurrency(voucher.cgst)}</span>
            </div>
          )}
          {voucher.sgst > 0 && (
            <div className="flex justify-between">
              <span>SGST:</span>
              <span>{formatCurrency(voucher.sgst)}</span>
            </div>
          )}
          {voucher.igst > 0 && (
            <div className="flex justify-between">
              <span>IGST:</span>
              <span>{formatCurrency(voucher.igst)}</span>
            </div>
          )}
          <div className="flex justify-between font-bold text-[11pt] border-t border-black pt-1">
            <span>GRAND TOTAL:</span>
            <span>{formatCurrency(voucher.grandTotal)}</span>
          </div>
        </div>

        <div className="text-[8.5pt] text-center space-y-1">
          <div>UPI: {profile.upiId}</div>
          <div className="font-semibold mt-2">*** Thank You For Visiting! ***</div>
          <div className="text-[7.5pt] text-gray-500">Powered by RELAX KHATA</div>
        </div>
      </div>
    );
  }

  // 1. MODERN PROFESSIONAL
  const renderModern = () => (
    <div className={`${paperClass} mx-auto`}>
      {/* Top Header */}
      <div className="flex justify-between items-start border-b-2 border-emerald-600 pb-4 mb-4">
        <div>
          <span className="inline-block bg-emerald-100 text-emerald-800 text-[9pt] font-semibold px-2.5 py-0.5 rounded uppercase tracking-wider mb-1">
            TAX INVOICE
          </span>
          <h1 className="text-[16pt] font-bold text-slate-900 tracking-tight">{profile.businessName}</h1>
          <p className="text-[9pt] text-slate-600 font-medium">{profile.tradeName}</p>
          <p className="text-[9.5pt] text-slate-600 mt-1 max-w-[340px] leading-snug">{profile.address}</p>
          <div className="mt-2 text-[9pt] space-y-0.5 text-slate-700">
            <div><span className="font-semibold">GSTIN:</span> {profile.gstin} | <span className="font-semibold">State:</span> {profile.state} ({profile.stateCode})</div>
            <div><span className="font-semibold">Phone:</span> {profile.phone} | <span className="font-semibold">Email:</span> {profile.email}</div>
          </div>
        </div>

        <div className="text-right">
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 inline-block text-left min-w-[210px]">
            <div className="text-[9pt] text-slate-500 uppercase font-semibold">Invoice No</div>
            <div className="text-[12pt] font-bold text-emerald-700">{voucher.voucherNo}</div>
            <div className="mt-2 text-[9pt]">
              <span className="text-slate-500">Invoice Date:</span> <span className="font-medium text-slate-800">{voucher.date}</span>
            </div>
            {voucher.dueDate && (
              <div className="text-[9pt]">
                <span className="text-slate-500">Due Date:</span> <span className="font-medium text-slate-800">{voucher.dueDate}</span>
              </div>
            )}
            <div className="text-[9pt]">
              <span className="text-slate-500">Payment:</span> <span className="font-semibold uppercase text-slate-800">{voucher.paymentMode}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bill To & Ship To */}
      <div className="grid grid-cols-2 gap-4 bg-slate-50 border border-slate-200 rounded-lg p-3 mb-4 text-[9.5pt]">
        <div>
          <div className="font-bold text-slate-700 uppercase tracking-wider text-[8.5pt] border-b border-slate-200 pb-1 mb-1.5">
            Billed To (Customer Details)
          </div>
          <div className="font-bold text-slate-900 text-[10.5pt]">{voucher.partyName}</div>
          <p className="text-slate-600 text-[9pt] leading-snug mt-0.5">{voucher.partyAddress || 'Local Counter Sale'}</p>
          <div className="mt-1 text-[9pt] space-y-0.5">
            <div><span className="font-medium text-slate-600">GSTIN:</span> <span className="font-semibold text-slate-900">{voucher.partyGstin || 'Unregistered / Consumer'}</span></div>
            <div><span className="font-medium text-slate-600">State:</span> {voucher.partyState || profile.state} ({voucher.partyStateCode || profile.stateCode})</div>
          </div>
        </div>

        <div>
          <div className="font-bold text-slate-700 uppercase tracking-wider text-[8.5pt] border-b border-slate-200 pb-1 mb-1.5">
            Place of Supply & Transport
          </div>
          <div className="space-y-1 text-[9pt] text-slate-700">
            <div><span className="font-medium text-slate-600">Place of Supply:</span> {voucher.partyState || profile.state} ({voucher.partyStateCode || profile.stateCode})</div>
            <div><span className="font-medium text-slate-600">Supply Type:</span> {isInterState ? 'Inter-State (IGST Applicable)' : 'Intra-State (CGST + SGST Applicable)'}</div>
            <div><span className="font-medium text-slate-600">Reverse Charge (RCM):</span> No</div>
          </div>
        </div>
      </div>

      {/* Items Table */}
      <table className="w-full text-left border-collapse border border-slate-200 text-[9.5pt] mb-4">
        <thead>
          <tr className="bg-slate-900 text-white font-semibold text-[8.5pt] uppercase tracking-wider">
            <th className="p-2 border border-slate-800 text-center w-8">#</th>
            <th className="p-2 border border-slate-800">Item Description</th>
            <th className="p-2 border border-slate-800 text-center">HSN/SAC</th>
            <th className="p-2 border border-slate-800 text-center">Qty</th>
            <th className="p-2 border border-slate-800 text-right">Rate (₹)</th>
            <th className="p-2 border border-slate-800 text-right">Disc</th>
            <th className="p-2 border border-slate-800 text-right">Taxable</th>
            <th className="p-2 border border-slate-800 text-center">GST</th>
            <th className="p-2 border border-slate-800 text-right">Total (₹)</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-200">
          {voucher.items.map((item, idx) => (
            <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
              <td className="p-2 border border-slate-200 text-center font-medium text-slate-600">{idx + 1}</td>
              <td className="p-2 border border-slate-200">
                <div className="font-bold text-slate-900">{item.itemName}</div>
                {item.batchNo && <div className="text-[8pt] text-slate-500">Batch: {item.batchNo} {item.expiryDate ? `| Exp: ${item.expiryDate}` : ''}</div>}
              </td>
              <td className="p-2 border border-slate-200 text-center text-slate-700">{item.hsnCode}</td>
              <td className="p-2 border border-slate-200 text-center font-medium">{item.quantity} {item.unit}</td>
              <td className="p-2 border border-slate-200 text-right">{item.rate.toFixed(2)}</td>
              <td className="p-2 border border-slate-200 text-right text-slate-600">{item.discountPercent ? `${item.discountPercent}%` : '-'}</td>
              <td className="p-2 border border-slate-200 text-right font-medium">{item.taxableAmount.toFixed(2)}</td>
              <td className="p-2 border border-slate-200 text-center font-semibold text-emerald-700">{item.gstRate}%</td>
              <td className="p-2 border border-slate-200 text-right font-bold text-slate-900">{item.totalAmount.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Tax Breakup & Grand Totals */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        {/* Left Side: Amount in Words, Bank Details */}
        <div className="space-y-3">
          <div className="bg-slate-50 border border-slate-200 rounded p-2.5">
            <span className="text-[8pt] uppercase font-bold text-slate-500 block mb-0.5">Amount Chargeable in Words:</span>
            <div className="font-bold text-slate-900 text-[9pt] leading-tight">
              {numberToWordsINR(voucher.grandTotal, 'en')}
            </div>
            <div className="text-slate-600 text-[8.5pt] mt-0.5">
              {numberToWordsINR(voucher.grandTotal, 'hi')}
            </div>
          </div>

          <div className="border border-slate-200 rounded p-2.5 text-[8.5pt]">
            <span className="font-bold text-slate-800 uppercase block mb-1">Company Bank Details:</span>
            <div className="grid grid-cols-2 gap-1 text-slate-700">
              <div><span className="font-medium">Bank Name:</span> {profile.bankName}</div>
              <div><span className="font-medium">A/C No:</span> {profile.bankAccountNo}</div>
              <div><span className="font-medium">IFSC Code:</span> {profile.bankIfsc}</div>
              <div><span className="font-medium">Branch:</span> {profile.bankBranch}</div>
            </div>
            <div className="mt-1 font-semibold text-emerald-700">UPI ID: {profile.upiId}</div>
          </div>
        </div>

        {/* Right Side: Totals calculation */}
        <div className="bg-slate-50 border border-slate-200 rounded p-3 text-[9.5pt] space-y-1.5">
          <div className="flex justify-between text-slate-700">
            <span>Total Taxable Value:</span>
            <span className="font-medium">{formatCurrency(voucher.taxableAmount)}</span>
          </div>
          {voucher.cgst > 0 && (
            <div className="flex justify-between text-slate-700">
              <span>Central Tax (CGST):</span>
              <span className="font-medium">{formatCurrency(voucher.cgst)}</span>
            </div>
          )}
          {voucher.sgst > 0 && (
            <div className="flex justify-between text-slate-700">
              <span>State Tax (SGST):</span>
              <span className="font-medium">{formatCurrency(voucher.sgst)}</span>
            </div>
          )}
          {voucher.igst > 0 && (
            <div className="flex justify-between text-slate-700">
              <span>Integrated Tax (IGST):</span>
              <span className="font-medium">{formatCurrency(voucher.igst)}</span>
            </div>
          )}
          {voucher.roundOff !== 0 && (
            <div className="flex justify-between text-slate-600 text-[9pt]">
              <span>Round Off:</span>
              <span>{voucher.roundOff > 0 ? `+${voucher.roundOff.toFixed(2)}` : voucher.roundOff.toFixed(2)}</span>
            </div>
          )}
          <div className="border-t-2 border-slate-900 pt-2 flex justify-between items-baseline font-bold text-[13pt] text-slate-900">
            <span>Grand Total (INR):</span>
            <span className="text-emerald-700">{formatCurrency(voucher.grandTotal)}</span>
          </div>
        </div>
      </div>

      {/* Footer: Terms & Signature Stamp */}
      <div className="grid grid-cols-2 gap-4 border-t border-slate-200 pt-4 mt-auto text-[8.5pt]">
        <div>
          <span className="font-bold uppercase text-slate-700 block mb-1">Terms & Conditions:</span>
          <pre className="text-slate-600 whitespace-pre-line font-sans text-[8pt] leading-tight">
            {profile.termsAndConditions}
          </pre>
        </div>

        <div className="text-right flex flex-col justify-between items-end min-h-[90px]">
          <span className="font-semibold text-slate-800">For {profile.businessName}</span>
          <div className="border border-dashed border-emerald-500 rounded p-1.5 px-3 text-center inline-block">
            <span className="text-[7.5pt] font-bold text-emerald-700 uppercase tracking-wider block">RELAX KHATA VERIFIED</span>
            <span className="text-[7pt] text-slate-500">Authorized Digital Signature</span>
          </div>
          <span className="text-[8.5pt] text-slate-600 font-medium">Authorized Signatory</span>
        </div>
      </div>
    </div>
  );

  // 2. CLASSIC BUSINESS (Traditional Indian Boxed Format)
  const renderClassic = () => (
    <div className={`${paperClass} mx-auto border-2 border-black`}>
      <div className="text-center border-b-2 border-black p-3 bg-amber-50/50">
        <h1 className="text-[17pt] font-black uppercase tracking-wider">{profile.businessName}</h1>
        <p className="text-[10pt] font-bold text-slate-800">{profile.tradeName}</p>
        <p className="text-[9.5pt] max-w-[500px] mx-auto mt-0.5">{profile.address}</p>
        <p className="text-[9pt] font-semibold mt-1">GSTIN: {profile.gstin} | State: {profile.state} ({profile.stateCode}) | Phone: {profile.phone}</p>
        <div className="inline-block border border-black px-4 py-0.5 font-bold uppercase text-[10pt] mt-2 bg-white">
          TAX INVOICE
        </div>
      </div>

      <div className="grid grid-cols-2 border-b-2 border-black text-[9.5pt]">
        <div className="p-3 border-r-2 border-black">
          <div className="font-bold underline mb-1">Details of Receiver (Billed To):</div>
          <div className="font-bold text-[11pt]">{voucher.partyName}</div>
          <div>{voucher.partyAddress || 'Local Address'}</div>
          <div><span className="font-bold">GSTIN / UIN:</span> {voucher.partyGstin || 'Unregistered'}</div>
          <div><span className="font-bold">State & Code:</span> {voucher.partyState || profile.state} ({voucher.partyStateCode || profile.stateCode})</div>
        </div>
        <div className="p-3 space-y-1">
          <div><span className="font-bold">Invoice Number:</span> <span className="font-mono font-bold text-[11pt]">{voucher.voucherNo}</span></div>
          <div><span className="font-bold">Invoice Date:</span> {voucher.date}</div>
          <div><span className="font-bold">Due Date:</span> {voucher.dueDate || 'Immediate'}</div>
          <div><span className="font-bold">Place of Supply:</span> {voucher.partyState || profile.state}</div>
          <div><span className="font-bold">Terms of Payment:</span> {voucher.paymentMode.toUpperCase()}</div>
        </div>
      </div>

      {/* Classic Table */}
      <table className="w-full text-left border-collapse text-[9pt]">
        <thead>
          <tr className="border-b-2 border-black bg-slate-100 font-bold uppercase">
            <th className="p-2 border-r border-black text-center w-8">S.N.</th>
            <th className="p-2 border-r border-black">Description of Goods</th>
            <th className="p-2 border-r border-black text-center">HSN</th>
            <th className="p-2 border-r border-black text-center">Qty</th>
            <th className="p-2 border-r border-black text-right">Rate</th>
            <th className="p-2 border-r border-black text-right">Taxable Val</th>
            <th className="p-2 border-r border-black text-center">GST %</th>
            <th className="p-2 text-right">Amount (₹)</th>
          </tr>
        </thead>
        <tbody>
          {voucher.items.map((item, idx) => (
            <tr key={idx} className="border-b border-black">
              <td className="p-2 border-r border-black text-center">{idx + 1}</td>
              <td className="p-2 border-r border-black font-semibold">{item.itemName}</td>
              <td className="p-2 border-r border-black text-center">{item.hsnCode}</td>
              <td className="p-2 border-r border-black text-center">{item.quantity} {item.unit}</td>
              <td className="p-2 border-r border-black text-right">{item.rate.toFixed(2)}</td>
              <td className="p-2 border-r border-black text-right">{item.taxableAmount.toFixed(2)}</td>
              <td className="p-2 border-r border-black text-center">{item.gstRate}%</td>
              <td className="p-2 text-right font-bold">{item.totalAmount.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Classic Summary */}
      <div className="grid grid-cols-2 border-t-2 border-black text-[9pt]">
        <div className="p-3 border-r-2 border-black space-y-2">
          <div>
            <span className="font-bold underline block mb-0.5">Total Amount in Words:</span>
            <div className="font-bold text-[9.5pt]">{numberToWordsINR(voucher.grandTotal, 'en')}</div>
          </div>
          <div className="border border-black p-2 mt-2">
            <span className="font-bold block">Bank Account Details:</span>
            <div>Bank: {profile.bankName} | A/C: {profile.bankAccountNo}</div>
            <div>IFSC: {profile.bankIfsc} | UPI: {profile.upiId}</div>
          </div>
        </div>

        <div className="p-3 space-y-1 text-[9.5pt]">
          <div className="flex justify-between">
            <span>Total Taxable:</span>
            <span className="font-bold">{formatCurrency(voucher.taxableAmount)}</span>
          </div>
          {voucher.cgst > 0 && (
            <div className="flex justify-between">
              <span>Add CGST:</span>
              <span>{formatCurrency(voucher.cgst)}</span>
            </div>
          )}
          {voucher.sgst > 0 && (
            <div className="flex justify-between">
              <span>Add SGST:</span>
              <span>{formatCurrency(voucher.sgst)}</span>
            </div>
          )}
          {voucher.igst > 0 && (
            <div className="flex justify-between">
              <span>Add IGST:</span>
              <span>{formatCurrency(voucher.igst)}</span>
            </div>
          )}
          <div className="flex justify-between font-black text-[12pt] border-t-2 border-black pt-1 mt-1">
            <span>Invoice Total:</span>
            <span>{formatCurrency(voucher.grandTotal)}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 border-t-2 border-black p-3 text-[8.5pt]">
        <div>
          <span className="font-bold underline block mb-1">Declaration & Terms:</span>
          <div>{profile.termsAndConditions}</div>
        </div>
        <div className="text-right flex flex-col justify-between items-end min-h-[80px]">
          <span className="font-bold">For {profile.businessName}</span>
          <span className="font-bold border-t border-black pt-1 px-4">Authorized Signatory</span>
        </div>
      </div>
    </div>
  );

  // Default to Modern if other styles are selected (they share the clean high-fidelity rendering)
  if (templateId === 'classic') return renderClassic();
  return renderModern();
};
