import React, { useState } from 'react';
import {
  X,
  Printer,
  Download,
  Share2,
  FileCode,
} from 'lucide-react';
import { Voucher, BusinessProfile, InvoiceTemplateId, PaperSize } from '../../types';
import { InvoiceRenderer } from './InvoiceRenderer';
import { generateWhatsAppShareLink, exportToJSON, exportReportToPDF } from '../../utils/exportService';

interface InvoicePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  voucher: Voucher | null;
  profile: BusinessProfile;
  lang: 'en' | 'hi';
}

export const InvoicePreviewModal: React.FC<InvoicePreviewModalProps> = ({
  isOpen,
  onClose,
  voucher,
  profile,
  lang,
}) => {
  const [templateId, setTemplateId] = useState<InvoiceTemplateId>(voucher?.templateId || 'modern');
  const [paperSize, setPaperSize] = useState<PaperSize>('a4');

  if (!isOpen || !voucher) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = () => {
    const headers = ['#', 'Item', 'HSN', 'Qty', 'Unit', 'Rate', 'Taxable', 'GST%', 'Total'];
    const rows = voucher.items.map((it, idx) => [
      idx + 1,
      it.itemName,
      it.hsnCode,
      it.quantity,
      it.unit,
      it.rate.toFixed(2),
      it.taxableAmount.toFixed(2),
      `${it.gstRate}%`,
      it.totalAmount.toFixed(2),
    ]);

    exportReportToPDF(
      `Tax_Invoice_${voucher.voucherNo.replace(/[^a-zA-Z0-9]/g, '_')}`,
      profile.businessName,
      profile.gstin,
      headers,
      rows,
      `Billed To: ${voucher.partyName} | Date: ${voucher.date} | Grand Total: Rs. ${voucher.grandTotal.toFixed(2)}`
    );
  };

  const handleWhatsAppShare = () => {
    const link = generateWhatsAppShareLink(
      voucher.partyAddress || '',
      profile.businessName,
      voucher.voucherNo,
      voucher.grandTotal,
      voucher.date,
      voucher.dueDate
    );
    window.open(link, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 md:p-6 bg-slate-950/85 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-100 rounded-2xl shadow-2xl border border-slate-300 w-full max-w-5xl h-[95vh] flex flex-col overflow-hidden">
        {/* Top Control Bar (Hidden during print) */}
        <div className="no-print p-4 bg-slate-900 text-white flex flex-wrap gap-3 justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <span className="font-bold text-base">{voucher.voucherNo}</span>
            <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-400/30 uppercase">
              {voucher.status}
            </span>
          </div>

          {/* Quick Selectors */}
          <div className="flex items-center gap-2">
            <select
              value={templateId}
              onChange={(e) => setTemplateId(e.target.value as InvoiceTemplateId)}
              className="bg-slate-800 text-slate-200 border border-slate-700 text-xs rounded-lg px-3 py-1.5 font-medium"
            >
              <option value="modern">Modern Professional</option>
              <option value="classic">Classic Business</option>
              <option value="minimal">Minimal GST Invoice</option>
              <option value="corporate">Premium Corporate</option>
              <option value="retail">Retail Counter POS</option>
              <option value="wholesale">Wholesale Invoice</option>
              <option value="custom">Custom Format</option>
            </select>

            <select
              value={paperSize}
              onChange={(e) => setPaperSize(e.target.value as PaperSize)}
              className="bg-slate-800 text-slate-200 border border-slate-700 text-xs rounded-lg px-3 py-1.5 font-medium"
            >
              <option value="a4">A4 Full Page</option>
              <option value="a5">A5 Half Page</option>
              <option value="thermal">Thermal 80mm Roll</option>
            </select>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition cursor-pointer shadow"
            >
              <Printer className="w-4 h-4" />
              <span>{lang === 'hi' ? 'प्रिंट करें' : 'Print'}</span>
            </button>

            <button
              onClick={handleDownloadPDF}
              className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition cursor-pointer border border-slate-700"
            >
              <Download className="w-4 h-4" />
              <span>PDF</span>
            </button>

            <button
              onClick={handleWhatsAppShare}
              className="flex items-center gap-1.5 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
              <span>WhatsApp</span>
            </button>

            <button
              onClick={() => exportToJSON(`Invoice_${voucher.voucherNo}`, voucher)}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
              title="Download JSON"
            >
              <FileCode className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Paper Canvas Display */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 flex justify-center bg-slate-200/80">
          <InvoiceRenderer
            voucher={voucher}
            profile={profile}
            templateId={templateId}
            paperSize={paperSize}
          />
        </div>
      </div>
    </div>
  );
};
