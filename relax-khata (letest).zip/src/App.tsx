import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Receipt,
  ShoppingCart,
  Wallet,
  Package,
  Users,
  Percent,
  BarChart3,
  Settings as SettingsIcon,
  Download,
  Search,
  Sparkles,
  Lock,
  Globe,
  Bell,
  HelpCircle,
  Menu,
  X,
  Type,
  CloudCheck,
} from 'lucide-react';
import {
  ScreenRoute,
  Language,
  BusinessProfile,
  Party,
  Item,
  Voucher,
  VoucherType,
  GSTR2BItem,
} from './types';
import { LocalKhataDB } from './utils/storage';
import { t } from './utils/translations';
import { BootScreen } from './components/BootScreen';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { HelpMeAIModal } from './components/HelpMeAIModal';
import { AdminDashboardModal } from './components/AdminDashboardModal';
import { VoucherModal } from './components/vouchers/VoucherModal';
import { InvoicePreviewModal } from './components/invoice/InvoicePreviewModal';
import { DownloadAppModal } from './components/DownloadAppModal';
import { Smartphone } from 'lucide-react';

// Views
import { DashboardView } from './views/DashboardView';
import { SalesView } from './views/SalesView';
import { PurchaseView } from './views/PurchaseView';
import { PaymentsView } from './views/PaymentsView';
import { InventoryView } from './views/InventoryView';
import { PartiesView } from './views/PartiesView';
import { GSTCentreView } from './views/GSTCentreView';
import { ReportsView } from './views/ReportsView';
import { SettingsView } from './views/SettingsView';
import { InstallerView } from './views/InstallerView';

export default function App() {
  // Boot Screen state
  const [showBootScreen, setShowBootScreen] = useState(true);

  // Core App State
  const [activeRoute, setActiveRoute] = useState<ScreenRoute>('dashboard');
  const [lang, setLang] = useState<Language>('hi');
  const [fontScale, setFontScale] = useState<number>(1);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Data Collections
  const [profile, setProfile] = useState<BusinessProfile>(() => LocalKhataDB.getProfile());
  const [parties, setParties] = useState<Party[]>(() => LocalKhataDB.getParties());
  const [items, setItems] = useState<Item[]>(() => LocalKhataDB.getItems());
  const [vouchers, setVouchers] = useState<Voucher[]>(() => LocalKhataDB.getVouchers());
  const [portal2B, setPortal2B] = useState<GSTR2BItem[]>(() => LocalKhataDB.getPortal2B());

  // Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isHelpMeOpen, setIsHelpMeOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isVoucherModalOpen, setIsVoucherModalOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [currentVoucherType, setCurrentVoucherType] = useState<VoucherType>('sales_invoice');
  const [editingVoucher, setEditingVoucher] = useState<Voucher | undefined>(undefined);
  const [previewVoucher, setPreviewVoucher] = useState<Voucher | null>(null);

  // Initialize Font scale on mount
  useEffect(() => {
    const scale = LocalKhataDB.getFontScale();
    setFontScale(scale);
    document.documentElement.style.setProperty('--app-font-scale', scale.toString());
  }, []);

  // Global Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Persistence helpers
  const handleSaveProfile = (newProfile: BusinessProfile) => {
    setProfile(newProfile);
    LocalKhataDB.saveProfile(newProfile);
  };

  const handleUpdateLanguage = (newLang: Language) => {
    setLang(newLang);
  };

  const handleUpdateFontScale = (scale: number) => {
    setFontScale(scale);
    LocalKhataDB.saveFontScale(scale);
  };

  const handleSaveParty = (party: Party) => {
    setParties((prev) => {
      const idx = prev.findIndex((p) => p.id === party.id);
      let updated: Party[];
      if (idx !== -1) {
        updated = [...prev];
        updated[idx] = party;
      } else {
        updated = [party, ...prev];
      }
      LocalKhataDB.saveParties(updated);
      return updated;
    });
  };

  const handleDeleteParty = (id: string) => {
    if (confirm(lang === 'hi' ? 'क्या आप इस पार्टी को हटाना चाहते हैं?' : 'Delete this party record?')) {
      setParties((prev) => {
        const updated = prev.filter((p) => p.id !== id);
        LocalKhataDB.saveParties(updated);
        return updated;
      });
    }
  };

  const handleSaveItem = (item: Item) => {
    setItems((prev) => {
      const idx = prev.findIndex((i) => i.id === item.id);
      let updated: Item[];
      if (idx !== -1) {
        updated = [...prev];
        updated[idx] = item;
      } else {
        updated = [item, ...prev];
      }
      LocalKhataDB.saveItems(updated);
      return updated;
    });
  };

  const handleDeleteItem = (id: string) => {
    if (confirm(lang === 'hi' ? 'क्या आप इस उत्पाद को हटाना चाहते हैं?' : 'Delete this item?')) {
      setItems((prev) => {
        const updated = prev.filter((i) => i.id !== id);
        LocalKhataDB.saveItems(updated);
        return updated;
      });
    }
  };

  const handleSaveVoucher = (voucher: Voucher, printAfter = false) => {
    // 1. Update stock if applicable
    if (['sales_invoice', 'cash_memo', 'delivery_challan'].includes(voucher.voucherType)) {
      setItems((prev) => {
        const copy = [...prev];
        voucher.items.forEach((vi) => {
          const itemIdx = copy.findIndex((it) => it.id === vi.itemId);
          if (itemIdx !== -1) {
            copy[itemIdx] = {
              ...copy[itemIdx],
              currentStock: Math.max(0, copy[itemIdx].currentStock - vi.quantity),
            };
          }
        });
        LocalKhataDB.saveItems(copy);
        return copy;
      });
    } else if (voucher.voucherType === 'purchase_invoice') {
      setItems((prev) => {
        const copy = [...prev];
        voucher.items.forEach((vi) => {
          const itemIdx = copy.findIndex((it) => it.id === vi.itemId);
          if (itemIdx !== -1) {
            copy[itemIdx] = {
              ...copy[itemIdx],
              currentStock: copy[itemIdx].currentStock + vi.quantity,
            };
          }
        });
        LocalKhataDB.saveItems(copy);
        return copy;
      });
    }

    // 2. Update Party balance if credit
    if (voucher.partyId && voucher.paymentMode === 'credit') {
      setParties((prev) => {
        const copy = [...prev];
        const pIdx = copy.findIndex((p) => p.id === voucher.partyId);
        if (pIdx !== -1) {
          copy[pIdx] = {
            ...copy[pIdx],
            currentBalance: copy[pIdx].currentBalance + voucher.grandTotal,
          };
          LocalKhataDB.saveParties(copy);
        }
        return copy;
      });
    }

    // 3. Save voucher
    setVouchers((prev) => {
      const idx = prev.findIndex((v) => v.id === voucher.id);
      let updated: Voucher[];
      if (idx !== -1) {
        updated = [...prev];
        updated[idx] = voucher;
      } else {
        updated = [voucher, ...prev];
      }
      LocalKhataDB.saveVouchers(updated);
      return updated;
    });

    setIsVoucherModalOpen(false);

    if (printAfter) {
      setPreviewVoucher(voucher);
    }
  };

  const handleOpenNewVoucher = (type: VoucherType) => {
    setCurrentVoucherType(type);
    setEditingVoucher(undefined);
    setIsVoucherModalOpen(true);
  };

  const navItems = [
    { id: 'dashboard', label: t('dashboard', lang), icon: LayoutDashboard },
    { id: 'sales', label: t('sales', lang), icon: Receipt },
    { id: 'purchase', label: t('purchase', lang), icon: ShoppingCart },
    { id: 'payments', label: t('payments', lang), icon: Wallet },
    { id: 'inventory', label: t('inventory', lang), icon: Package },
    { id: 'parties', label: t('parties', lang), icon: Users },
    { id: 'gst-centre', label: t('gstCentre', lang), icon: Percent },
    { id: 'reports', label: t('reports', lang), icon: BarChart3 },
    { id: 'installer', label: t('installer', lang), icon: Download },
    { id: 'settings', label: t('settings', lang), icon: SettingsIcon },
  ];

  if (showBootScreen) {
    return <BootScreen onComplete={() => setShowBootScreen(false)} lang={lang} />;
  }

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans select-text">
      {/* Top Navbar */}
      <header className="no-print sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 py-2.5 flex items-center justify-between shadow-xs">
        {/* Left: Brand Logo & Mobile Menu Toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div
            onClick={() => setActiveRoute('dashboard')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white font-black text-sm shadow-md shadow-emerald-600/20 group-hover:scale-105 transition">
              RK
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-slate-900 tracking-tight text-base">
                  RELAX KHATA
                </span>
                <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded uppercase">
                  v2.4
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium hidden sm:block truncate max-w-[200px]">
                {profile.businessName}
              </p>
            </div>
          </div>
        </div>

        {/* Center: Global Search Bar */}
        <div className="flex-1 max-w-md mx-4 hidden md:block">
          <button
            onClick={() => setIsSearchOpen(true)}
            className="w-full flex items-center justify-between bg-slate-100 hover:bg-slate-200/80 text-slate-500 px-3.5 py-2 rounded-xl text-xs font-medium border border-slate-200 transition cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-slate-400" />
              <span>{t('searchPlaceholder', lang)}</span>
            </div>
            <kbd className="text-[10px] bg-white border border-slate-300 rounded px-1.5 py-0.5 text-slate-400 font-mono">
              Ctrl+K
            </kbd>
          </button>
        </div>

        {/* Right: Actions, Language, HELP ME AI & Admin */}
        <div className="flex items-center gap-2">
          {/* Mobile Search Button */}
          <button
            onClick={() => setIsSearchOpen(true)}
            className="md:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 cursor-pointer"
            title="Global Search"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Bilingual Toggle Button */}
          <button
            onClick={() => handleUpdateLanguage(lang === 'hi' ? 'en' : 'hi')}
            className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-200 transition cursor-pointer"
            title="Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'hi' ? 'English' : 'हिन्दी'}</span>
          </button>

          {/* Prominent App Download Button */}
          <button
            onClick={() => setIsDownloadModalOpen(true)}
            className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 text-xs font-black px-3.5 py-1.5 rounded-xl shadow-md transition cursor-pointer"
            title={lang === 'hi' ? 'मोबाइल में ऍप डाउनलोड व इंस्टॉल करें' : 'Download and install app on mobile'}
          >
            <Smartphone className="w-4 h-4 text-slate-950" />
            <span>{lang === 'hi' ? '📲 ऍप डाउनलोड' : '📲 Install App'}</span>
          </button>

          {/* HELP ME – AI Assistant Button */}
          <button
            onClick={() => setIsHelpMeOpen(true)}
            className="flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold px-3.5 py-1.5 rounded-xl shadow-md shadow-emerald-900/20 transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">HELP ME AI</span>
          </button>

          {/* Owner Admin Panel Access */}
          <button
            onClick={() => setIsAdminOpen(true)}
            className="p-2 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition cursor-pointer"
            title="Admin & AI Telemetry"
          >
            <Lock className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Mobile Sticky Install Alert Strip */}
      <div className="md:hidden no-print bg-gradient-to-r from-emerald-900 via-slate-900 to-emerald-950 text-white px-3.5 py-2 flex items-center justify-between text-xs border-b border-emerald-800 shadow-sm">
        <div className="flex items-center gap-2 truncate">
          <Smartphone className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="font-bold text-[11px] truncate">
            {lang === 'hi' ? 'RELAX KHATA को फोन में इंस्टॉल करें' : 'Install RELAX KHATA on your phone'}
          </span>
        </div>
        <button
          onClick={() => setIsDownloadModalOpen(true)}
          className="bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 font-black px-3 py-1 rounded-lg text-xs shadow-md shrink-0 ml-2 cursor-pointer"
        >
          {lang === 'hi' ? 'डाउनलोड करें' : 'Install App'}
        </button>
      </div>

      {/* Main Container Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar Navigation */}
        <aside className="no-print hidden md:flex flex-col w-64 bg-white border-r border-slate-200 p-3 space-y-1 shrink-0 overflow-y-auto">
          <div className="px-3 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            {lang === 'hi' ? 'मुख्य मेन्यू' : 'Main Menu'}
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeRoute === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveRoute(item.id as ScreenRoute)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer text-left ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-700/20'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}

          {/* Bottom Offline Status Widget */}
          <div className="mt-auto pt-4 border-t border-slate-100 px-3 py-2">
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-xs text-emerald-950 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-emerald-800">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping inline-block" />
                <span>100% Offline Ready</span>
              </div>
              <p className="text-[11px] text-emerald-700 leading-tight">
                Data stored securely in local database. Auto sync when online.
              </p>
            </div>
          </div>
        </aside>

        {/* Mobile Slide-over Drawer Navigation */}
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-50 md:hidden bg-slate-950/70 backdrop-blur-xs flex">
            <div className="w-4/5 max-w-xs bg-white h-full p-4 flex flex-col justify-between shadow-2xl animate-in slide-in-from-left duration-200">
              <div className="space-y-2">
                <div className="flex justify-between items-center pb-3 border-b border-slate-200">
                  <span className="font-black text-slate-900 text-base">RELAX KHATA</span>
                  <button
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="p-1 text-slate-500 hover:text-slate-900 rounded cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-1 pt-2">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeRoute === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveRoute(item.id as ScreenRoute);
                          setIsMobileMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition text-left ${
                          isActive
                            ? 'bg-emerald-600 text-white'
                            : 'text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="text-[11px] text-slate-400 text-center py-2 border-t border-slate-100">
                v2.4.0 Pro Enterprise
              </div>
            </div>
            <div className="flex-1" onClick={() => setIsMobileMenuOpen(false)} />
          </div>
        )}

        {/* Primary Content View Container */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-7xl mx-auto">
            {activeRoute === 'dashboard' && (
              <DashboardView
                vouchers={vouchers}
                items={items}
                parties={parties}
                onNavigate={(route, _id) => setActiveRoute(route)}
                onOpenNewVoucher={handleOpenNewVoucher}
                onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
                lang={lang}
              />
            )}

            {activeRoute === 'sales' && (
              <SalesView
                vouchers={vouchers}
                profile={profile}
                onOpenNewVoucher={handleOpenNewVoucher}
                onOpenPreview={(v) => setPreviewVoucher(v)}
                onDeleteVoucher={(id) => {
                  setVouchers((prev) => {
                    const updated = prev.filter((v) => v.id !== id);
                    LocalKhataDB.saveVouchers(updated);
                    return updated;
                  });
                }}
                lang={lang}
              />
            )}

            {activeRoute === 'purchase' && (
              <PurchaseView
                vouchers={vouchers}
                profile={profile}
                onOpenNewVoucher={handleOpenNewVoucher}
                onOpenPreview={(v) => setPreviewVoucher(v)}
                lang={lang}
              />
            )}

            {activeRoute === 'payments' && (
              <PaymentsView
                vouchers={vouchers}
                parties={parties}
                profile={profile}
                onOpenNewVoucher={handleOpenNewVoucher}
                lang={lang}
              />
            )}

            {activeRoute === 'inventory' && (
              <InventoryView
                items={items}
                onSaveItem={handleSaveItem}
                onDeleteItem={handleDeleteItem}
                lang={lang}
              />
            )}

            {activeRoute === 'parties' && (
              <PartiesView
                parties={parties}
                vouchers={vouchers}
                profile={profile}
                onSaveParty={handleSaveParty}
                onDeleteParty={handleDeleteParty}
                lang={lang}
              />
            )}

            {activeRoute === 'gst-centre' && (
              <GSTCentreView
                vouchers={vouchers}
                profile={profile}
                portal2B={portal2B}
                onUpdatePortal2B={(data) => {
                  setPortal2B(data);
                  LocalKhataDB.savePortal2B(data);
                }}
                lang={lang}
              />
            )}

            {activeRoute === 'reports' && (
              <ReportsView
                vouchers={vouchers}
                items={items}
                parties={parties}
                profile={profile}
                lang={lang}
              />
            )}

            {activeRoute === 'installer' && <InstallerView lang={lang} />}

            {activeRoute === 'settings' && (
              <SettingsView
                profile={profile}
                onUpdateProfile={handleSaveProfile}
                lang={lang}
                onUpdateLanguage={handleUpdateLanguage}
                fontScale={fontScale}
                onUpdateFontScale={handleUpdateFontScale}
              />
            )}
          </div>
        </main>
      </div>

      {/* Mobile Sticky Bottom Navigation Bar */}
      <nav className="no-print md:hidden bg-white border-t border-slate-200 flex justify-around items-center py-2 px-1 shadow-lg shrink-0">
        {[
          { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
          { id: 'sales', label: 'Sales', icon: Receipt },
          { id: 'purchase', label: 'Purchase', icon: ShoppingCart },
          { id: 'parties', label: 'Parties', icon: Users },
          { id: 'gst-centre', label: 'GST', icon: Percent },
          { id: 'download_modal', label: lang === 'hi' ? 'ऍप इंस्टॉल' : 'Install', icon: Smartphone, isDownloadAction: true },
        ].map((item: any) => {
          const Icon = item.icon;
          const isActive = activeRoute === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                if (item.isDownloadAction) {
                  setIsDownloadModalOpen(true);
                } else {
                  setActiveRoute(item.id as ScreenRoute);
                }
              }}
              className={`flex flex-col items-center py-1 px-1.5 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                item.isDownloadAction
                  ? 'text-amber-600 bg-amber-50 font-black'
                  : isActive
                  ? 'text-emerald-700'
                  : 'text-slate-500'
              }`}
            >
              <Icon className="w-4 h-4 mb-0.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Global Modals */}
      <DownloadAppModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        lang={lang}
      />
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        parties={parties}
        items={items}
        vouchers={vouchers}
        onNavigate={(route) => setActiveRoute(route)}
        lang={lang}
      />

      <HelpMeAIModal
        isOpen={isHelpMeOpen}
        onClose={() => setIsHelpMeOpen(false)}
        onNavigate={(route) => setActiveRoute(route)}
        lang={lang}
        businessName={profile.businessName}
      />

      <AdminDashboardModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        lang={lang}
      />

      {isVoucherModalOpen && (
        <VoucherModal
          isOpen={isVoucherModalOpen}
          onClose={() => setIsVoucherModalOpen(false)}
          onSave={handleSaveVoucher}
          voucherType={currentVoucherType}
          parties={parties}
          items={items}
          profile={profile}
          initialVoucher={editingVoucher}
          lang={lang}
        />
      )}

      {previewVoucher && (
        <InvoicePreviewModal
          isOpen={Boolean(previewVoucher)}
          onClose={() => setPreviewVoucher(null)}
          voucher={previewVoucher}
          profile={profile}
          lang={lang}
        />
      )}
    </div>
  );
}
