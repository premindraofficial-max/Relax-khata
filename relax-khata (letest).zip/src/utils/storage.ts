import { BusinessProfile, Party, Item, Voucher, GSTR2BItem } from '../types';

const STORAGE_KEYS = {
  PROFILE: 'relax_khata_profile',
  PARTIES: 'relax_khata_parties',
  ITEMS: 'relax_khata_items',
  VOUCHERS: 'relax_khata_vouchers',
  GSTR2B: 'relax_khata_gstr2b_portal',
  SETTINGS: 'relax_khata_settings',
  RECENT_SEARCHES: 'relax_khata_recent_searches',
  FONT_SCALE: 'relax_khata_font_scale',
  LANGUAGE: 'relax_khata_language',
};

export const DEFAULT_PROFILE: BusinessProfile = {
  id: 'biz-01',
  businessName: 'SHREE SHYAM ENTERPRISES',
  tradeName: 'श्री श्याम एंटरप्राइजेज',
  gstin: '07AAAAA1234A1Z5',
  pan: 'AAAAA1234A',
  state: 'Delhi',
  stateCode: '07',
  address: 'Shop No. 42, Commercial Complex, Connaught Place, New Delhi - 110001',
  phone: '+91 98765 43210',
  email: 'contact@shreeshyamenterprises.com',
  bankName: 'HDFC Bank Ltd',
  bankAccountNo: '50200045678912',
  bankIfsc: 'HDFC0001234',
  bankBranch: 'Connaught Place New Delhi',
  upiId: 'shreeshyam@okhdfcbank',
  financialYear: '2024-2025',
  compositionScheme: false,
  invoicePrefix: 'SK/24-25/',
  termsAndConditions: '1. Goods once sold will not be taken back.\n2. Interest @ 18% p.a. will be charged if payment is delayed beyond due date.\n3. Subject to Delhi Jurisdiction only.',
};

export const INITIAL_PARTIES: Party[] = [
  {
    id: 'p-1',
    type: 'customer',
    name: 'Sharma Electronics & Appliances',
    mobile: '9811122233',
    email: 'sharmaelec@gmail.com',
    gstin: '07BBBBB2345B1Z4',
    address: 'Plot 12, Main Market, Karol Bagh, Delhi - 110005',
    state: 'Delhi',
    stateCode: '07',
    openingBalance: 15000,
    balanceType: 'dr',
    creditLimit: 250000,
    paymentTerms: 'Net 15 Days',
    currentBalance: 52400,
    createdAt: '2024-04-01',
  },
  {
    id: 'p-2',
    type: 'customer',
    name: 'Kalyan Traders & Wholesalers',
    mobile: '9822233344',
    email: 'kalyantraders@outlook.com',
    gstin: '08CCCCC3456C1Z3', // Rajasthan (Inter-state IGST)
    address: 'B-4, Transport Nagar, Jaipur, Rajasthan - 302004',
    state: 'Rajasthan',
    stateCode: '08',
    openingBalance: 32000,
    balanceType: 'dr',
    creditLimit: 500000,
    paymentTerms: 'Net 30 Days',
    currentBalance: 78500,
    createdAt: '2024-04-02',
  },
  {
    id: 'p-3',
    type: 'customer',
    name: 'Rajdhani General Store (Retail Cash)',
    mobile: '9833344455',
    email: 'rajdhanistore@gmail.com',
    gstin: '', // Unregistered B2C
    address: 'Sector 14, Rohini, Delhi - 110085',
    state: 'Delhi',
    stateCode: '07',
    openingBalance: 0,
    balanceType: 'dr',
    creditLimit: 50000,
    paymentTerms: 'Immediate',
    currentBalance: 0,
    createdAt: '2024-04-05',
  },
  {
    id: 'p-4',
    type: 'supplier',
    name: 'Surya Electricals & Cables Ltd',
    mobile: '9844455566',
    email: 'orders@suryacables.com',
    gstin: '07DDDDD4567D1Z2',
    address: 'Industrial Area Phase 2, Okhla, New Delhi - 110020',
    state: 'Delhi',
    stateCode: '07',
    openingBalance: 45000,
    balanceType: 'cr',
    creditLimit: 1000000,
    paymentTerms: 'Net 30 Days',
    currentBalance: 34500,
    createdAt: '2024-04-01',
  },
  {
    id: 'p-5',
    type: 'supplier',
    name: 'Bharat Tech Industries',
    mobile: '9855566677',
    email: 'info@bharattech.com',
    gstin: '27EEEEE5678E1Z1', // Maharashtra (IGST)
    address: 'MIDC Industrial Estate, Andheri East, Mumbai - 400093',
    state: 'Maharashtra',
    stateCode: '27',
    openingBalance: 20000,
    balanceType: 'cr',
    creditLimit: 800000,
    paymentTerms: 'Net 21 Days',
    currentBalance: 65000,
    createdAt: '2024-04-03',
  },
];

export const INITIAL_ITEMS: Item[] = [
  {
    id: 'item-1',
    name: 'LED Smart Android TV 43 Inch 4K UHD',
    category: 'Electronics',
    unit: 'PCS',
    hsnCode: '8528',
    gstRate: 18,
    purchasePrice: 19500,
    salePrice: 24900,
    wholesalePrice: 22800,
    retailPrice: 25999,
    openingStock: 25,
    currentStock: 18,
    minStockAlert: 5,
    negativeStockAllowed: false,
    batchNo: 'B-2401',
    expiryDate: '2028-12-31',
    barcode: '8901234567890',
    updatedAt: '2024-04-10',
  },
  {
    id: 'item-2',
    name: 'Heavy Duty Copper Power Cable 2.5 sq mm (90m Roll)',
    category: 'Electricals',
    unit: 'BOX',
    hsnCode: '8544',
    gstRate: 18,
    purchasePrice: 2650,
    salePrice: 3450,
    wholesalePrice: 3100,
    retailPrice: 3600,
    openingStock: 60,
    currentStock: 42,
    minStockAlert: 10,
    negativeStockAllowed: false,
    batchNo: 'C-902',
    barcode: '8901234567891',
    updatedAt: '2024-04-10',
  },
  {
    id: 'item-3',
    name: 'Royal Basmati Rice Premium Export Quality (25 Kg Bag)',
    category: 'Groceries',
    unit: 'BAG',
    hsnCode: '1006',
    gstRate: 5,
    purchasePrice: 2350,
    salePrice: 2850,
    wholesalePrice: 2650,
    retailPrice: 2950,
    openingStock: 100,
    currentStock: 68,
    minStockAlert: 15,
    negativeStockAllowed: false,
    batchNo: 'R-401',
    expiryDate: '2026-06-30',
    barcode: '8901234567892',
    updatedAt: '2024-04-10',
  },
  {
    id: 'item-4',
    name: 'Tri-Ply Stainless Steel Cookware Gift Set (5 Pcs)',
    category: 'Home Appliances',
    unit: 'SET',
    hsnCode: '7323',
    gstRate: 12,
    purchasePrice: 3200,
    salePrice: 4400,
    wholesalePrice: 3950,
    retailPrice: 4750,
    openingStock: 40,
    currentStock: 24,
    minStockAlert: 8,
    negativeStockAllowed: false,
    batchNo: 'SS-77',
    barcode: '8901234567893',
    updatedAt: '2024-04-10',
  },
  {
    id: 'item-5',
    name: 'Microfiber Super Absorbent Cleaning Cloths (Pack of 10)',
    category: 'Accessories',
    unit: 'PACK',
    hsnCode: '6307',
    gstRate: 12,
    purchasePrice: 240,
    salePrice: 450,
    wholesalePrice: 380,
    retailPrice: 499,
    openingStock: 200,
    currentStock: 140,
    minStockAlert: 25,
    negativeStockAllowed: false,
    batchNo: 'MF-01',
    barcode: '8901234567894',
    updatedAt: '2024-04-10',
  },
  {
    id: 'item-6',
    name: 'Energy Saving Smart BLDC Ceiling Fan 1200mm',
    category: 'Electricals',
    unit: 'NOS',
    hsnCode: '8414',
    gstRate: 18,
    purchasePrice: 2450,
    salePrice: 3290,
    wholesalePrice: 2950,
    retailPrice: 3499,
    openingStock: 15,
    currentStock: 4, // Low stock alert triggered!
    minStockAlert: 6,
    negativeStockAllowed: false,
    batchNo: 'FAN-2024',
    barcode: '8901234567895',
    updatedAt: '2024-04-10',
  },
];

export const INITIAL_VOUCHERS: Voucher[] = [
  {
    id: 'v-101',
    voucherNo: 'SK/24-25/001',
    voucherType: 'sales_invoice',
    date: '2024-04-15',
    dueDate: '2024-04-30',
    partyId: 'p-1',
    partyName: 'Sharma Electronics & Appliances',
    partyGstin: '07BBBBB2345B1Z4',
    partyAddress: 'Plot 12, Main Market, Karol Bagh, Delhi - 110005',
    partyState: 'Delhi',
    partyStateCode: '07',
    items: [
      {
        id: 'vi-1',
        itemId: 'item-1',
        itemName: 'LED Smart Android TV 43 Inch 4K UHD',
        hsnCode: '8528',
        quantity: 2,
        unit: 'PCS',
        rate: 24900,
        discountPercent: 0,
        discountAmount: 0,
        taxableAmount: 49800,
        gstRate: 18,
        cgstAmount: 4482,
        sgstAmount: 4482,
        igstAmount: 0,
        cessAmount: 0,
        totalAmount: 58764,
        batchNo: 'B-2401',
      },
    ],
    subtotal: 49800,
    discount: 0,
    taxableAmount: 49800,
    cgst: 4482,
    sgst: 4482,
    igst: 0,
    cess: 0,
    roundOff: 0,
    grandTotal: 58764,
    paymentMode: 'credit',
    narration: 'B2B Sales Invoice to registered dealer in Delhi',
    templateId: 'modern',
    status: 'partial',
    paidAmount: 20000,
    createdAt: '2024-04-15T10:30:00.000Z',
  },
  {
    id: 'v-102',
    voucherNo: 'SK/24-25/002',
    voucherType: 'sales_invoice',
    date: '2024-04-18',
    dueDate: '2024-05-18',
    partyId: 'p-2',
    partyName: 'Kalyan Traders & Wholesalers',
    partyGstin: '08CCCCC3456C1Z3', // Rajasthan (Inter-State IGST)
    partyAddress: 'B-4, Transport Nagar, Jaipur, Rajasthan - 302004',
    partyState: 'Rajasthan',
    partyStateCode: '08',
    items: [
      {
        id: 'vi-2',
        itemId: 'item-2',
        itemName: 'Heavy Duty Copper Power Cable 2.5 sq mm (90m Roll)',
        hsnCode: '8544',
        quantity: 10,
        unit: 'BOX',
        rate: 3450,
        discountPercent: 5,
        discountAmount: 1725,
        taxableAmount: 32775,
        gstRate: 18,
        cgstAmount: 0,
        sgstAmount: 0,
        igstAmount: 5899.5,
        cessAmount: 0,
        totalAmount: 38674.5,
        batchNo: 'C-902',
      },
      {
        id: 'vi-3',
        itemId: 'item-3',
        itemName: 'Royal Basmati Rice Premium Export Quality (25 Kg Bag)',
        hsnCode: '1006',
        quantity: 10,
        unit: 'BAG',
        rate: 2850,
        discountPercent: 0,
        discountAmount: 0,
        taxableAmount: 28500,
        gstRate: 5,
        cgstAmount: 0,
        sgstAmount: 0,
        igstAmount: 1425,
        cessAmount: 0,
        totalAmount: 29925,
        batchNo: 'R-401',
      },
    ],
    subtotal: 63000,
    discount: 1725,
    taxableAmount: 61275,
    cgst: 0,
    sgst: 0,
    igst: 7324.5,
    cess: 0,
    roundOff: 0.5,
    grandTotal: 68600,
    paymentMode: 'credit',
    narration: 'Inter-state B2B supply to Rajasthan with IGST applied',
    templateId: 'classic',
    status: 'unpaid',
    paidAmount: 0,
    createdAt: '2024-04-18T14:15:00.000Z',
  },
  {
    id: 'v-103',
    voucherNo: 'SK/24-25/003',
    voucherType: 'cash_memo',
    date: '2024-04-20',
    partyName: 'Rajdhani General Store (Retail Cash)',
    partyState: 'Delhi',
    partyStateCode: '07',
    items: [
      {
        id: 'vi-4',
        itemId: 'item-4',
        itemName: 'Tri-Ply Stainless Steel Cookware Gift Set (5 Pcs)',
        hsnCode: '7323',
        quantity: 1,
        unit: 'SET',
        rate: 4400,
        discountPercent: 0,
        discountAmount: 0,
        taxableAmount: 4400,
        gstRate: 12,
        cgstAmount: 264,
        sgstAmount: 264,
        igstAmount: 0,
        cessAmount: 0,
        totalAmount: 4928,
      },
    ],
    subtotal: 4400,
    discount: 0,
    taxableAmount: 4400,
    cgst: 264,
    sgst: 264,
    igst: 0,
    cess: 0,
    roundOff: 0,
    grandTotal: 4928,
    paymentMode: 'upi',
    narration: 'Retail B2C Cash Memo paid via UPI',
    templateId: 'retail',
    status: 'paid',
    paidAmount: 4928,
    createdAt: '2024-04-20T16:00:00.000Z',
  },
  {
    id: 'v-201',
    voucherNo: 'PUR/24-25/014',
    voucherType: 'purchase_invoice',
    date: '2024-04-10',
    dueDate: '2024-05-10',
    partyId: 'p-4',
    partyName: 'Surya Electricals & Cables Ltd',
    partyGstin: '07DDDDD4567D1Z2',
    partyAddress: 'Industrial Area Phase 2, Okhla, New Delhi - 110020',
    partyState: 'Delhi',
    partyStateCode: '07',
    items: [
      {
        id: 'vi-5',
        itemId: 'item-2',
        itemName: 'Heavy Duty Copper Power Cable 2.5 sq mm (90m Roll)',
        hsnCode: '8544',
        quantity: 20,
        unit: 'BOX',
        rate: 2650,
        discountPercent: 0,
        discountAmount: 0,
        taxableAmount: 53000,
        gstRate: 18,
        cgstAmount: 4770,
        sgstAmount: 4770,
        igstAmount: 0,
        cessAmount: 0,
        totalAmount: 62540,
      },
    ],
    subtotal: 53000,
    discount: 0,
    taxableAmount: 53000,
    cgst: 4770,
    sgst: 4770,
    igst: 0,
    cess: 0,
    roundOff: 0,
    grandTotal: 62540,
    paymentMode: 'credit',
    narration: 'Stock purchase for cable boxes with ITC eligible',
    templateId: 'minimal',
    status: 'unpaid',
    paidAmount: 0,
    createdAt: '2024-04-10T11:00:00.000Z',
  },
  {
    id: 'v-202',
    voucherNo: 'PUR/24-25/019',
    voucherType: 'purchase_invoice',
    date: '2024-04-14',
    dueDate: '2024-05-05',
    partyId: 'p-5',
    partyName: 'Bharat Tech Industries',
    partyGstin: '27EEEEE5678E1Z1',
    partyAddress: 'MIDC Industrial Estate, Andheri East, Mumbai - 400093',
    partyState: 'Maharashtra',
    partyStateCode: '27',
    items: [
      {
        id: 'vi-6',
        itemId: 'item-1',
        itemName: 'LED Smart Android TV 43 Inch 4K UHD',
        hsnCode: '8528',
        quantity: 5,
        unit: 'PCS',
        rate: 19500,
        discountPercent: 0,
        discountAmount: 0,
        taxableAmount: 97500,
        gstRate: 18,
        cgstAmount: 0,
        sgstAmount: 0,
        igstAmount: 17550,
        cessAmount: 0,
        totalAmount: 115050,
      },
    ],
    subtotal: 97500,
    discount: 0,
    taxableAmount: 97500,
    cgst: 0,
    sgst: 0,
    igst: 17550,
    cess: 0,
    roundOff: 0,
    grandTotal: 115050,
    paymentMode: 'bank',
    narration: 'Interstate purchase of TVs via RTGS with full IGST ITC',
    templateId: 'corporate',
    status: 'paid',
    paidAmount: 115050,
    createdAt: '2024-04-14T09:45:00.000Z',
  },
  {
    id: 'v-301',
    voucherNo: 'RCP/24-25/001',
    voucherType: 'payment_in',
    date: '2024-04-22',
    partyId: 'p-1',
    partyName: 'Sharma Electronics & Appliances',
    items: [],
    subtotal: 20000,
    discount: 0,
    taxableAmount: 0,
    cgst: 0,
    sgst: 0,
    igst: 0,
    cess: 0,
    roundOff: 0,
    grandTotal: 20000,
    paymentMode: 'bank',
    narration: 'Part payment received via NEFT against Inv SK/24-25/001',
    templateId: 'modern',
    status: 'paid',
    paidAmount: 20000,
    createdAt: '2024-04-22T12:00:00.000Z',
  },
  {
    id: 'v-401',
    voucherNo: 'CNT/24-25/001',
    voucherType: 'contra',
    date: '2024-04-24',
    partyName: 'Bank Deposit (Cash to HDFC Bank)',
    items: [],
    subtotal: 15000,
    discount: 0,
    taxableAmount: 0,
    cgst: 0,
    sgst: 0,
    igst: 0,
    cess: 0,
    roundOff: 0,
    grandTotal: 15000,
    paymentMode: 'cash',
    narration: 'Cash deposited into HDFC Current Account',
    templateId: 'classic',
    status: 'paid',
    paidAmount: 15000,
    createdAt: '2024-04-24T15:30:00.000Z',
  },
  {
    id: 'v-501',
    voucherNo: 'EXP/24-25/001',
    voucherType: 'expense',
    date: '2024-04-25',
    partyName: 'Electricity Board & Office Rent',
    items: [],
    subtotal: 8500,
    discount: 0,
    taxableAmount: 8500,
    cgst: 0,
    sgst: 0,
    igst: 0,
    cess: 0,
    roundOff: 0,
    grandTotal: 8500,
    paymentMode: 'bank',
    narration: 'Office electricity and commercial maintenance charges',
    templateId: 'modern',
    status: 'paid',
    paidAmount: 8500,
    createdAt: '2024-04-25T11:00:00.000Z',
  },
];

// Sample GSTR-2B data downloaded from GST portal for reconciliation comparison
export const SAMPLE_PORTAL_GSTR2B: GSTR2BItem[] = [
  {
    gstin: '07DDDDD4567D1Z2',
    supplierName: 'Surya Electricals & Cables Ltd',
    invoiceNo: 'PUR/24-25/014',
    invoiceDate: '2024-04-10',
    invoiceType: 'Regular',
    taxableValue: 53000,
    cgst: 4770,
    sgst: 4770,
    igst: 0,
    cess: 0,
    filingDate: '2024-05-11',
    itcAvailable: 'Y',
  },
  {
    gstin: '27EEEEE5678E1Z1',
    supplierName: 'Bharat Tech Industries',
    invoiceNo: 'PUR/24-25/019',
    invoiceDate: '2024-04-14',
    invoiceType: 'Regular',
    taxableValue: 97500,
    cgst: 0,
    sgst: 0,
    igst: 17550,
    cess: 0,
    filingDate: '2024-05-12',
    itcAvailable: 'Y',
  },
  {
    gstin: '07FFFFF6789F1Z0',
    supplierName: 'Delta Logistics & Packaging Solutions',
    invoiceNo: 'DL/24/098',
    invoiceDate: '2024-04-20',
    invoiceType: 'Regular',
    taxableValue: 12000,
    cgst: 1080,
    sgst: 1080,
    igst: 0,
    cess: 0,
    filingDate: '2024-05-11',
    itcAvailable: 'Y',
  },
];

// Storage Engine
export class LocalKhataDB {
  static getProfile(): BusinessProfile {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return data ? JSON.parse(data) : DEFAULT_PROFILE;
    } catch {
      return DEFAULT_PROFILE;
    }
  }

  static saveProfile(profile: BusinessProfile): void {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
  }

  static getParties(): Party[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PARTIES);
      return data ? JSON.parse(data) : INITIAL_PARTIES;
    } catch {
      return INITIAL_PARTIES;
    }
  }

  static saveParties(parties: Party[]): void {
    localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(parties));
  }

  static getItems(): Item[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ITEMS);
      return data ? JSON.parse(data) : INITIAL_ITEMS;
    } catch {
      return INITIAL_ITEMS;
    }
  }

  static saveItems(items: Item[]): void {
    localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify(items));
  }

  static getVouchers(): Voucher[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.VOUCHERS);
      return data ? JSON.parse(data) : INITIAL_VOUCHERS;
    } catch {
      return INITIAL_VOUCHERS;
    }
  }

  static saveVouchers(vouchers: Voucher[]): void {
    localStorage.setItem(STORAGE_KEYS.VOUCHERS, JSON.stringify(vouchers));
  }

  static getPortal2B(): GSTR2BItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.GSTR2B);
      return data ? JSON.parse(data) : SAMPLE_PORTAL_GSTR2B;
    } catch {
      return SAMPLE_PORTAL_GSTR2B;
    }
  }

  static savePortal2B(data: GSTR2BItem[]): void {
    localStorage.setItem(STORAGE_KEYS.GSTR2B, JSON.stringify(data));
  }

  static getFontScale(): number {
    try {
      const scale = localStorage.getItem(STORAGE_KEYS.FONT_SCALE);
      return scale ? parseFloat(scale) : 1;
    } catch {
      return 1;
    }
  }

  static saveFontScale(scale: number): void {
    localStorage.setItem(STORAGE_KEYS.FONT_SCALE, scale.toString());
    document.documentElement.style.setProperty('--app-font-scale', scale.toString());
  }

  static getRecentSearches(): string[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.RECENT_SEARCHES);
      return data ? JSON.parse(data) : ['Sharma Electronics', 'LED Smart Android TV', 'SK/24-25/001', 'GSTR-1'];
    } catch {
      return [];
    }
  }

  static addRecentSearch(query: string): void {
    if (!query.trim()) return;
    const existing = this.getRecentSearches().filter((q) => q.toLowerCase() !== query.toLowerCase());
    existing.unshift(query.trim());
    localStorage.setItem(STORAGE_KEYS.RECENT_SEARCHES, JSON.stringify(existing.slice(0, 8)));
  }

  // Backup & Restore
  static exportFullBackupJSON(): string {
    const backup = {
      app: 'RELAX KHATA',
      version: '2.4.0',
      exportedAt: new Date().toISOString(),
      profile: this.getProfile(),
      parties: this.getParties(),
      items: this.getItems(),
      vouchers: this.getVouchers(),
      portal2b: this.getPortal2B(),
    };
    return JSON.stringify(backup, null, 2);
  }

  static restoreFromBackupJSON(jsonStr: string): boolean {
    try {
      const backup = JSON.parse(jsonStr);
      if (backup.profile) this.saveProfile(backup.profile);
      if (backup.parties) this.saveParties(backup.parties);
      if (backup.items) this.saveItems(backup.items);
      if (backup.vouchers) this.saveVouchers(backup.vouchers);
      if (backup.portal2b) this.savePortal2B(backup.portal2b);
      return true;
    } catch (e) {
      console.error('Failed to restore backup:', e);
      return false;
    }
  }
}
