import { Voucher, BusinessProfile, GSTR2BItem, ReconRow } from '../types';

export interface GSTR1Summary {
  b2bCount: number;
  b2bTaxable: number;
  b2bCgst: number;
  b2bSgst: number;
  b2bIgst: number;
  b2bTotal: number;

  b2csCount: number;
  b2csTaxable: number;
  b2csCgst: number;
  b2csSgst: number;
  b2csIgst: number;
  b2csTotal: number;

  cdnrCount: number;
  cdnrTaxable: number;
  cdnrTotal: number;

  totalTaxable: number;
  totalTax: number;
  totalInvoiceValue: number;

  hsnSummary: Array<{
    hsnCode: string;
    description: string;
    unit: string;
    totalQty: number;
    totalValue: number;
    taxableValue: number;
    igst: number;
    cgst: number;
    sgst: number;
    cess: number;
  }>;
}

export function computeGSTR1Data(vouchers: Voucher[], _profile: BusinessProfile): GSTR1Summary {
  const salesVouchers = vouchers.filter(
    (v) => (v.voucherType === 'sales_invoice' || v.voucherType === 'cash_memo') && !v.isCancelled
  );

  let b2bCount = 0;
  let b2bTaxable = 0;
  let b2bCgst = 0;
  let b2bSgst = 0;
  let b2bIgst = 0;
  let b2bTotal = 0;

  let b2csCount = 0;
  let b2csTaxable = 0;
  let b2csCgst = 0;
  let b2csSgst = 0;
  let b2csIgst = 0;
  let b2csTotal = 0;

  const hsnMap: Record<string, {
    hsnCode: string;
    description: string;
    unit: string;
    totalQty: number;
    totalValue: number;
    taxableValue: number;
    igst: number;
    cgst: number;
    sgst: number;
    cess: number;
  }> = {};

  salesVouchers.forEach((v) => {
    const isB2B = Boolean(v.partyGstin && v.partyGstin.trim().length === 15);
    if (isB2B) {
      b2bCount++;
      b2bTaxable += v.taxableAmount || 0;
      b2bCgst += v.cgst || 0;
      b2bSgst += v.sgst || 0;
      b2bIgst += v.igst || 0;
      b2bTotal += v.grandTotal || 0;
    } else {
      b2csCount++;
      b2csTaxable += v.taxableAmount || 0;
      b2csCgst += v.cgst || 0;
      b2csSgst += v.sgst || 0;
      b2csIgst += v.igst || 0;
      b2csTotal += v.grandTotal || 0;
    }

    // Accumulate HSN table
    (v.items || []).forEach((item) => {
      const code = item.hsnCode || 'N/A';
      if (!hsnMap[code]) {
        hsnMap[code] = {
          hsnCode: code,
          description: item.itemName,
          unit: item.unit || 'PCS',
          totalQty: 0,
          totalValue: 0,
          taxableValue: 0,
          igst: 0,
          cgst: 0,
          sgst: 0,
          cess: 0,
        };
      }
      hsnMap[code].totalQty += item.quantity || 0;
      hsnMap[code].totalValue += item.totalAmount || 0;
      hsnMap[code].taxableValue += item.taxableAmount || 0;
      hsnMap[code].cgst += item.cgstAmount || 0;
      hsnMap[code].sgst += item.sgstAmount || 0;
      hsnMap[code].igst += item.igstAmount || 0;
      hsnMap[code].cess += item.cessAmount || 0;
    });
  });

  const totalTaxable = b2bTaxable + b2csTaxable;
  const totalTax = b2bCgst + b2bSgst + b2bIgst + b2csCgst + b2csSgst + b2csIgst;
  const totalInvoiceValue = b2bTotal + b2csTotal;

  return {
    b2bCount,
    b2bTaxable,
    b2bCgst,
    b2bSgst,
    b2bIgst,
    b2bTotal,
    b2csCount,
    b2csTaxable,
    b2csCgst,
    b2csSgst,
    b2csIgst,
    b2csTotal,
    cdnrCount: 0,
    cdnrTaxable: 0,
    cdnrTotal: 0,
    totalTaxable,
    totalTax,
    totalInvoiceValue,
    hsnSummary: Object.values(hsnMap),
  };
}

// Generates official GST Portal GSTR-1 Upload JSON format
export function generateOfficialGSTR1JSON(
  vouchers: Voucher[],
  profile: BusinessProfile,
  period = '042024'
): object {
  const salesVouchers = vouchers.filter(
    (v) => (v.voucherType === 'sales_invoice' || v.voucherType === 'cash_memo') && !v.isCancelled
  );

  // Group B2B by Buyer GSTIN
  const b2bGrouped: Record<string, any[]> = {};

  salesVouchers.forEach((v) => {
    if (v.partyGstin && v.partyGstin.trim().length === 15) {
      if (!b2bGrouped[v.partyGstin]) {
        b2bGrouped[v.partyGstin] = [];
      }
      b2bGrouped[v.partyGstin].push({
        inum: v.voucherNo,
        idt: v.date.split('-').reverse().join('-'), // DD-MM-YYYY format for portal
        val: v.grandTotal,
        pos: v.partyStateCode || profile.stateCode,
        rchrg: 'N',
        inv_typ: 'R',
        itms: (v.items || []).map((it, idx) => ({
          num: idx + 1,
          itm_det: {
            rt: it.gstRate,
            txval: it.taxableAmount,
            iamt: it.igstAmount || 0,
            camt: it.cgstAmount || 0,
            samt: it.sgstAmount || 0,
            csamt: it.cessAmount || 0,
          },
        })),
      });
    }
  });

  const b2bPayload = Object.entries(b2bGrouped).map(([ctin, inv]) => ({
    ctin,
    inv,
  }));

  // B2CS payload
  const b2csPayload = salesVouchers
    .filter((v) => !v.partyGstin || v.partyGstin.trim().length !== 15)
    .map((v) => ({
      sply_ty: v.partyStateCode === profile.stateCode ? 'INTRA' : 'INTER',
      pos: v.partyStateCode || profile.stateCode,
      typ: 'OE',
      rt: v.items?.[0]?.gstRate || 18,
      txval: v.taxableAmount,
      iamt: v.igst || 0,
      camt: v.cgst || 0,
      samt: v.sgst || 0,
      csamt: v.cess || 0,
    }));

  // HSN payload
  const hsnMap: Record<string, any> = {};
  salesVouchers.forEach((v) => {
    (v.items || []).forEach((item) => {
      const code = item.hsnCode || '8528';
      if (!hsnMap[code]) {
        hsnMap[code] = {
          num: Object.keys(hsnMap).length + 1,
          hsn_sc: code,
          desc: item.itemName,
          uqc: item.unit || 'PCS',
          qty: 0,
          val: 0,
          txval: 0,
          iamt: 0,
          camt: 0,
          samt: 0,
          csamt: 0,
        };
      }
      hsnMap[code].qty += item.quantity || 0;
      hsnMap[code].val += item.totalAmount || 0;
      hsnMap[code].txval += item.taxableAmount || 0;
      hsnMap[code].camt += item.cgstAmount || 0;
      hsnMap[code].samt += item.sgstAmount || 0;
      hsnMap[code].iamt += item.igstAmount || 0;
    });
  });

  return {
    gstin: profile.gstin,
    fp: period,
    cur_gt: 1500000,
    b2b: b2bPayload,
    b2cs: b2csPayload,
    hsn: {
      data: Object.values(hsnMap),
    },
    doc_issue: {
      doc_det: [
        {
          doc_num: 1,
          doc_typ: 'Invoices for outward supply',
          docs: [
            {
              num: 1,
              from: salesVouchers[0]?.voucherNo || 'SK/24-25/001',
              to: salesVouchers[salesVouchers.length - 1]?.voucherNo || 'SK/24-25/003',
              totnum: salesVouchers.length,
              canc: 0,
              net_issue: salesVouchers.length,
            },
          ],
        },
      ],
    },
  };
}

// GSTR-3B Table Generation
export interface GSTR3BSummary {
  outwardTaxable: {
    taxable: number;
    igst: number;
    cgst: number;
    sgst: number;
    cess: number;
  };
  zeroRated: {
    taxable: number;
    igst: number;
    cess: number;
  };
  inwardRcm: {
    taxable: number;
    igst: number;
    cgst: number;
    sgst: number;
  };
  eligibleItc: {
    allOtherItc: {
      igst: number;
      cgst: number;
      sgst: number;
      cess: number;
    };
    totalItc: number;
  };
  netTaxPayable: {
    igst: number;
    cgst: number;
    sgst: number;
    total: number;
  };
}

export function computeGSTR3B(vouchers: Voucher[]): GSTR3BSummary {
  const sales = vouchers.filter((v) => (v.voucherType === 'sales_invoice' || v.voucherType === 'cash_memo') && !v.isCancelled);
  const purchases = vouchers.filter((v) => v.voucherType === 'purchase_invoice' && !v.isCancelled);

  const outwardTaxable = sales.reduce(
    (acc, v) => ({
      taxable: acc.taxable + (v.taxableAmount || 0),
      igst: acc.igst + (v.igst || 0),
      cgst: acc.cgst + (v.cgst || 0),
      sgst: acc.sgst + (v.sgst || 0),
      cess: acc.cess + (v.cess || 0),
    }),
    { taxable: 0, igst: 0, cgst: 0, sgst: 0, cess: 0 }
  );

  const itc = purchases.reduce(
    (acc, v) => ({
      igst: acc.igst + (v.igst || 0),
      cgst: acc.cgst + (v.cgst || 0),
      sgst: acc.sgst + (v.sgst || 0),
      cess: acc.cess + (v.cess || 0),
    }),
    { igst: 0, cgst: 0, sgst: 0, cess: 0 }
  );

  const totalItc = itc.igst + itc.cgst + itc.sgst + itc.cess;

  const netIgst = Math.max(0, outwardTaxable.igst - itc.igst);
  const netCgst = Math.max(0, outwardTaxable.cgst - itc.cgst);
  const netSgst = Math.max(0, outwardTaxable.sgst - itc.sgst);

  return {
    outwardTaxable,
    zeroRated: { taxable: 0, igst: 0, cess: 0 },
    inwardRcm: { taxable: 0, igst: 0, cgst: 0, sgst: 0 },
    eligibleItc: {
      allOtherItc: itc,
      totalItc,
    },
    netTaxPayable: {
      igst: netIgst,
      cgst: netCgst,
      sgst: netSgst,
      total: netIgst + netCgst + netSgst,
    },
  };
}

// GSTR-2B Automated Reconciliation Engine
export function reconcileGSTR2B(
  bookVouchers: Voucher[],
  portalItems: GSTR2BItem[]
): {
  rows: ReconRow[];
  matchedCount: number;
  matchedItc: number;
  missingIn2bCount: number;
  missingIn2bItc: number;
  missingInBooksCount: number;
  missingInBooksItc: number;
  mismatchCount: number;
} {
  const purchaseVouchers = bookVouchers.filter((v) => v.voucherType === 'purchase_invoice' && !v.isCancelled);

  const rows: ReconRow[] = [];
  const matchedPortalIndexes = new Set<number>();

  let matchedCount = 0;
  let matchedItc = 0;
  let missingIn2bCount = 0;
  let missingIn2bItc = 0;
  let missingInBooksCount = 0;
  let missingInBooksItc = 0;
  let mismatchCount = 0;

  // Normalize string for comparing invoice numbers
  const normalize = (str: string = '') => str.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

  // 1. Check every book purchase against portal 2B
  purchaseVouchers.forEach((bookInv) => {
    const bookNormNo = normalize(bookInv.voucherNo);
    const bookGst = (bookInv.cgst || 0) + (bookInv.sgst || 0) + (bookInv.igst || 0);

    let matchIdx = -1;
    for (let i = 0; i < portalItems.length; i++) {
      if (matchedPortalIndexes.has(i)) continue;
      const p = portalItems[i];
      if (
        (bookInv.partyGstin && p.gstin === bookInv.partyGstin) ||
        normalize(p.invoiceNo) === bookNormNo
      ) {
        matchIdx = i;
        break;
      }
    }

    if (matchIdx !== -1) {
      matchedPortalIndexes.add(matchIdx);
      const portalInv = portalItems[matchIdx];
      const portalGst = (portalInv.cgst || 0) + (portalInv.sgst || 0) + (portalInv.igst || 0);
      const taxableDiff = Math.abs(bookInv.taxableAmount - portalInv.taxableValue);
      const gstDiff = Math.abs(bookGst - portalGst);

      if (taxableDiff > 2 || gstDiff > 2) {
        mismatchCount++;
        rows.push({
          id: `recon-mismatch-${bookInv.id}`,
          gstin: portalInv.gstin,
          supplierName: bookInv.partyName || portalInv.supplierName,
          invoiceNo: bookInv.voucherNo,
          invoiceDate: bookInv.date,
          bookTaxable: bookInv.taxableAmount,
          portalTaxable: portalInv.taxableValue,
          bookGst,
          portalGst,
          difference: gstDiff,
          status: 'gst_mismatch',
          notes: `Value mismatch: Book ₹${bookGst.toFixed(2)} vs Portal ₹${portalGst.toFixed(2)}`,
        });
      } else {
        matchedCount++;
        matchedItc += bookGst;
        rows.push({
          id: `recon-matched-${bookInv.id}`,
          gstin: portalInv.gstin,
          supplierName: bookInv.partyName || portalInv.supplierName,
          invoiceNo: bookInv.voucherNo,
          invoiceDate: bookInv.date,
          bookTaxable: bookInv.taxableAmount,
          portalTaxable: portalInv.taxableValue,
          bookGst,
          portalGst,
          difference: 0,
          status: 'matched',
          notes: '100% Matched. Eligible for claim in GSTR-3B.',
        });
      }
    } else {
      missingIn2bCount++;
      missingIn2bItc += bookGst;
      rows.push({
        id: `recon-miss2b-${bookInv.id}`,
        gstin: bookInv.partyGstin || 'N/A',
        supplierName: bookInv.partyName,
        invoiceNo: bookInv.voucherNo,
        invoiceDate: bookInv.date,
        bookTaxable: bookInv.taxableAmount,
        portalTaxable: 0,
        bookGst,
        portalGst: 0,
        difference: bookGst,
        status: 'missing_in_2b',
        notes: 'Invoice in Books but supplier not filed GSTR-1 yet. ITC pending.',
      });
    }
  });

  // 2. Identify portal items missing in books
  portalItems.forEach((p, idx) => {
    if (!matchedPortalIndexes.has(idx)) {
      const portalGst = (p.cgst || 0) + (p.sgst || 0) + (p.igst || 0);
      missingInBooksCount++;
      missingInBooksItc += portalGst;
      rows.push({
        id: `recon-missbook-${idx}`,
        gstin: p.gstin,
        supplierName: p.supplierName,
        invoiceNo: p.invoiceNo,
        invoiceDate: p.invoiceDate,
        bookTaxable: 0,
        portalTaxable: p.taxableValue,
        bookGst: 0,
        portalGst,
        difference: portalGst,
        status: 'missing_in_books',
        notes: 'Found in GSTR-2B portal download but unrecorded in purchase book.',
      });
    }
  });

  return {
    rows,
    matchedCount,
    matchedItc,
    missingIn2bCount,
    missingIn2bItc,
    missingInBooksCount,
    missingInBooksItc,
    mismatchCount,
  };
}
