import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { formatCurrency } from './accounting';

// 1. EXCEL (.xlsx) EXPORT
export function exportToExcel(
  filename: string,
  sheets: { sheetName: string; headers: string[]; rows: (string | number)[][] }[]
): void {
  const wb = XLSX.utils.book_new();

  sheets.forEach(({ sheetName, headers, rows }) => {
    const wsData = [headers, ...rows];
    const ws = XLSX.utils.aoa_to_sheet(wsData);

    // Apply auto column width
    const colWidths = headers.map((h, i) => {
      let maxLen = h.length;
      rows.forEach((r) => {
        const val = r[i] !== undefined ? String(r[i]) : '';
        if (val.length > maxLen) maxLen = val.length;
      });
      return { wch: Math.min(Math.max(maxLen + 3, 12), 40) };
    });
    ws['!cols'] = colWidths;

    XLSX.utils.book_append_sheet(wb, ws, sheetName.slice(0, 31));
  });

  XLSX.writeFile(wb, `${filename}.xlsx`);
}

// 2. CSV EXPORT
export function exportToCSV(filename: string, headers: string[], rows: (string | number)[][]): void {
  const csvContent = [
    headers.map((h) => `"${h.replace(/"/g, '""')}"`).join(','),
    ...rows.map((row) =>
      row
        .map((cell) => {
          const val = cell !== undefined && cell !== null ? String(cell) : '';
          return `"${val.replace(/"/g, '""')}"`;
        })
        .join(',')
    ),
  ].join('\r\n');

  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// 3. JSON EXPORT
export function exportToJSON(filename: string, data: any): void {
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// 4. PDF REPORT EXPORT
export function exportReportToPDF(
  title: string,
  businessName: string,
  gstin: string,
  headers: string[],
  rows: (string | number)[][],
  summaryText?: string
): void {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

  // Header branding
  doc.setFontSize(16);
  doc.setTextColor(15, 23, 42); // slate-900
  doc.text(businessName || 'RELAX KHATA', 14, 18);

  doc.setFontSize(10);
  doc.setTextColor(100, 116, 139);
  doc.text(`GSTIN: ${gstin || 'Unregistered'} | Financial Report`, 14, 24);
  doc.text(`Generated on: ${new Date().toLocaleString('en-IN')}`, 14, 29);

  doc.setFontSize(13);
  doc.setTextColor(16, 185, 129); // emerald-600
  doc.text(title, 14, 38);

  (doc as any).autoTable({
    startY: 42,
    head: [headers],
    body: rows,
    theme: 'striped',
    headStyles: { fillColor: [15, 23, 42], textColor: 255, fontSize: 9, fontStyle: 'bold' },
    bodyStyles: { fontSize: 8.5, textColor: [30, 41, 59] },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    margin: { left: 14, right: 14 },
  });

  if (summaryText) {
    const finalY = (doc as any).lastAutoTable?.finalY || 200;
    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105);
    doc.text(summaryText, 14, finalY + 10);
  }

  doc.save(`${title.replace(/\s+/g, '_')}_${Date.now()}.pdf`);
}

// 5. WHATSAPP SHARE GENERATOR
export function generateWhatsAppShareLink(
  partyMobile: string = '',
  businessName: string,
  invoiceNo: string,
  grandTotal: number,
  invoiceDate: string,
  dueDate?: string
): string {
  const cleanPhone = partyMobile.replace(/[^0-9]/g, '');
  const phone = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;

  const message = `Namaste! 🙏\n\nHere is your Tax Invoice from *${businessName}*:\n📄 *Invoice No:* ${invoiceNo}\n📅 *Date:* ${invoiceDate}\n💰 *Amount Due:* ${formatCurrency(grandTotal)}\n${dueDate ? `⏳ *Due Date:* ${dueDate}\n` : ''}\nThank you for doing business with us!\n_Sent via RELAX KHATA_`;

  const encoded = encodeURIComponent(message);
  return phone ? `https://wa.me/${phone}?text=${encoded}` : `https://wa.me/?text=${encoded}`;
}
