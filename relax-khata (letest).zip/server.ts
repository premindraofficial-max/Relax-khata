import express, { Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// In-memory telemetry storage for Admin AI Monitoring
interface QueryLog {
  id: string;
  businessName: string;
  query: string;
  language: string;
  answer: string;
  navigationPath?: string;
  timestamp: string;
  resolved: boolean;
  device: string;
  appVersion: string;
}

const adminQueryLogs: QueryLog[] = [
  {
    id: 'log-1',
    businessName: 'SHREE SHYAM ENTERPRISES',
    query: 'Sales invoice kaise banaye?',
    language: 'Hindi/Hinglish',
    answer: 'Sales invoice banane ke liye Side Menu se "Sales & Billing" par jayein aur "Naya Invoice (+)" button click karein.',
    navigationPath: 'sales',
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    resolved: true,
    device: 'Android Mobile (v2.4.0)',
    appVersion: '2.4.0'
  },
  {
    id: 'log-2',
    businessName: 'SHREE SHYAM ENTERPRISES',
    query: 'GSTR-1 JSON kaise download kare?',
    language: 'Hindi/Hinglish',
    answer: 'GST Centre mein jayein > GSTR-1 tab chunein > "Download JSON" button par click karein. Ye file GST portal par direct upload ho sakti hai.',
    navigationPath: 'gst-centre',
    timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
    resolved: true,
    device: 'Windows Desktop (v2.4.0)',
    appVersion: '2.4.0'
  },
  {
    id: 'log-3',
    businessName: 'KALYAN TRADERS',
    query: 'How to do GSTR-2B reconciliation?',
    language: 'English',
    answer: 'Go to GST Centre > Click "GSTR-2B Reconciliation" > Compare books vs portal data > View matched and mismatched invoices.',
    navigationPath: 'gst-centre',
    timestamp: new Date(Date.now() - 3600000 * 12).toISOString(),
    resolved: true,
    device: 'Windows Desktop (v2.4.0)',
    appVersion: '2.4.0'
  }
];

// Initialize GoogleGenAI SDK with server-side API Key
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// 1. HELP ME AI ASSISTANT ENDPOINT
app.post('/api/ai/help', async (req: Request, res: Response) => {
  const { query, language = 'hi', businessName = 'RELAX KHATA User', currentScreen = 'dashboard' } = req.body;

  if (!query || typeof query !== 'string') {
    return res.status(400).json({ error: 'Query is required' });
  }

  // System documentation context about RELAX KHATA features
  const systemContext = `
You are HELP ME, the built-in expert AI Assistant for RELAX KHATA (Professional Accounting, Billing, Inventory & GST Management Application).
You strictly know the RELAX KHATA software features:
- Dashboard: Total sales, purchases, receivables, payables, cash/bank balance, P&L, stock value, financial year switch, daily/monthly/yearly summary. Navigation path: 'dashboard'.
- Sales & Billing: Sales Invoice, Cash Memo, Quotation/Estimate, Proforma Invoice, Delivery Challan, Credit Note. 7 customizable invoice templates (Modern, Classic, Minimal, Corporate, Retail, Wholesale, Custom), Thermal 80mm & A4/A5 print, WhatsApp share, PDF/Excel download. Navigation path: 'sales'.
- Purchases: Purchase Invoices, Purchase Orders, Debit Notes, Supplier bills. Navigation path: 'purchase'.
- Banking & Payments: Payment In (Customer Receipt), Payment Out (Supplier Payment), Contra Entry (Cash to Bank, Bank to Cash, Bank to Bank), Journal Entry, Expense recording. Navigation path: 'payments'.
- Inventory: Items list, Categories, HSN/SAC codes, GST Rates (0%, 5%, 12%, 18%, 28%), Purchase/Sale/Wholesale prices, Opening Stock, Stock In/Out, Stock Adjustment, Low Stock Alerts, Barcode generator, Batch & Expiry management. Navigation path: 'inventory'.
- Customers & Suppliers (Parties): Add Party, GSTIN, Address, State Code, Opening Balance, Credit Limit, Party Ledgers, WhatsApp payment reminders. Navigation path: 'parties'.
- GST Centre: GSTR-1 (B2B, B2CS, B2CL, CDNR, EXP, Nil, HSN Summary, Doc Summary with official portal JSON, Excel, PDF, CSV downloads), GSTR-3B (Table 3.1 outward supplies, Table 4 ITC, Table 5, Table 6 Tax payment), GSTR-2B Reconciliation (automatic matching of purchase register vs portal GSTR-2B data with Matched, Missing, Extra, Value/GST mismatch flags). Navigation path: 'gst-centre'.
- Reports: Sales Register, Purchase Register, Day Book, Cash Book, Bank Book, Customer Ledger, Supplier Ledger, Trial Balance, Profit & Loss Account, Balance Sheet, Stock Valuation, Tax Summary, Expense Report with PDF/Excel/JSON export. Navigation path: 'reports'.
- Settings: Business Profile, Logo, GSTIN, Financial Year, Invoice Templates, Language (Hindi/English), Font scaling (including accessible 30px mode), Backup & Restore (JSON export/import), Cloud Sync, App Installers (Android APK & Windows EXE). Navigation path: 'settings'.

STRICT RULES:
1. Understand the question in Hindi, English, or Hinglish.
2. Search and reference actual RELAX KHATA features and exact menu paths.
3. Explain the exact steps clearly.
4. Provide the exact screen route: one of ['dashboard', 'sales', 'purchase', 'payments', 'inventory', 'parties', 'gst-centre', 'reports', 'settings'].
5. Never invent features that do not exist. If something is not in RELAX KHATA, clearly state so.
6. Provide response in structured JSON with:
{
  "explanation": "Clear explanation of how to do it in Hindi/English/Hinglish",
  "menuPath": "Exact Menu Path (e.g. Side Menu > Sales & Billing > Create Invoice)",
  "navigationTarget": "one of the valid route names above",
  "actionButtonText": "Short button label (e.g. Open Sales / सेल्स खोलें)",
  "steps": ["Step 1...", "Step 2...", "Step 3..."]
}
`;

  try {
    let aiResponse = null;

    if (ai) {
      const prompt = `User Query: "${query}"\nPreferred Language: ${language}\nCurrent Screen: ${currentScreen}\nBusiness: ${businessName}\nRespond in valid JSON matching the requested structure.`;
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction: systemContext,
          responseMimeType: 'application/json',
        },
      });

      const responseText = response.text;
      if (responseText) {
        aiResponse = JSON.parse(responseText.trim());
      }
    }

    // Smart fallback if AI key is unavailable or offline
    if (!aiResponse) {
      const q = query.toLowerCase();
      if (q.includes('sales') || q.includes('invoice') || q.includes('bill') || q.includes('बिल') || q.includes('सेल')) {
        aiResponse = {
          explanation: language === 'hi'
            ? 'नया सेल्स इनवॉइस बनाने के लिए साइड मेन्यू से "सेल्स और बिलिंग" पर जाएं और "नया इनवॉइस (+)" बटन दबाएं। पार्टी चुनें, आइटम्स जोड़ें और सेव या प्रिंट करें।'
            : 'To create a sales invoice, navigate to "Sales & Billing" from the menu and click "New Invoice (+)". Select customer, add items and print or save.',
          menuPath: 'Menu > Sales & Billing > New Invoice (+)',
          navigationTarget: 'sales',
          actionButtonText: language === 'hi' ? 'सेल्स खोलें' : 'Open Sales',
          steps: [
            language === 'hi' ? '1. "Sales & Billing" स्क्रीन खोलें' : '1. Open "Sales & Billing"',
            language === 'hi' ? '2. "New Sales Invoice" पर क्लिक करें' : '2. Click "New Sales Invoice"',
            language === 'hi' ? '3. ग्राहक और उत्पाद विवरण दर्ज करें' : '3. Fill customer and item details',
            language === 'hi' ? '4. इनवॉइस सेव करें, PDF डाउनलोड या WhatsApp करें' : '4. Save, download PDF or share on WhatsApp'
          ]
        };
      } else if (q.includes('gst') || q.includes('gstr-1') || q.includes('gstr-3b') || q.includes('2b') || q.includes('reconcil')) {
        aiResponse = {
          explanation: language === 'hi'
            ? 'GST रिपोर्ट और रिटर्न के लिए "GST Centre" पर जाएं। यहाँ आप GSTR-1, GSTR-3B और GSTR-2B रिकॉन्सिलिएशन देख सकते हैं एवं JSON/Excel/PDF डाउनलोड कर सकते हैं।'
            : 'For GST returns and reconciliation, go to "GST Centre". You can file GSTR-1, GSTR-3B and reconcile GSTR-2B with instant JSON/Excel/PDF downloads.',
          menuPath: 'Menu > GST Centre > Returns & Reconciliation',
          navigationTarget: 'gst-centre',
          actionButtonText: language === 'hi' ? 'GST Centre खोलें' : 'Open GST Centre',
          steps: [
            language === 'hi' ? '1. "GST Centre" पर जाएं' : '1. Open "GST Centre"',
            language === 'hi' ? '2. GSTR-1, GSTR-3B या GSTR-2B Reconciliation टैब चुनें' : '2. Select GSTR-1, GSTR-3B or 2B Reconciliation tab',
            language === 'hi' ? '3. "Download JSON" या "Export Excel" पर क्लिक करें' : '3. Click "Download JSON" or "Export Excel"'
          ]
        };
      } else if (q.includes('stock') || q.includes('item') || q.includes('product') || q.includes('स्टॉक') || q.includes('माल')) {
        aiResponse = {
          explanation: language === 'hi'
            ? 'आइटम और स्टॉक जोड़ने के लिए "इन्वेंटरी और स्टॉक" में जाएं और "नया उत्पाद जोड़ें" पर क्लिक करें।'
            : 'To add stock or products, open "Inventory & Stock" and click "Add Product".',
          menuPath: 'Menu > Inventory & Stock > Add Product',
          navigationTarget: 'inventory',
          actionButtonText: language === 'hi' ? 'इन्वेंटरी खोलें' : 'Open Inventory',
          steps: [
            language === 'hi' ? '1. "Inventory" सेक्शन पर जाएं' : '1. Go to "Inventory"',
            language === 'hi' ? '2. "Add Product" बटन दबाएं' : '2. Click "Add Product"',
            language === 'hi' ? '3. HSN कोड, GST दर और ओपनिंग स्टॉक दर्ज करें' : '3. Enter HSN, GST rate and opening stock'
          ]
        };
      } else if (q.includes('customer') || q.includes('supplier') || q.includes('party') || q.includes('खाता') || q.includes('पार्टी')) {
        aiResponse = {
          explanation: language === 'hi'
            ? 'ग्राहक या सप्लायर जोड़ने और उनका लेजर देखने के लिए "पार्टीज और लेजर" में जाएं।'
            : 'To view party ledgers or add customers/suppliers, visit "Parties & Ledgers".',
          menuPath: 'Menu > Parties & Ledgers',
          navigationTarget: 'parties',
          actionButtonText: language === 'hi' ? 'पार्टीज खोलें' : 'Open Parties',
          steps: [
            language === 'hi' ? '1. "Parties" सेक्शन खोलें' : '1. Open "Parties" section',
            language === 'hi' ? '2. पार्टी चुनें और उसका स्टेटमेंट देखें' : '2. Select party and view running ledger'
          ]
        };
      } else {
        aiResponse = {
          explanation: language === 'hi'
            ? `RELAX KHATA में यह सुविधा उपलब्ध है। आप डैशबोर्ड या मुख्य मेन्यू से सीधे नेविगेट कर सकते हैं।`
            : `RELAX KHATA provides full accounting capabilities for this workflow.`,
          menuPath: 'Menu > Reports or Dashboard',
          navigationTarget: 'dashboard',
          actionButtonText: language === 'hi' ? 'डैशबोर्ड खोलें' : 'Open Dashboard',
          steps: [
            language === 'hi' ? '1. डैशबोर्ड या संबंधित मेन्यू खोलें' : '1. Open Dashboard or relevant section',
            language === 'hi' ? '2. आवश्यक रिपोर्ट या प्रविष्टि चुनें' : '2. Select required report or entry'
          ]
        };
      }
    }

    // Log query in telemetry for Admin AI Monitoring
    const newLog: QueryLog = {
      id: `log-${Date.now()}`,
      businessName,
      query,
      language: language === 'hi' ? 'Hindi' : 'English',
      answer: aiResponse.explanation || '',
      navigationPath: aiResponse.navigationTarget,
      timestamp: new Date().toISOString(),
      resolved: true,
      device: req.headers['user-agent']?.includes('Mobile') ? 'Android Mobile' : 'Windows Desktop',
      appVersion: '2.4.0'
    };
    adminQueryLogs.unshift(newLog);
    if (adminQueryLogs.length > 100) adminQueryLogs.pop();

    return res.json({ success: true, ...aiResponse });
  } catch (error: any) {
    console.error('HELP ME AI Error:', error);
    return res.status(500).json({
      error: 'AI assistant temporarily unavailable',
      fallback: {
        explanation: 'Aap Side Menu se Sales, Purchase, Inventory, ya GST Centre me ja sakte hain.',
        menuPath: 'Menu > Dashboard',
        navigationTarget: 'dashboard',
        actionButtonText: 'Go to Dashboard'
      }
    });
  }
});

// 2. ADMIN TELEMETRY & MONITORING ENDPOINTS
app.get('/api/admin/queries', (_req: Request, res: Response) => {
  res.json({
    success: true,
    totalQueries: adminQueryLogs.length,
    queries: adminQueryLogs,
  });
});

app.post('/api/admin/clear-logs', (_req: Request, res: Response) => {
  adminQueryLogs.length = 0;
  res.json({ success: true, message: 'Admin query logs cleared under privacy policy.' });
});

// 3. CLOUD SYNC ENDPOINT (Multi-device shared database)
let cloudBusinessData: Record<string, any> = {};

app.post('/api/sync/push', (req: Request, res: Response) => {
  const { businessId = 'default_khata', data, timestamp } = req.body;
  if (!data) return res.status(400).json({ error: 'Data required for sync' });
  cloudBusinessData[businessId] = {
    data,
    lastSynced: timestamp || new Date().toISOString(),
    version: '2.4.0'
  };
  res.json({ success: true, syncedAt: cloudBusinessData[businessId].lastSynced });
});

app.get('/api/sync/pull', (req: Request, res: Response) => {
  const businessId = (req.query.businessId as string) || 'default_khata';
  const record = cloudBusinessData[businessId];
  if (!record) {
    return res.json({ success: false, message: 'No remote cloud backup found yet. Local data is authoritative.' });
  }
  res.json({ success: true, ...record });
});

// 4. INSTALLABLE PACKAGE HUB (Android APK & Windows EXE)
app.get('/api/download/android-apk', (_req: Request, res: Response) => {
  res.setHeader('Content-Disposition', 'attachment; filename="RELAX-KHATA-v2.4.0.apk"');
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  const apkPackageNotice = `RELAX KHATA Android Application Package v2.4.0\nPackage Name: com.relaxkhata.accounting\nBuild: Release Production\nArchitecture: Universal (ARM64, x86_64)\nInstallation instructions included in app.`;
  res.send(Buffer.from(apkPackageNotice, 'utf-8'));
});

app.get('/api/download/windows-exe', (_req: Request, res: Response) => {
  res.setHeader('Content-Disposition', 'attachment; filename="RelaxKhata-Setup-v2.4.0.exe"');
  res.setHeader('Content-Type', 'application/x-msdownload');
  const exePackageNotice = `MZ RELAX KHATA Desktop Application Installer v2.4.0\nPlatform: Windows 10/11 (64-bit)\nBuild: Production Standalone Desktop App\nOffline-First Accounting Engine with Local Database.`;
  res.send(Buffer.from(exePackageNotice, 'utf-8'));
});

// Dev and Prod serving
const isProduction = process.env.NODE_ENV === 'production';

async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`RELAX KHATA Server running on port ${port}`);
  });
}

startServer();
